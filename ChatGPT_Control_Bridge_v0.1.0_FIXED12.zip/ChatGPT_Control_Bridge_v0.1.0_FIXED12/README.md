# ChatGPT Control Bridge v0.1.0-FIXED12

FIXED12 keeps the working FIXED9/FIXED12 command set and changes only the confirmed issues:
- target-window selection no longer switches to the Latin IME when the Bridge command field is focused; ChatGPT remains the preferred target.
- `назад` never uses a blind global BACK that can exit ChatGPT to Home; it uses an exposed target-app back control when available.
- the journal is now a dedicated fixed-height ScrollView, separate from the main controls, so it can be scrolled and inspected independently.

- FIXED12 correction: `открыть файл` now uses the already selected URI when no filename is supplied.
- FIXED12 correction: system aliases for settings, phone, camera and gallery use Android intents instead of label-based package matching.
- FIXED12 correction: microphone targets ChatGPT's voice accessibility description and falls back to a screen-coordinate gesture.


FINAL FIXED12 build identity: FIXED12-CAMERA-GALLERY-20261002-FINAL

The service logs this exact ID on connection so the installed APK can be distinguished from older FIXED12 builds.
