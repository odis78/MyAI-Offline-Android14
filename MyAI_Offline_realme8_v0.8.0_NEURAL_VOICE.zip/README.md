# MyAI Offline — v0.8.0 Neural Voice

Android offline-first assistant:
- Gemma 3 1B INT4 via LiteRT-LM 0.17.1
- neural Russian TTS via sherpa-onnx 1.13.8 + Piper voices
- four downloadable Russian voices: Ruslan, Dmitri, Denis, Irina
- voice archives are stored outside the APK and remain available offline after download
- CPU backend
- microphone input keeps Android on-device recognition when available

The LLM model is still external: import `gemma3-1b-it-int4.litertlm` from the app settings.

Neural TTS voices are downloaded from the sherpa-onnx TTS model releases. The app extracts the archive into its private `files/voices` directory.

### Important
The first v0.8 build adds neural TTS. The next stage can replace Android's speech recognizer with a dedicated Russian sherpa-onnx ASR model for fully independent offline speech input.

Implementation: `NeuralVoiceManager.kt` manages external neural voice archives.
