package com.dmitry.myai

import android.content.Context
import android.net.Uri
import java.io.File

class ModelManager(private val context: Context) {
    private val directory = File(context.filesDir, "models")
    private val prefs = context.getSharedPreferences("models", Context.MODE_PRIVATE)
    private val maxModelBytes = 2L * 1024L * 1024L * 1024L

    init { directory.mkdirs() }

    fun directory(): File = directory

    fun models(): List<File> = directory.listFiles()
        ?.filter { it.isFile && it.extension.equals("litertlm", ignoreCase = true) }
        ?.sortedBy { it.name.lowercase() }
        ?: emptyList()

    fun selectedModel(): File? {
        val selected = prefs.getString("selected", null)
        val all = models()
        return all.firstOrNull { it.name == selected } ?: all.firstOrNull()
    }

    fun selectModel(file: File) {
        require(file.exists() && file.extension.equals("litertlm", true))
        prefs.edit().putString("selected", file.name).apply()
    }

    fun hasModel(): Boolean = selectedModel() != null

    fun importModel(uri: Uri): File {
        val resolver = context.contentResolver
        val displayName = resolver.query(uri, arrayOf("_display_name"), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            ?: "model.litertlm"
        val cleanName = displayName.substringAfterLast('/').trim().ifBlank { "model.litertlm" }
        require(cleanName.endsWith(".litertlm", ignoreCase = true)) { "Нужен файл с расширением .litertlm" }

        val size = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        require(size <= maxModelBytes || size < 0) { "Модель слишком большая (> 2 ГБ)" }
        if (size > 0) {
            require(directory.usableSpace > size + 64L * 1024L * 1024L) {
                "Недостаточно свободного места для модели"
            }
        }

        val target = File(directory, cleanName)
        val temp = File(directory, ".${cleanName}.part")
        temp.delete()
        try {
            resolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Не удалось открыть файл модели" }
                temp.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
            }
            require(temp.length() > 0) { "Файл модели пустой" }
            if (target.exists()) target.delete()
            check(temp.renameTo(target)) { "Не удалось сохранить модель" }
            selectModel(target)
            return target
        } catch (e: Exception) {
            temp.delete()
            throw e
        }
    }

    fun delete(file: File) {
        val wasSelected = selectedModel()?.name == file.name
        file.delete()
        if (wasSelected) {
            val next = models().firstOrNull()
            if (next != null) selectModel(next)
            else prefs.edit().remove("selected").apply()
        }
    }

    fun deleteModels() {
        models().forEach { it.delete() }
        prefs.edit().remove("selected").apply()
    }
}
