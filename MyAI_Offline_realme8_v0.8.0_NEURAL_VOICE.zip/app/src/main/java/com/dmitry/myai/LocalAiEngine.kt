
package com.dmitry.myai

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalAiEngine(private val context: Context) {
    private var engine: Engine? = null
    private var conversation: com.google.ai.edge.litertlm.Conversation? = null

    suspend fun initialize(modelPath: String) {
        close()
        val config = EngineConfig(
            modelPath = modelPath,
            backend = Backend.CPU(),
            cacheDir = context.cacheDir.absolutePath
        )
        val e = Engine(config)
        e.initialize()
        engine = e
        conversation = e.createConversation()
    }

    fun isInitialized(): Boolean = conversation != null

    fun streamChat(message: String): Flow<String> {
        val c = conversation ?: error("AI engine is not initialized")
        return c.sendMessageAsync(message).map { msg ->
            msg.toString()
        }
    }

    fun close() {
        conversation?.close()
        conversation = null
        engine?.close()
        engine = null
    }
}
