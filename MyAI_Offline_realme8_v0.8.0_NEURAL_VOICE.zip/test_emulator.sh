#!/usr/bin/env bash
set -euo pipefail

APP_ID="com.dmitry.myai"
APK="app/build/outputs/apk/debug/app-debug.apk"
AVD="${1:-Pixel_8_API_34}"

if ! command -v adb >/dev/null 2>&1; then echo "adb не найден: установите Android SDK Platform Tools"; exit 2; fi
if ! command -v emulator >/dev/null 2>&1; then echo "emulator не найден: установите Android Emulator"; exit 2; fi

./gradlew assembleDebug
adb start-server
if ! emulator -list-avds | grep -qx "$AVD"; then
  echo "AVD '$AVD' не найден. Создайте Android 14 / API 34 AVD в Device Manager."
  exit 3
fi

emulator "@$AVD" -no-snapshot -no-boot-anim >/tmp/myai-emulator.log 2>&1 &
EMU_PID=$!
trap 'kill $EMU_PID 2>/dev/null || true' EXIT

adb wait-for-device
until adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r' | grep -q 1; do sleep 2; done
adb install -r "$APK"
adb shell am force-stop "$APP_ID"
adb shell monkey -p "$APP_ID" 1 >/dev/null
sleep 5
adb logcat -d -t 300 '*:E' > emulator-errors.log || true

echo "Готово. Ошибки: emulator-errors.log"
if grep -q "FATAL EXCEPTION\|AndroidRuntime" emulator-errors.log; then
  echo "НАЙДЕНА КРИТИЧЕСКАЯ ОШИБКА"
  exit 10
fi
echo "Критических Java/Kotlin ошибок в последних 300 строках не обнаружено."
