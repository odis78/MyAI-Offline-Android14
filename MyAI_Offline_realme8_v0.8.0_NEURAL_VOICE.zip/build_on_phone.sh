#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "MyAI phone build helper"
echo "This script is intended for Termux. For the recommended phone-only build, use GitHub Actions."
if [ ! -f "./gradlew" ]; then
  echo "gradlew is missing. The GitHub Actions workflow can generate/use Gradle tooling after the project is uploaded."
  exit 1
fi
chmod +x ./gradlew
./gradlew :app:assembleDebug --stacktrace
echo
echo "APK:"
find app/build/outputs/apk/debug -name "*.apk" -maxdepth 1 -print
