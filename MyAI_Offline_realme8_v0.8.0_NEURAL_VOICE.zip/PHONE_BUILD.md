# Сборка на телефоне

Проект рассчитан на Android Studio и обычную Gradle-сборку. Если собираешь прямо на Android-устройстве, сначала установи среду, способную запускать Gradle/Android SDK, и проверь наличие API 34.

Проверка проекта:
- compileSdk 34
- targetSdk 34
- minSdk 28
- Java/Kotlin 17
- LiteRT-LM 0.17.1

Модель Gemma 3 1B INT4 (~584 MB) устанавливается отдельно через системный файловый picker.
