# realme 8 profile

Target: realme 8 4G / RMX3085
SoC: MediaTek Helio G95
GPU: ARM Mali-G76
Typical RAM variants: 4/6/8 GB depending on market
Original OS: realme UI 2.0 based on Android 11
Inference backend: CPU first
Starter model: Gemma3-1B-IT INT4 `.litertlm`

This profile does not hard-code the app to one RAM size; the app remains installable on the other realme 8 RAM variants.


## v0.6.3 FINAL
- Corrected AndroidManifest.xml: optional native libraries are declared inside `<application>`.
- Added executable `gradlew` launcher using Gradle 8.7 for GitHub Actions builds.
