package com.dmitry.myai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Handler
import android.os.Looper

/**
 * Android control bridge for MyAI.
 *
 * The user must explicitly enable this service in Android Accessibility settings.
 * It is intentionally small in v0.8.0: global navigation, screen inspection and
 * basic text/button interaction are exposed first. More tools can be added without
 * coupling them to the local LLM.
 */
class MyAiAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var instance: MyAiAccessibilityService? = null

        fun isEnabled(): Boolean = instance != null

        fun goHome(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_HOME) == true

        fun goBack(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_BACK) == true

        fun openRecents(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) == true

        fun notifications(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) == true

        fun readScreen(): String = instance?.screenText() ?: ""

        fun clickText(text: String): Boolean = instance?.clickTextInternal(text) == true

        fun tap(x: Float, y: Float): Boolean = instance?.tapInternal(x, y) == true
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun screenText(): String {
        val root = rootInActiveWindow ?: return ""
        val out = StringBuilder()
        appendNodeText(root, out, 0)
        return out.toString().trim().take(12000)
    }

    private fun appendNodeText(node: AccessibilityNodeInfo, out: StringBuilder, depth: Int) {
        if (depth > 40) return
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrBlank()) out.appendLine(text)
        if (!desc.isNullOrBlank() && desc != text) out.appendLine(desc)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                appendNodeText(child, out, depth + 1)
                child.recycle()
            }
        }
    }

    private fun clickTextInternal(target: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findText(root, target.trim())
        if (node == null) return false
        val clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (clicked) {
            node.recycle()
            return true
        }
        val bounds = android.graphics.Rect()
        node.getBoundsInScreen(bounds)
        node.recycle()
        return if (bounds.width() > 0 && bounds.height() > 0) {
            tapInternal(bounds.centerX().toFloat(), bounds.centerY().toFloat())
        } else false
    }

    private fun findText(node: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val exact = node.text?.toString()?.trim()?.equals(target, ignoreCase = true) == true ||
            node.contentDescription?.toString()?.trim()?.equals(target, ignoreCase = true) == true
        if (exact) return AccessibilityNodeInfo.obtain(node)

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findText(child, target)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    private fun tapInternal(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
    }
}
