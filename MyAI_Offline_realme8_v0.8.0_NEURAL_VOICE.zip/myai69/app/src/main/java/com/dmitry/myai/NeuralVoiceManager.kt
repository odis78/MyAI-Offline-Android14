package com.dmitry.myai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Offline neural voice catalog. Voice archives are downloaded once and kept on-device. */
class NeuralVoiceManager(private val context: Context) {
    data class Voice(
        val id: String,
        val title: String,
        val gender: String,
        val archiveUrl: String,
        val archiveDir: String
    )

    companion object {
        val CATALOG = listOf(
            Voice("ruslan", "Руслан", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-ruslan-medium.tar.bz2", "vits-piper-ru_RU-ruslan-medium"),
            Voice("dmitri", "Дмитрий", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-dmitri-medium.tar.bz2", "vits-piper-ru_RU-dmitri-medium"),
            Voice("denis", "Денис", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-denis-medium.tar.bz2", "vits-piper-ru_RU-denis-medium"),
            Voice("irina", "Ирина", "женский", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-irina-medium.tar.bz2", "vits-piper-ru_RU-irina-medium")
        )
    }

    private val root = File(context.filesDir, "voices").apply { mkdirs() }
    private val selectedPrefs = context.getSharedPreferences("voice", Context.MODE_PRIVATE)

    fun root(): File = root
    fun selected(): Voice? = CATALOG.firstOrNull { it.id == selectedPrefs.getString("selected", "ruslan") && isInstalled(it) }
    fun select(voice: Voice) {
        require(isInstalled(voice))
        selectedPrefs.edit().putString("selected", voice.id).apply()
    }
    fun isInstalled(voice: Voice): Boolean {
        val dir = File(root, voice.archiveDir)
        return dir.isDirectory && dir.walkTopDown().any { it.isFile && it.extension.equals("onnx", true) } &&
            File(dir, "tokens.txt").exists() && File(dir, "espeak-ng-data").isDirectory
    }
    fun voiceDir(voice: Voice): File = File(root, voice.archiveDir)

    suspend fun download(voice: Voice, onProgress: (Int) -> Unit = {}) = withContext(Dispatchers.IO) {
        val tmp = File(root, ".${voice.archiveDir}.tar.bz2.part")
        val archive = File(root, ".${voice.archiveDir}.tar.bz2")
        val target = voiceDir(voice)
        tmp.delete(); archive.delete()
        val connection = (URL(voice.archiveUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 60_000
            requestMethod = "GET"
            instanceFollowRedirects = true
        }
        try {
            connection.connect()
            require(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }
            val total = connection.contentLengthLong
            connection.inputStream.use { input ->
                FileOutputStream(tmp).use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var done = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        done += n
                        if (total > 0) onProgress((done * 100L / total).toInt().coerceIn(0, 100))
                    }
                }
            }
            check(tmp.length() > 0) { "Пустой архив голоса" }
            check(tmp.renameTo(archive)) { "Не удалось сохранить архив" }
            target.deleteRecursively()
            extractTarBz2(archive, root)
            archive.delete()
            tmp.delete()
            require(isInstalled(voice)) { "Архив не содержит корректную модель голоса" }
            if (selectedPrefs.getString("selected", null) == null) select(voice)
        } catch (e: Exception) {
            tmp.delete(); archive.delete(); target.deleteRecursively()
            throw e
        } finally {
            connection.disconnect()
        }
    }

    fun delete(voice: Voice) {
        voiceDir(voice).deleteRecursively()
        if (selectedPrefs.getString("selected", null) == voice.id) {
            val next = CATALOG.firstOrNull { isInstalled(it) }
            if (next != null) selectedPrefs.edit().putString("selected", next.id).apply()
            else selectedPrefs.edit().remove("selected").apply()
        }
    }

    private fun extractTarBz2(archive: File, destination: File) {
        FileInputStream(archive).use { fis ->
            BZip2CompressorInputStream(fis).use { bz ->
                TarArchiveInputStream(bz).use { tar ->
                    var entry = tar.nextTarEntry
                    while (entry != null) {
                        val safeName = entry.name.replace('\\', '/').trimStart('/')
                        require(!safeName.split('/').any { it == ".." }) { "Опасный путь в архиве" }
                        val out = File(destination, safeName)
                        if (entry.isDirectory) {
                            out.mkdirs()
                        } else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { output -> tar.copyTo(output) }
                        }
                        entry = tar.nextTarEntry
                    }
                }
            }
        }
    }
}
