package com.dmitry.myai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class NeuralVoiceManager(private val context: Context) {
    data class Voice(
        val id: String,
        val title: String,
        val gender: String,
        val archiveUrl: String,
        val archiveDir: String
    )

    companion object {
        val CATALOG = listOf(
            Voice("ruslan", "Руслан", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-ruslan-medium.tar.bz2", "vits-piper-ru_RU-ruslan-medium"),
            Voice("dmitri", "Дмитрий", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-dmitri-medium.tar.bz2", "vits-piper-ru_RU-dmitri-medium"),
            Voice("denis", "Денис", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-denis-medium.tar.bz2", "vits-piper-ru_RU-denis-medium"),
            Voice("irina", "Ирина", "женский", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-irina-medium.tar.bz2", "vits-piper-ru_RU-irina-medium")
        )
    }

    private val root = File(context.filesDir, "voices").apply { mkdirs() }
    private val sharedEspeak = File(root, "espeak-ng-data")
    private val selectedPrefs = context.getSharedPreferences("voice", Context.MODE_PRIVATE)

    init {
        migrateExistingEspeak()
    }

    fun root(): File = root
    fun sharedEspeakDir(): File = sharedEspeak

    fun selected(): Voice? = CATALOG.firstOrNull {
        it.id == selectedPrefs.getString("selected", null) && isInstalled(it)
    }

    fun select(voice: Voice) {
        require(isInstalled(voice)) { "Голос ${voice.title} ещё не установлен" }
        selectedPrefs.edit().putString("selected", voice.id).apply()
    }

    fun isInstalled(voice: Voice): Boolean = hasVoiceFiles(voiceDir(voice))
    fun voiceDir(voice: Voice): File = File(root, voice.archiveDir)

    suspend fun download(voice: Voice, onProgress: (Int, String) -> Unit = { _, _ -> }) = withContext(Dispatchers.IO) {
        val tmp = File(root, ".${voice.archiveDir}.tar.bz2.part")
        val archive = File(root, ".${voice.archiveDir}.tar.bz2")
        val staging = File(root, ".${voice.archiveDir}.extract")
        val target = voiceDir(voice)
        val espeakStage = File(root, ".espeak-ng-data.extract")

        tmp.delete(); archive.delete(); staging.deleteRecursively(); staging.mkdirs()
        if (!sharedEspeak.isDirectory) espeakStage.deleteRecursively()

        val connection = (URL(voice.archiveUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 120_000
            requestMethod = "GET"
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "MyAI-Offline/0.8.0")
            setRequestProperty("Accept", "application/octet-stream")
        }

        try {
            onProgress(0, "Подключение…")
            connection.connect()
            val response = connection.responseCode
            require(response in 200..299) { "HTTP $response" }
            val total = connection.contentLengthLong
            connection.inputStream.use { input ->
                FileOutputStream(tmp).use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100L / total).toInt().coerceIn(0, 100)
                            if (p != last) { last = p; onProgress(p, "Скачивание…") }
                        }
                    }
                    output.fd.sync()
                }
            }
            check(tmp.length() > 0) { "Пустой архив голоса" }
            check(tmp.renameTo(archive)) { "Не удалось сохранить архив" }

            onProgress(100, "Распаковка…")
            val skipSharedEspeak = sharedEspeak.isDirectory && File(sharedEspeak, "phontab").exists()
            val extractedRoot = extractTarBz2(archive, staging, skipSharedEspeak) { count, name ->
                onProgress(100, "Распаковка: $count файлов${if (name.isNotBlank()) " • $name" else ""}")
            }

            require(extractedRoot != null) { "В архиве не найдены ONNX-модель и tokens.txt" }
            val sourceRoot = extractedRoot

            if (!sharedEspeak.isDirectory) {
                val sourceEspeak = findDirNamed(sourceRoot, "espeak-ng-data")
                    ?: error("В архиве не найден espeak-ng-data")
                onProgress(100, "Установка общего espeak-ng-data…")
                sharedEspeak.deleteRecursively()
                check(sourceEspeak.renameTo(sharedEspeak)) {
                    "Не удалось установить общий espeak-ng-data"
                }
                if (!hasEspeakData()) error("espeak-ng-data установлен неполностью")
            }

            onProgress(100, "Проверка модели…")
            target.deleteRecursively()
            if (!sourceRoot.renameTo(target)) {
                copyDirectory(sourceRoot, target)
                sourceRoot.deleteRecursively()
            }
            // Old installations may contain a private copy. It is no longer needed.
            File(target, "espeak-ng-data").deleteRecursively()
            check(hasVoiceFiles(target)) { "Файлы голоса установлены не полностью" }

            if (selectedPrefs.getString("selected", null).isNullOrBlank() || selected() == null) {
                selectedPrefs.edit().putString("selected", voice.id).apply()
            }
            onProgress(100, "Голос установлен")
        } catch (e: Exception) {
            tmp.delete(); archive.delete(); staging.deleteRecursively(); espeakStage.deleteRecursively()
            throw IllegalStateException("Не удалось установить голос «${voice.title}»: ${e.message ?: e.javaClass.simpleName}", e)
        } finally {
            connection.disconnect()
            tmp.delete(); archive.delete(); staging.deleteRecursively(); espeakStage.deleteRecursively()
        }
    }

    fun delete(voice: Voice) {
        voiceDir(voice).deleteRecursively()
        if (selectedPrefs.getString("selected", null) == voice.id) {
            val next = CATALOG.firstOrNull { isInstalled(it) }
            if (next != null) selectedPrefs.edit().putString("selected", next.id).apply()
            else selectedPrefs.edit().remove("selected").apply()
        }
    }

    private fun migrateExistingEspeak() {
        if (hasEspeakData()) return
        CATALOG.asSequence()
            .map { File(root, it.archiveDir) }
            .map { File(it, "espeak-ng-data") }
            .firstOrNull { it.isDirectory && File(it, "phontab").isFile }
            ?.let { old ->
                sharedEspeak.deleteRecursively()
                if (!old.renameTo(sharedEspeak)) {
                    copyDirectory(old, sharedEspeak)
                    old.deleteRecursively()
                }
            }
    }

    private fun hasEspeakData(): Boolean = sharedEspeak.isDirectory && File(sharedEspeak, "phontab").isFile

    private fun hasVoiceFiles(dir: File): Boolean {
        if (!dir.isDirectory || !hasEspeakData()) return false
        val children = dir.listFiles() ?: return false
        val hasOnnx = children.any { it.isFile && it.extension.equals("onnx", true) }
        return hasOnnx && File(dir, "tokens.txt").isFile
    }

    private fun findDirNamed(root: File, name: String): File? {
        if (root.name == name && root.isDirectory) return root
        return root.walkTopDown().firstOrNull { it.isDirectory && it.name == name }
    }

    private fun copyDirectory(source: File, destination: File) {
        require(source.isDirectory) { "Исходная папка не найдена" }
        destination.mkdirs()
        source.walkTopDown().forEach { file ->
            val relative = file.relativeTo(source).path
            val out = if (relative.isBlank()) destination else File(destination, relative)
            if (file.isDirectory) out.mkdirs()
            else {
                out.parentFile?.mkdirs()
                FileInputStream(file).use { input -> FileOutputStream(out).use { output -> input.copyTo(output) } }
            }
        }
    }

    private fun extractTarBz2(
        archive: File,
        destination: File,
        skipEspeak: Boolean,
        onEntry: (count: Int, name: String) -> Unit
    ): File? {
        data class PendingLink(val path: String, val target: String)
        val links = mutableListOf<PendingLink>()
        var voiceRoot: File? = null
        var count = 0
        FileInputStream(archive).use { fis ->
            BZip2CompressorInputStream(fis).use { bz ->
                TarArchiveInputStream(bz).use { tar ->
                    var entry = tar.nextTarEntry
                    while (entry != null) {
                        val safeName = entry.name.replace('\\', '/').trimStart('/')
                        require(safeName.isNotBlank()) { "Пустой путь в архиве" }
                        require(!safeName.split('/').any { it == ".." }) { "Опасный путь в архиве" }
                        val parts = safeName.split('/')
                        val espeakIndex = parts.indexOfFirst { it == "espeak-ng-data" }
                        val isEspeak = espeakIndex >= 0
                        if (isEspeak && skipEspeak) {
                            // Shared data already exists. Do not spend time unpacking a duplicate.
                        } else {
                            val out = File(destination, safeName)
                            if (safeName.endsWith(".onnx", true)) voiceRoot = out.parentFile
                            when {
                                entry.isDirectory -> out.mkdirs()
                                entry.isSymbolicLink || entry.isLink -> {
                                    val linkName = entry.linkName.replace('\\', '/').trimStart('/')
                                    require(linkName.isNotBlank() && !linkName.split('/').any { it == ".." }) { "Опасная ссылка: $safeName" }
                                    links += PendingLink(safeName, linkName)
                                }
                                else -> {
                                    out.parentFile?.mkdirs()
                                    FileOutputStream(out).use { output -> tar.copyTo(output) }
                                }
                            }
                            count++
                            if (count == 1 || count % 25 == 0 || safeName.endsWith(".onnx", true)) onEntry(count, safeName.substringAfterLast('/'))
                        }
                        entry = tar.nextTarEntry
                    }
                }
            }
        }

        var remaining = links.toMutableList()
        repeat(links.size + 2) {
            if (remaining.isEmpty()) return@repeat
            val next = mutableListOf<PendingLink>()
            for (link in remaining) {
                val out = File(destination, link.path)
                val target = File(destination, link.target)
                if (target.exists()) {
                    if (target.isDirectory) copyDirectory(target, out)
                    else {
                        out.parentFile?.mkdirs()
                        FileInputStream(target).use { input -> FileOutputStream(out).use { output -> input.copyTo(output) } }
                    }
                } else next += link
            }
            remaining = next
        }
        check(remaining.isEmpty()) { "Не удалось восстановить ссылки архива голоса" }
        return voiceRoot
    }
}
