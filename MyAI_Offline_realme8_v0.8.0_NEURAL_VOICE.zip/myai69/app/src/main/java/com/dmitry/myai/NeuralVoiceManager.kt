package com.dmitry.myai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Offline neural voice catalog. Voice archives are downloaded once and kept on-device. */
class NeuralVoiceManager(private val context: Context) {
    data class Voice(
        val id: String,
        val title: String,
        val gender: String,
        val archiveUrl: String,
        val archiveDir: String
    )

    companion object {
        val CATALOG = listOf(
            Voice("ruslan", "Руслан", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-ruslan-medium.tar.bz2", "vits-piper-ru_RU-ruslan-medium"),
            Voice("dmitri", "Дмитрий", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-dmitri-medium.tar.bz2", "vits-piper-ru_RU-dmitri-medium"),
            Voice("denis", "Денис", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-denis-medium.tar.bz2", "vits-piper-ru_RU-denis-medium"),
            Voice("irina", "Ирина", "женский", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-irina-medium.tar.bz2", "vits-piper-ru_RU-irina-medium")
        )
    }

    private val root = File(context.filesDir, "voices").apply { mkdirs() }
    private val selectedPrefs = context.getSharedPreferences("voice", Context.MODE_PRIVATE)

    fun root(): File = root

    fun selected(): Voice? = CATALOG.firstOrNull {
        it.id == selectedPrefs.getString("selected", "ruslan") && isInstalled(it)
    }

    fun select(voice: Voice) {
        require(isInstalled(voice)) { "Голос ${voice.title} ещё не установлен" }
        selectedPrefs.edit().putString("selected", voice.id).apply()
    }

    /**
     * The release archives normally contain a directory named exactly like archiveDir,
     * but this validator intentionally searches recursively. This protects against
     * an extra top-level folder or a changed archive layout.
     */
    fun isInstalled(voice: Voice): Boolean = hasVoiceFiles(voiceDir(voice))

    fun voiceDir(voice: Voice): File = File(root, voice.archiveDir)

    suspend fun download(voice: Voice, onProgress: (Int) -> Unit = {}) = withContext(Dispatchers.IO) {
        val tmp = File(root, ".${voice.archiveDir}.tar.bz2.part")
        val archive = File(root, ".${voice.archiveDir}.tar.bz2")
        val staging = File(root, ".${voice.archiveDir}.extract")
        val target = voiceDir(voice)

        tmp.delete()
        archive.delete()
        staging.deleteRecursively()
        staging.mkdirs()

        val connection = (URL(voice.archiveUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 120_000
            requestMethod = "GET"
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "MyAI-Offline/0.8.1")
            setRequestProperty("Accept", "application/octet-stream")
        }

        try {
            connection.connect()
            val response = connection.responseCode
            require(response in 200..299) {
                val location = connection.getHeaderField("Location")
                if (location.isNullOrBlank()) "HTTP $response" else "HTTP $response → $location"
            }

            val total = connection.contentLengthLong
            connection.inputStream.use { input ->
                FileOutputStream(tmp).use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var done = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        done += n
                        if (total > 0) {
                            onProgress((done * 100L / total).toInt().coerceIn(0, 100))
                        }
                    }
                    output.fd.sync()
                }
            }

            check(tmp.length() > 0) { "Пустой архив голоса" }
            check(tmp.renameTo(archive)) { "Не удалось сохранить архив" }

            // Keep the old installed voice until the new archive is fully extracted
            // and validated. This avoids leaving a half-installed model on failure.
            extractTarBz2(archive, staging)
            onProgress(100)

            val extractedRoot = findVoiceRoot(staging)
                ?: error("В архиве не найдены ONNX-модель, tokens.txt и espeak-ng-data")

            val prepared = File(root, ".${voice.archiveDir}.ready")
            prepared.deleteRecursively()
            check(extractedRoot.renameTo(prepared)) {
                "Не удалось подготовить файлы голоса (${extractedRoot.absolutePath})"
            }

            check(hasVoiceFiles(prepared)) {
                "Распаковка завершилась, но файлы Piper/Sherpa неполные"
            }

            target.deleteRecursively()
            check(prepared.renameTo(target)) {
                "Не удалось установить модель в ${target.absolutePath}"
            }
            staging.deleteRecursively()

            check(isInstalled(voice)) {
                "Модель распакована, но проверка установки не пройдена"
            }

            // First successfully installed Russian voice becomes the default.
            if (selectedPrefs.getString("selected", null).isNullOrBlank() || selected() == null) {
                selectedPrefs.edit().putString("selected", voice.id).apply()
            }
        } catch (e: Exception) {
            tmp.delete()
            archive.delete()
            staging.deleteRecursively()
            File(root, ".${voice.archiveDir}.ready").deleteRecursively()
            // Do not delete an already installed working voice on a failed update.
            throw IllegalStateException("Не удалось установить голос «${voice.title}»: ${e.message ?: e.javaClass.simpleName}", e)
        } finally {
            connection.disconnect()
            tmp.delete()
            archive.delete()
            staging.deleteRecursively()
            File(root, ".${voice.archiveDir}.ready").deleteRecursively()
        }
    }

    fun delete(voice: Voice) {
        voiceDir(voice).deleteRecursively()
        if (selectedPrefs.getString("selected", null) == voice.id) {
            val next = CATALOG.firstOrNull { isInstalled(it) }
            if (next != null) selectedPrefs.edit().putString("selected", next.id).apply()
            else selectedPrefs.edit().remove("selected").apply()
        }
    }

    private fun hasVoiceFiles(dir: File): Boolean {
        if (!dir.isDirectory) return false
        val onnx = dir.walkTopDown().any { it.isFile && it.extension.equals("onnx", true) }
        val tokens = dir.walkTopDown().any { it.isFile && it.name.equals("tokens.txt", true) }
        val espeak = dir.walkTopDown().any { it.isDirectory && it.name == "espeak-ng-data" }
        return onnx && tokens && espeak
    }

    /** Find the directory that contains the three artifacts required by Sherpa-ONNX VITS/Piper. */
    private fun findVoiceRoot(staging: File): File? {
        val candidates = staging.walkTopDown()
            .filter { it.isDirectory }
            .toList()
            .sortedByDescending { it.absolutePath.length }

        return candidates.firstOrNull { candidate ->
            val hasOnnx = candidate.walkTopDown().any { it.isFile && it.extension.equals("onnx", true) }
            val hasTokens = candidate.walkTopDown().any { it.isFile && it.name.equals("tokens.txt", true) }
            val hasEspeak = candidate.walkTopDown().any { it.isDirectory && it.name == "espeak-ng-data" }
            hasOnnx && hasTokens && hasEspeak
        }
    }

    private fun extractTarBz2(archive: File, destination: File) {
        FileInputStream(archive).use { fis ->
            BZip2CompressorInputStream(fis).use { bz ->
                TarArchiveInputStream(bz).use { tar ->
                    var entry = tar.nextTarEntry
                    while (entry != null) {
                        val safeName = entry.name.replace('\\', '/').trimStart('/')
                        require(safeName.isNotBlank()) { "Пустой путь в архиве" }
                        require(!safeName.split('/').any { it == ".." }) { "Опасный путь в архиве" }
                        val out = File(destination, safeName)

                        if (entry.isDirectory) {
                            out.mkdirs()
                        } else if (entry.isSymbolicLink || entry.isLink) {
                            // The Piper voice archives should not require links. Refuse them
                            // instead of creating an unsafe or incomplete extracted model.
                            error("Архив содержит неподдерживаемую ссылку: $safeName")
                        } else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { output -> tar.copyTo(output) }
                        }
                        entry = tar.nextTarEntry
                    }
                }
            }
        }
    }
}
