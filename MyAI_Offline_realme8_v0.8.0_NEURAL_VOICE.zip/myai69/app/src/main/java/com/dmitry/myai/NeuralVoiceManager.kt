package com.dmitry.myai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Offline neural voice catalog. Voice archives are downloaded once and kept on-device. */
class NeuralVoiceManager(private val context: Context) {
    data class Voice(
        val id: String,
        val title: String,
        val gender: String,
        val archiveUrl: String,
        val archiveDir: String
    )

    companion object {
        val CATALOG = listOf(
            Voice("ruslan", "Руслан", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-ruslan-medium.tar.bz2", "vits-piper-ru_RU-ruslan-medium"),
            Voice("dmitri", "Дмитрий", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-dmitri-medium.tar.bz2", "vits-piper-ru_RU-dmitri-medium"),
            Voice("denis", "Денис", "мужской", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-denis-medium.tar.bz2", "vits-piper-ru_RU-denis-medium"),
            Voice("irina", "Ирина", "женский", "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ru_RU-irina-medium.tar.bz2", "vits-piper-ru_RU-irina-medium")
        )
    }

    private val root = File(context.filesDir, "voices").apply { mkdirs() }
    private val selectedPrefs = context.getSharedPreferences("voice", Context.MODE_PRIVATE)

    fun root(): File = root

    fun selected(): Voice? = CATALOG.firstOrNull {
        it.id == selectedPrefs.getString("selected", "ruslan") && isInstalled(it)
    }

    fun select(voice: Voice) {
        require(isInstalled(voice)) { "Голос ${voice.title} ещё не установлен" }
        selectedPrefs.edit().putString("selected", voice.id).apply()
    }

    /**
     * The release archives normally contain a directory named exactly like archiveDir,
     * but this validator intentionally searches recursively. This protects against
     * an extra top-level folder or a changed archive layout.
     */
    fun isInstalled(voice: Voice): Boolean = hasVoiceFiles(voiceDir(voice))

    fun voiceDir(voice: Voice): File = File(root, voice.archiveDir)

    suspend fun download(voice: Voice, onProgress: (Int) -> Unit = {}) = withContext(Dispatchers.IO) {
        val tmp = File(root, ".${voice.archiveDir}.tar.bz2.part")
        val archive = File(root, ".${voice.archiveDir}.tar.bz2")
        val staging = File(root, ".${voice.archiveDir}.extract")
        val target = voiceDir(voice)

        tmp.delete()
        archive.delete()
        staging.deleteRecursively()
        staging.mkdirs()

        val connection = (URL(voice.archiveUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 120_000
            requestMethod = "GET"
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "MyAI-Offline/0.8.0")
            setRequestProperty("Accept", "application/octet-stream")
        }

        try {
            connection.connect()
            val response = connection.responseCode
            require(response in 200..299) {
                val location = connection.getHeaderField("Location")
                if (location.isNullOrBlank()) "HTTP $response" else "HTTP $response → $location"
            }

            val total = connection.contentLengthLong
            connection.inputStream.use { input ->
                FileOutputStream(tmp).use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var done = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        done += n
                        if (total > 0) {
                            onProgress((done * 100L / total).toInt().coerceIn(0, 100))
                        }
                    }
                    output.fd.sync()
                }
            }

            check(tmp.length() > 0) { "Пустой архив голоса" }
            check(tmp.renameTo(archive)) { "Не удалось сохранить архив" }

            // Keep the old installed voice until the new archive is fully extracted
            // and validated. This avoids leaving a half-installed model on failure.
            extractTarBz2(archive, staging)
            onProgress(100)

            val extractedRoot = findVoiceRoot(staging)
                ?: error("В архиве не найдены ONNX-модель, tokens.txt и espeak-ng-data")

            // The official Sherpa/Piper bundle has this exact directory name.
            // Prefer an atomic same-filesystem move so installing a voice does not
            // spend minutes copying thousands of small espeak-ng-data files.
            target.deleteRecursively()
            val moved = extractedRoot.renameTo(target)
            if (!moved) {
                copyDirectory(extractedRoot, target)
                extractedRoot.deleteRecursively()
            }
            check(hasVoiceFiles(target)) {
                "Файлы голоса установлены не полностью"
            }
            staging.deleteRecursively()

            check(isInstalled(voice)) {
                "Модель распакована, но проверка установки не пройдена"
            }

            // First successfully installed Russian voice becomes the default.
            if (selectedPrefs.getString("selected", null).isNullOrBlank() || selected() == null) {
                selectedPrefs.edit().putString("selected", voice.id).apply()
            }
        } catch (e: Exception) {
            tmp.delete()
            archive.delete()
            staging.deleteRecursively()
            File(root, ".${voice.archiveDir}.ready").deleteRecursively()
            // Do not delete an already installed working voice on a failed update.
            throw IllegalStateException("Не удалось установить голос «${voice.title}»: ${e.message ?: e.javaClass.simpleName}", e)
        } finally {
            connection.disconnect()
            tmp.delete()
            archive.delete()
            staging.deleteRecursively()
            File(root, ".${voice.archiveDir}.ready").deleteRecursively()
        }
    }

    fun delete(voice: Voice) {
        voiceDir(voice).deleteRecursively()
        if (selectedPrefs.getString("selected", null) == voice.id) {
            val next = CATALOG.firstOrNull { isInstalled(it) }
            if (next != null) selectedPrefs.edit().putString("selected", next.id).apply()
            else selectedPrefs.edit().remove("selected").apply()
        }
    }

    private fun hasVoiceFiles(dir: File): Boolean {
        if (!dir.isDirectory) return false
        val children = dir.listFiles() ?: return false
        val hasOnnx = children.any { it.isFile && it.extension.equals("onnx", true) }
        val hasTokens = File(dir, "tokens.txt").isFile
        val hasEspeak = File(dir, "espeak-ng-data").isDirectory
        return hasOnnx && hasTokens && hasEspeak
    }

    /**
     * Find the actual Piper voice directory without repeatedly scanning the
     * thousands of files under espeak-ng-data. We walk the extracted tree once
     * only to locate an ONNX file, then walk upward and check the expected
     * tokens.txt/espeak-ng-data files directly.
     */
    private fun findVoiceRoot(staging: File): File? {
        val stagingPath = staging.canonicalFile.toPath()
        var onnxFile: File? = null

        for (file in staging.walkTopDown()) {
            if (file.isFile && file.extension.equals("onnx", true)) {
                onnxFile = file
                break
            }
        }

        var candidate = onnxFile?.parentFile?.canonicalFile
        while (candidate != null) {
            val candidatePath = candidate.toPath()
            if (!candidatePath.startsWith(stagingPath)) break
            if (File(candidate, "tokens.txt").isFile &&
                File(candidate, "espeak-ng-data").isDirectory
            ) {
                return candidate
            }
            if (candidatePath == stagingPath) break
            candidate = candidate.parentFile?.canonicalFile
        }
        return null
    }

    private fun copyDirectory(source: File, destination: File) {
        require(source.isDirectory) { "Исходная папка голоса не найдена" }
        destination.mkdirs()
        source.walkTopDown().forEach { file ->
            val relative = file.relativeTo(source).path
            val out = if (relative.isBlank()) destination else File(destination, relative)
            if (file.isDirectory) {
                out.mkdirs()
            } else {
                out.parentFile?.mkdirs()
                FileInputStream(file).use { input ->
                    FileOutputStream(out).use { output -> input.copyTo(output) }
                }
            }
        }
    }

    private fun extractTarBz2(archive: File, destination: File) {
        data class PendingLink(val path: String, val target: String, val directory: Boolean)
        val links = mutableListOf<PendingLink>()
        FileInputStream(archive).use { fis ->
            BZip2CompressorInputStream(fis).use { bz ->
                TarArchiveInputStream(bz).use { tar ->
                    var entry = tar.nextTarEntry
                    while (entry != null) {
                        val safeName = entry.name.replace('\\', '/').trimStart('/')
                        require(safeName.isNotBlank()) { "Пустой путь в архиве" }
                        require(!safeName.split('/').any { it == ".." }) { "Опасный путь в архиве" }
                        val out = File(destination, safeName)

                        when {
                            entry.isDirectory -> out.mkdirs()
                            entry.isSymbolicLink || entry.isLink -> {
                                val linkName = entry.linkName.replace('\\', '/').trimStart('/')
                                require(linkName.isNotBlank()) { "Пустая ссылка в архиве: $safeName" }
                                require(!linkName.split('/').any { it == ".." }) { "Опасная ссылка в архиве: $safeName" }
                                links += PendingLink(safeName, linkName, entry.isDirectory)
                            }
                            else -> {
                                out.parentFile?.mkdirs()
                                FileOutputStream(out).use { output -> tar.copyTo(output) }
                            }
                        }
                        entry = tar.nextTarEntry
                    }
                }
            }
        }

        // Materialize archive links as real files/directories. This keeps the
        // installed model self-contained and avoids Android filesystem symlink issues.
        var remaining = links.toMutableList()
        repeat(links.size + 2) {
            if (remaining.isEmpty()) return@repeat
            val next = mutableListOf<PendingLink>()
            for (link in remaining) {
                val out = File(destination, link.path)
                val target = File(destination, link.target)
                if (target.exists()) {
                    if (target.isDirectory) {
                        copyDirectory(target, out)
                    } else {
                        out.parentFile?.mkdirs()
                        FileInputStream(target).use { input ->
                            FileOutputStream(out).use { output -> input.copyTo(output) }
                        }
                    }
                } else {
                    next += link
                }
            }
            remaining = next
        }
        check(remaining.isEmpty()) { "Не удалось восстановить ссылки архива голоса" }
    }
}
