# MyAI Offline v0.8.1 — Neural Voice installation fix

This source package fixes the neural voice installer:

- downloads GitHub release archives with a User-Agent and longer read timeout;
- extracts into a staging directory instead of directly into the final voice folder;
- locates the actual Piper/Sherpa model root recursively;
- validates `.onnx`, `tokens.txt`, and `espeak-ng-data` before replacing an installed voice;
- keeps an already installed working voice if a new download/extraction fails;
- shows the installation error in Settings;
- refreshes the selected voice immediately after choosing it;
- bumps the Android app version to `0.8.1-neural-voice-fix-realme8`.

The voice model archives remain external to the APK.
