# MyAI Offline — v0.8.0 Neural Voice

Android offline-first assistant:
- Gemma 3 1B INT4 via LiteRT-LM 0.17.1
- neural Russian TTS via sherpa-onnx 1.13.8 + Piper voices
- four downloadable Russian voices: Ruslan, Dmitri, Denis, Irina
- voice archives are stored outside the APK and remain available offline after download
- CPU backend
- microphone input keeps Android on-device recognition when available

The LLM model is still external: import `gemma3-1b-it-int4.litertlm` from the app settings.

Neural TTS voices are downloaded from the sherpa-onnx TTS model releases. The app extracts the archive into its private `files/voices` directory.

### Important
The first v0.8 build adds neural TTS. The next stage can replace Android's speech recognizer with a dedicated Russian sherpa-onnx ASR model for fully independent offline speech input.

Implementation: `NeuralVoiceManager.kt` manages external neural voice archives.


## Вторая ветка

Экспериментальная ветка для полноценного локального AI-агента. Первый этап добавляет адаптивный профиль производительности и thermal-aware диагностику. Следующий этап — сменный GGUF/llama.cpp backend с реальным benchmark tokens/sec.

## Tool Manager

The second branch now has a native deterministic tool layer between user input and Android actions. Voice and text commands such as home/back, screen reading, text tap, scrolling, typing and opening selected apps do not depend on the LLM guessing Android APIs.

Potentially consequential external actions (dialer, SMS composer, email composer) require explicit confirmation and remain under user control.

The app also keeps a bounded local `action_log.json` for engineering diagnostics. It is stored outside the APK and is preserved by an in-place update with the same application identity/signing.


## Третья ветка — агентный рефакторинг

Третья ветка сохраняет версию `0.8.0-neural-voice-realme8` (versionCode 800) и не меняет пользовательские каталоги.

Текущая архитектура: `ChatViewModel → AgentLoop → ToolManager/ToolRegistry → Android/Memory`, с `Observation` и коротким `AgentTrace`. LLM-команды проходят строгую JSON-валидацию; детерминированные команды по-прежнему выполняются напрямую, без LLM.

Offline ASR остаётся основным голосовым входом, Neural/System TTS — выходом.
