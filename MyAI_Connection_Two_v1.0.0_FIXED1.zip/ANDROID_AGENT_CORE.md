# MyAI Offline — Android Agent Core

## Что добавлено в 0.8.0

### Android Agent
`AndroidAgent.kt` — локальный маршрутизатор безопасных команд. Он не требует LLM для простых действий.

Поддерживаются:
- `домой`
- `назад`
- `последние приложения`
- `уведомления`
- `открой настройки`
- `открой настройки телефона`
- `открой калькулятор`
- `открой браузер`
- `прочитай экран`
- `нажми <текст>`

### Accessibility bridge
`MyAiAccessibilityService.kt` предоставляет:
- Home / Back / Recents / Notifications
- чтение текста активного окна
- нажатие элемента по тексту
- tap по координатам

Служба должна быть включена пользователем в настройках Android.

### Архитектура

`ChatViewModel -> AndroidAgent -> AndroidControl tools`

Если команда не относится к Android-инструментам, она передаётся в локальную LiteRT-LM модель.

Следующий этап:
1. файловые инструменты;
2. заметки и долговременная локальная память;
3. tool-calling/планировщик;
4. локальный ASR;
5. локальный TTS;
6. coding engine и тестовый цикл.

## Tool Manager + Engineering layer

`ToolManager.kt` is now the single native command gateway. `MyAiIntentEngine.kt` converts ordinary Russian commands into deterministic tool IDs before any LLM call.

Current tool IDs include:
- `go_home`, `go_back`, `open_recents`, `open_notifications`;
- `read_screen`, `click_text`, `tap`, `scroll_forward`, `scroll_backward`, `type_text`;
- `open_settings`, `open_calculator`, `open_browser`, `open_camera`, `open_maps`;
- `open_telegram`, `open_whatsapp`, `open_youtube`, `open_chrome` when installed;
- `device_info`, `time`;
- `call`, `sms`, `email` with an explicit confirmation dialog before the system compose/dial screen is opened.

`ActionLog.kt` stores a capped local journal of tool calls, confirmations, GGUF events and errors. It is outside the APK so normal app updates keep it.

The Engineering Test includes a deterministic parser self-test, runtime GGUF/microphone/TTS checks, data-location checks and a journal export/clear UI.
