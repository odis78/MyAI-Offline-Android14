# MyAI Third Branch — RMX3085 release checklist

## Device / OS
- [ ] Device reports RMX3085 / realme 8
- [ ] Android version and API captured in Engineering Test
- [ ] At least 2 GB free storage before installing a new GGUF
- [ ] Battery optimisation reviewed for MyAI
- [ ] App allowed to run in background when voice testing

## Persistence / update-over
- [ ] Install APK over existing MyAI without uninstalling
- [ ] `filesDir/gguf_models` still contains selected GGUF
- [ ] `filesDir/voices` still contains downloaded neural voices
- [ ] `filesDir/asr_ru` still contains offline ASR
- [ ] `filesDir/memory` still contains notes/reminders
- [ ] `chat_history.json` still exists
- [ ] Accessibility service remains enabled or can be re-opened

## LLM
- [ ] Qwen GGUF loads
- [ ] Normal chat returns valid Russian text
- [ ] Agent JSON self-test passes
- [ ] Agent can open Settings
- [ ] Agent can read screen
- [ ] Agent can click a visible text element
- [ ] Agent can type into an editable field
- [ ] Agent can scroll
- [ ] Agent observes the screen after an action
- [ ] Observation diff is short enough for the model context
- [ ] Fuzzy click does not choose an ambiguous element
- [ ] `done=true` заканчивает агент раньше 4 шагов
- [ ] Agent stops after 4 steps
- [ ] Unknown tool is blocked
- [ ] Malformed JSON does not execute a tool

## Voice
- [ ] Offline ASR model is installed
- [ ] Offline ASR is the primary microphone path
- [ ] Android SpeechRecognizer is fallback only
- [ ] Russian speech produces text
- [ ] Voice command reaches the Agent Loop
- [ ] TTS speaks the final result
- [ ] Stop speaking works

## Thermal / performance
- [ ] Benchmark recorded at 1/2/4/6/8 threads
- [ ] Best thread profile saved for the selected GGUF
- [ ] Repeated agent tasks do not leave multiple native models loaded
- [ ] Thermal status recorded before/after a long test
- [ ] No ANR during repeated tasks

## Safety / confirmation
- [ ] Call opens dialer only after confirmation
- [ ] SMS opens composer only after confirmation
- [ ] Email opens composer only after confirmation
- [ ] Cancel closes the pending action without executing it

## Engineering report
- [ ] Parser self-test passes
- [ ] Agent protocol self-test passes
- [ ] Mic test passes
- [ ] TTS test passes
- [ ] Action log exported
- [ ] Final report archived before release
