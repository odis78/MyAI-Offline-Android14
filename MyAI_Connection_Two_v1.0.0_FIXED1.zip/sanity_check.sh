#!/usr/bin/env bash
set -euo pipefail

chmod +x ./gradlew sanity_check.sh
test -x ./gradlew
python3 -c 'import xml.etree.ElementTree as ET; ET.parse("app/src/main/AndroidManifest.xml")'
grep -q 'id("com.android.application") version "8.6.1"' build.gradle.kts
grep -q 'id("org.jetbrains.kotlin.android") version "2.4.10"' build.gradle.kts
grep -q 'litertlm-android:0.17.1' app/build.gradle.kts
grep -q 'sherpa-onnx:sherpa-onnx:v1.13.8' app/build.gradle.kts
grep -q 'https://jitpack.io' settings.gradle.kts
grep -q 'versionCode = 800' app/build.gradle.kts
grep -q 'versionName = "0.8.0-neural-voice-realme8"' app/build.gradle.kts
grep -q 'NeuralVoiceManager.kt' README.md
test -f app/src/main/java/com/dmitry/myai/NeuralVoiceManager.kt
test -f app/src/main/java/com/dmitry/myai/NeuralTtsController.kt
! grep -Rqs 'kotlinOptions' app build.gradle.kts
! grep -qs 'versionCode = 700' app/build.gradle.kts
! grep -qs 'FIXED' README.md app/build.gradle.kts settings.gradle.kts
! grep -qs '\.text' app/src/main/java/com/dmitry/myai/LocalAiEngine.kt

test -f app/src/main/java/com/dmitry/myai/AgentToolSchema.kt
test -f app/src/main/java/com/dmitry/myai/AgentToolParser.kt
test -f app/src/main/java/com/dmitry/myai/MemoryStore.kt
! grep -qs 'runAgentLoop' app/src/main/java/com/dmitry/myai/ChatViewModel.kt
grep -q 'agentLoop.run' app/src/main/java/com/dmitry/myai/ChatViewModel.kt
grep -q 'AgentToolSchema.allowedArgs' app/src/main/java/com/dmitry/myai/AgentToolParser.kt
grep -q 'openSession' app/src/main/java/com/dmitry/myai/LlamaEngine.kt
grep -q 'inferenceSettings' app/src/main/java/com/dmitry/myai/RealmePerformanceProfile.kt
grep -q 'waitForText' app/src/main/java/com/dmitry/myai/MyAiAccessibilityService.kt
grep -q 'activePackage' app/src/main/java/com/dmitry/myai/MyAiAccessibilityService.kt
grep -q 'preferredThreads(model' app/src/main/java/com/dmitry/myai/GgufModelManager.kt
grep -q 'android.permission.VIBRATE' app/src/main/AndroidManifest.xml

echo "MyAI v0.8 sanity check: OK"

# Second Branch LLM benchmark files
test -f app/src/main/java/com/dmitry/myai/LlamaEngine.kt
test -f app/src/main/java/com/dmitry/myai/GgufModelManager.kt
grep -q 'dev.ffmpegkit-maintained:llama-android:0.1.1' app/build.gradle.kts
grep -q 'tokensPerSecond' app/src/main/java/com/dmitry/myai/LlamaEngine.kt
grep -q 'EXTRA_PREFER_OFFLINE' app/src/main/java/com/dmitry/myai/VoiceController.kt
grep -q 'isOnDeviceRecognitionAvailable' app/src/main/java/com/dmitry/myai/VoiceController.kt
grep -q 'assistantReplies' app/src/main/java/com/dmitry/myai/ChatViewModel.kt
grep -q 'auto_speak' app/src/main/java/com/dmitry/myai/VoiceController.kt
grep -q 'putFloat("speed"' app/src/main/java/com/dmitry/myai/NeuralTtsController.kt
test -f app/src/main/java/com/dmitry/myai/OfflineAsrManager.kt
test -f app/src/main/java/com/dmitry/myai/OfflineAsrController.kt
grep -q 'sherpa-onnx-small-zipformer-ru-2024-09-18' app/src/main/java/com/dmitry/myai/OfflineAsrManager.kt
grep -q 'OnlineRecognizer' app/src/main/java/com/dmitry/myai/OfflineAsrController.kt

# Tool Manager / Engineering layer
chmod +x ./gradlew sanity_check.sh
test -f app/src/main/java/com/dmitry/myai/MyAiIntentEngine.kt
test -f app/src/main/java/com/dmitry/myai/ToolManager.kt
test -f app/src/main/java/com/dmitry/myai/ActionLog.kt
grep -q 'pendingConfirmation' app/src/main/java/com/dmitry/myai/ChatViewModel.kt
grep -q 'WAITING_CONFIRMATION' app/src/main/java/com/dmitry/myai/ChatViewModel.kt
grep -q 'scroll_internal\|scroll(forward' app/src/main/java/com/dmitry/myai/MyAiAccessibilityService.kt || grep -q 'scrollInternal' app/src/main/java/com/dmitry/myai/MyAiAccessibilityService.kt
grep -q 'typeTextInternal' app/src/main/java/com/dmitry/myai/MyAiAccessibilityService.kt
grep -q 'parserSelfTest' app/src/main/java/com/dmitry/myai/EngineeringDiagnostics.kt
grep -q 'Журнал действий MyAI' app/src/main/java/com/dmitry/myai/MainActivity.kt
grep -q 'Подтвердить' app/src/main/java/com/dmitry/myai/MainActivity.kt

# Third Branch agent hardening
grep -q 'MAX_TRACE_ITEMS' app/src/main/java/com/dmitry/myai/AgentToolSchema.kt
grep -q 'done=true' app/src/main/java/com/dmitry/myai/AgentToolSchema.kt
grep -q 'allowedTopLevel' app/src/main/java/com/dmitry/myai/AgentToolParser.kt
grep -q 'Финальный answer должен иметь done=true' app/src/main/java/com/dmitry/myai/AgentToolParser.kt
! grep -qs 'screenDiff' app/src/main/java/com/dmitry/myai/ChatViewModel.kt
grep -q 'focusedEditableText' app/src/main/java/com/dmitry/myai/ToolManager.kt app/src/main/java/com/dmitry/myai/MyAiAccessibilityService.kt
grep -q 'findFuzzyText' app/src/main/java/com/dmitry/myai/MyAiAccessibilityService.kt

# Third Branch refactor architecture
test -f app/src/main/java/com/dmitry/myai/AgentLoop.kt
test -f app/src/main/java/com/dmitry/myai/AgentTrace.kt
test -f app/src/main/java/com/dmitry/myai/Observation.kt
test -f app/src/main/java/com/dmitry/myai/ToolRegistry.kt
grep -q 'AgentLoop(' app/src/main/java/com/dmitry/myai/ChatViewModel.kt
grep -q 'ToolRegistry().apply' app/src/main/java/com/dmitry/myai/ToolManager.kt
grep -q 'registry.execute' app/src/main/java/com/dmitry/myai/ToolManager.kt
grep -q 'ToolRegistry.all()' app/src/main/java/com/dmitry/myai/AgentToolSchema.kt
grep -q 'hasFocusedEditable' app/src/main/java/com/dmitry/myai/MyAiAccessibilityService.kt
grep -q 'Observation(' app/src/main/java/com/dmitry/myai/AgentLoop.kt
