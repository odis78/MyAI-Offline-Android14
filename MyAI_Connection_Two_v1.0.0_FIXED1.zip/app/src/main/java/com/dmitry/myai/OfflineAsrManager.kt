package com.dmitry.myai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** One-time Russian streaming ASR model stored outside the APK. */
class OfflineAsrManager(private val context: Context) {
    companion object {
        const val MODEL_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-small-zipformer-ru-2024-09-18.tar.bz2"
        private const val MODEL_DIR_NAME = "sherpa-onnx-small-zipformer-ru-2024-09-18"
    }

    private val root = File(context.filesDir, "asr_ru").apply { mkdirs() }
    private val modelDir = File(root, MODEL_DIR_NAME)

    fun modelDir(): File = modelDir
    fun isInstalled(): Boolean = modelDir.isDirectory &&
        File(modelDir, "encoder.int8.onnx").isFile &&
        File(modelDir, "decoder.onnx").isFile &&
        File(modelDir, "joiner.int8.onnx").isFile &&
        File(modelDir, "tokens.txt").isFile

    suspend fun download(onProgress: (Int, String) -> Unit = { _, _ -> }) = withContext(Dispatchers.IO) {
        if (isInstalled()) {
            onProgress(100, "Офлайн-распознавание уже установлено")
            return@withContext
        }
        require(context.filesDir.usableSpace > 400L * 1024L * 1024L) {
            "Нужно минимум 400 MB свободного места для офлайн-распознавания"
        }
        val tmp = File(root, "model.tar.bz2.part")
        val archive = File(root, "model.tar.bz2")
        val staging = File(root, ".extract")
        tmp.delete(); archive.delete(); staging.deleteRecursively(); staging.mkdirs()

        val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 120_000
            requestMethod = "GET"
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "MyAI-Offline/0.8.0")
        }
        try {
            onProgress(0, "Подключение к архиву ASR…")
            connection.connect()
            require(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }
            val total = connection.contentLengthLong
            connection.inputStream.use { input ->
                FileOutputStream(tmp).use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var copied = 0L
                    var last = -1
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        copied += n
                        if (total > 0) {
                            val p = (copied * 100L / total).toInt().coerceIn(0, 100)
                            if (p != last) { last = p; onProgress(p, "Скачивание ASR…") }
                        }
                    }
                    output.fd.sync()
                }
            }
            require(tmp.length() > 0) { "Пустой архив ASR" }
            check(tmp.renameTo(archive)) { "Не удалось сохранить архив ASR" }
            onProgress(100, "Распаковка ASR…")
            extractTarBz2(archive, staging, onProgress)
            val extracted = staging.walkTopDown().firstOrNull { it.isDirectory && it.name == MODEL_DIR_NAME }
                ?: error("Папка русской ASR-модели не найдена")
            modelDir.deleteRecursively()
            check(extracted.renameTo(modelDir)) { "Не удалось установить ASR-модель" }
            check(isInstalled()) { "ASR-модель установлена неполностью" }
            onProgress(100, "Офлайн-распознавание установлено")
        } catch (e: Exception) {
            tmp.delete(); archive.delete(); staging.deleteRecursively()
            throw IllegalStateException("Не удалось установить офлайн-распознавание: ${e.message ?: e.javaClass.simpleName}", e)
        } finally {
            connection.disconnect()
            tmp.delete(); archive.delete(); staging.deleteRecursively()
        }
    }

    private fun extractTarBz2(archive: File, destination: File, onProgress: (Int, String) -> Unit) {
        FileInputStream(archive).use { fis ->
            BZip2CompressorInputStream(fis).use { bz ->
                TarArchiveInputStream(bz).use { tar ->
                    var entry = tar.nextTarEntry
                    var count = 0
                    while (entry != null) {
                        val safeName = entry.name.replace('\\', '/').trimStart('/')
                        require(safeName.isNotBlank() && !safeName.split('/').contains("..")) { "Опасный путь в ASR-архиве" }
                        val out = File(destination, safeName)
                        val base = destination.canonicalFile.toPath()
                        require(out.canonicalFile.toPath().startsWith(base)) { "Опасный путь в ASR-архиве" }
                        if (entry.isDirectory) {
                            out.mkdirs()
                        } else if (!entry.isSymbolicLink && !entry.isLink) {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { output -> tar.copyTo(output) }
                        }
                        count++
                        if (count % 20 == 0) onProgress(100, "Распаковка ASR: $count файлов")
                        entry = tar.nextTarEntry
                    }
                }
            }
        }
    }
}
