package com.dmitry.myai

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import android.os.Build
import java.io.File

/**
 * Read-only engineering diagnostics plus deterministic parser self-tests.
 * Runtime actions (GGUF/TTS/microphone) are still started explicitly from UI.
 */
class EngineeringDiagnostics(private val context: Context) {
    data class Check(val name: String, val ok: Boolean, val detail: String)

    fun runChecks(): List<Check> {
        val gguf = GgufModelManager(context)
        val voice = NeuralVoiceManager(context)
        val asr = OfflineAsrManager(context)
        val am = context.getSystemService(ActivityManager::class.java)
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val accessibility = accessibilityEnabled()
        val mic = context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val tts = runCatching {
            val engines = context.packageManager.queryIntentServices(
                android.content.Intent(android.speech.tts.TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE),
                0
            )
            engines.isNotEmpty()
        }.getOrDefault(false)
        val parser = parserSelfTest()
        val registry = registrySelfTest()
        val agent = agentProtocolSelfTest()
        val memoryDir = File(context.filesDir, "memory")
        val selectedGguf = gguf.selectedModel()
        val profileOk = selectedGguf == null || gguf.preferredThreads(selectedGguf) in 1..8

        return listOf(
            Check("Приложение", true, "MyAI ${BuildConfig.VERSION_NAME}, API ${Build.VERSION.SDK_INT}"),
            Check("Данные приложения", context.filesDir.isDirectory, context.filesDir.absolutePath),
            Check("Tool Manager", parser.first && registry.first, parser.second + " | " + registry.second),
            Check("Agent Protocol", agent.first, agent.second),
            Check("GGUF", gguf.selectedModel() != null, gguf.selectedModel()?.let { "Выбрана ${it.name} (${it.length() / 1_048_576} MB)" } ?: "GGUF-модель не выбрана"),
            Check("Neural Voice", voice.selected() != null, voice.selected()?.title ?: "Нейронный голос не выбран; доступен системный TTS"),
            Check("Офлайн ASR", asr.isInstalled(), if (asr.isInstalled()) "Модель установлена" else "Модель не установлена"),
            Check("Микрофон", mic, if (mic) "RECORD_AUDIO разрешён" else "RECORD_AUDIO не разрешён"),
            Check("Accessibility", accessibility, if (accessibility) "Служба управления телефоном включена" else "Служба управления телефоном выключена"),
            Check("System TTS", tts, if (tts) "TTS engine найден" else "TTS engine не найден"),
            Check("Свободная RAM", mem.availMem > 300L * 1024L * 1024L, "${mem.availMem / 1_048_576} MB свободно из ${mem.totalMem / 1_048_576} MB"),
            Check("Свободное место", context.filesDir.freeSpace > 500L * 1024L * 1024L, "${context.filesDir.freeSpace / 1_048_576} MB свободно"),
            Check("Локальная память", memoryDir.exists() || memoryDir.mkdirs(), memoryDir.absolutePath),
            Check("Профиль GGUF", profileOk, selectedGguf?.let { "Потоки: ${gguf.preferredThreads(it)} для ${it.name}" } ?: "GGUF не выбрана")
        )
    }

    fun parserSelfTest(): Pair<Boolean, String> {
        val cases = listOf(
            "домой" to "go_home",
            "назад" to "go_back",
            "последние приложения" to "open_recents",
            "уведомления" to "open_notifications",
            "прочитай экран" to "read_screen",
            "найди на экране Настройки и нажми" to "click_text",
            "нажми координаты 100 200" to "tap",
            "прокрути вниз" to "scroll_forward",
            "прокрути вверх" to "scroll_backward",
            "введи привет" to "type_text",
            "открой настройки" to "open_settings",
            "открой калькулятор" to "open_calculator",
            "открой Telegram" to "open_telegram",
            "открой почту" to "open_email",
            "позвони +79001234567" to "call",
            "смс на +79001234567 «Привет»" to "sms",
            "напиши письмо на test@example.com «Тест»" to "email",
            "запиши в заметку купить молоко" to "save_note",
            "напомни завтра купить масло" to "create_reminder",
            "проанализируй текст это тест" to "analyze_text",
            "вибрируй" to "vibrate",
            "поделись этим текстом" to "share_text",
        )
        val bad = cases.filter { (command, expected) ->
            val intent = MyAiIntentEngine.parse(command)
            MyAiIntentEngine.toolId(intent) != expected
        }
        return if (bad.isEmpty()) {
            true to "${cases.size} команд распознаны детерминированно"
        } else {
            false to "Ошибки парсера: ${bad.joinToString { "${it.first} → ${MyAiIntentEngine.toolId(MyAiIntentEngine.parse(it.first))}, нужно ${it.second}" }}"
        }
    }


    fun registrySelfTest(): Pair<Boolean, String> {
        val descriptors = ToolRegistry.all()
        val canonical = ToolRegistry.names()
        val sanity = runCatching { ToolRegistry.selfTest() }.getOrElse { return false to "Ошибка реестра: ${it.message}" }
        val manager = ToolManager(context)
        val missing = canonical - manager.registeredToolNames()
        return if (sanity.size == canonical.size && missing.isEmpty()) {
            true to "Реестр: ${descriptors.size}/${descriptors.size} tools зарегистрированы"
        } else {
            false to "Реестр tools неполный: отсутствуют ${missing.joinToString()}"
        }
    }
    fun agentProtocolSelfTest(): Pair<Boolean, String> {
        val good = runCatching {
            val d = AgentToolParser.parse("{\"tool\":\"go_home\",\"args\":{}}")
            d.tool == "go_home"
        }.getOrDefault(false)
        val answer = runCatching {
            val d = AgentToolParser.parse("{\"done\":true,\"answer\":\"Готово\"}")
            d.tool == null && d.answer == "Готово" && d.done
        }.getOrDefault(false)
        val blocked = runCatching { AgentToolParser.parse("{\"tool\":\"delete_everything\",\"args\":{}}") }.isFailure
        val argsBlocked = runCatching { AgentToolParser.parse("{\"tool\":\"tap\",\"args\":{\"x\":-1,\"y\":2}}") }.isFailure
        val plainTextBlocked = runCatching { AgentToolParser.parse("Просто сделано") }.isFailure
        val malformedBlocked = runCatching { AgentToolParser.parse("{\"tool\":\"go_home\"") }.isFailure
        val answerWithoutDoneBlocked = runCatching { AgentToolParser.parse("{\"answer\":\"Готово\",\"done\":false}") }.isFailure
        val wrongTypeBlocked = runCatching { AgentToolParser.parse("{\"tool\":\"tap\",\"args\":{\"x\":\"100\",\"y\":200}}") }.isFailure
        val unknownFieldBlocked = runCatching { AgentToolParser.parse("{\"tool\":\"go_home\",\"extra\":1}") }.isFailure
        return if (good && answer && blocked && argsBlocked && plainTextBlocked && malformedBlocked && answerWithoutDoneBlocked && wrongTypeBlocked && unknownFieldBlocked) {
            true to "JSON tool-протокол, done, строгий парсер и защита типов аргументов работают"
        } else {
            false to "Ошибка JSON tool-протокола/валидатора"
        }
    }

    private fun accessibilityEnabled(): Boolean {
        val expected = "${context.packageName}/${MyAiAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    fun dataLocations(): List<Pair<String, File>> = listOf(
        "GGUF" to File(context.filesDir, "gguf_models"),
        "Голоса" to File(context.filesDir, "voices"),
        "ASR" to File(context.filesDir, "asr_ru"),
        "LiteRT модели" to File(context.filesDir, "models"),
        "История" to File(context.filesDir, "chat_history.json"),
        "Журнал действий" to File(context.filesDir, "action_log.json"),
        "Память/заметки" to File(context.filesDir, "memory"),
    )
}
