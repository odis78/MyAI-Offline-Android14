package com.dmitry.myai

/** Short-lived working trace for one agent task. */
class AgentTrace(private val maxItems: Int = AgentToolSchema.MAX_TRACE_ITEMS) {
    private val items = ArrayDeque<String>()

    fun add(text: String) {
        if (items.size >= maxItems) items.removeFirst()
        items.addLast(text.take(900))
    }

    fun snapshot(): List<String> = items.toList()
    fun prompt(): String = snapshot().joinToString("\n").ifBlank { "пусто" }
}
