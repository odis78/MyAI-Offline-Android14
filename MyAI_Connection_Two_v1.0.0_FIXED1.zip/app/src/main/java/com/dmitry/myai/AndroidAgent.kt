package com.dmitry.myai

import android.content.Context

/**
 * Compatibility facade kept for existing callers.
 * The actual command routing now lives in ToolManager.
 */
class AndroidAgent(context: Context) {
    private val tools = ToolManager(context)

    fun execute(text: String): String? {
        val result = tools.execute(text)
        return if (result.handled) {
            if (result.pending != null) result.message else result.message
        } else null
    }
}
