package com.dmitry.myai

import java.util.Locale

/**
 * Deterministic fast-path intent parser. Clear device commands are handled
 * without asking a small local LLM to guess an Android API.
 */
object MyAiIntentEngine {
    sealed class Intent {
        data object Help : Intent()
        data object Home : Intent()
        data object Back : Intent()
        data object Recents : Intent()
        data object Notifications : Intent()
        data object ReadScreen : Intent()
        data class ClickText(val text: String) : Intent()
        data class Tap(val x: Float, val y: Float) : Intent()
        data class Scroll(val forward: Boolean) : Intent()
        data class TypeText(val text: String) : Intent()
        data class Open(val target: Target, val query: String? = null) : Intent()
        data object Device : Intent()
        data object Time : Intent()
        data class Call(val number: String) : Intent()
        data class Sms(val number: String?, val body: String) : Intent()
        data class Email(val to: String?, val subject: String?, val body: String) : Intent()
        data class Note(val title: String, val body: String) : Intent()
        data class Reminder(val title: String, val whenLabel: String) : Intent()
        data class Analyze(val text: String) : Intent()
        data object Vibrate : Intent()
        data class Share(val text: String) : Intent()
        data object Unknown : Intent()
    }

    enum class Target { SETTINGS, CALCULATOR, BROWSER, CAMERA, MAPS, TELEGRAM, WHATSAPP, YOUTUBE, CHROME, EMAIL }

    private val phoneRe = Regex("(?:\\+?\\d[\\d\\s()\\-]{8,18}\\d)")
    private val emailRe = Regex("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", RegexOption.IGNORE_CASE)

    fun parse(raw: String): Intent {
        val text = raw.trim()
        if (text.isBlank()) return Intent.Unknown
        val low = text.lowercase(Locale.getDefault())
            .replaceFirst(Regex("^(пожалуйста[, ]*|можешь[ ,]+|можешь ли[ ,]+)"), "")
            .trim()

        return when {
            low.matches(Regex("^(помощь|что ты умеешь|что умеешь|команды|help)$")) -> Intent.Help
            low == "домой" || low == "на главный экран" || low.contains("перейди на главный экран") -> Intent.Home
            low == "назад" || low == "вернись назад" || low.contains("нажми назад") -> Intent.Back
            low.contains("последние приложения") || low.contains("открой последние") -> Intent.Recents
            low.contains("уведомления") || low.contains("открой шторку") -> Intent.Notifications
            low.startsWith("прочитай экран") || low.startsWith("прочитай мне экран") ||
                low.startsWith("что сейчас на экране") || low.startsWith("что на экране") ||
                low == "прочитай что на экране" -> Intent.ReadScreen
            low.startsWith("найди на экране ") -> Intent.ClickText(cleanTarget(extractFindTarget(text)))
            low.matches(Regex("^(тап|tap|нажми координаты)\\s+[-+]?\\d+(?:[.,]\\d+)?\\s+[-+]?\\d+(?:[.,]\\d+)?$")) -> parseTap(text)
            low.startsWith("найди ") -> Intent.ClickText(cleanTarget(extractFindTarget(text)))
            low.startsWith("нажми ") -> Intent.ClickText(cleanTarget(text.substringAfter("нажми ").trim()))
            low.contains("прокрути вниз") || low.contains("пролистай вниз") || low.contains("вниз по экрану") -> Intent.Scroll(true)
            low.contains("прокрути вверх") || low.contains("пролистай вверх") || low.contains("вверх по экрану") -> Intent.Scroll(false)
            low.startsWith("введи ") || low.startsWith("ввести ") -> Intent.TypeText(text.substringAfter(' ').trim())

            low.contains("напомин") || low.startsWith("напомни ") -> {
                val title = after(text, Regex("напомн\\w*", RegexOption.IGNORE_CASE)).ifBlank { text }
                val whenLabel = Regex("(сегодня|завтра|утром|вечером|через\\s+\\d+\\s*\\w+|\\d{1,2}:\\d{2})", RegexOption.IGNORE_CASE)
                    .find(low)?.value ?: "позже"
                Intent.Reminder(title, whenLabel)
            }
            low.contains("заметк") || low.startsWith("запиши ") || low.startsWith("запомни ") -> {
                val body = after(text, Regex("(заметк\\w*|запиши|запомни)\\s*(что)?", RegexOption.IGNORE_CASE)).ifBlank { text }
                val title = body.split(Regex("[.!?\\n]"), limit = 2).firstOrNull()?.take(80).orEmpty().ifBlank { "Заметка" }
                Intent.Note(title, body)
            }
            low.startsWith("проанализируй ") || low.startsWith("проанализируй текст ") || low.startsWith("разбери текст ") ->
                Intent.Analyze(after(text, Regex("(проанализируй|проанализируй текст|разбери текст)\\s*", RegexOption.IGNORE_CASE)).ifBlank { text })
            low == "вибрация" || low == "вибрируй" || low.contains("вибрацию") -> Intent.Vibrate
            low.startsWith("поделись ") || low.startsWith("поделиться ") ->
                Intent.Share(after(text, Regex("(поделись|поделиться)\\s*", RegexOption.IGNORE_CASE)).ifBlank { text })

            low.contains("который час") || low.contains("сколько времени") -> Intent.Time
            low.contains("позвони") || low.contains("набери") || low.contains("вызови") || low.contains("call") || low.contains("dial") ->
                Intent.Call(phoneRe.find(text)?.value?.replace(Regex("[^+\\d]"), "") ?: "")
            low.contains("смс") || low.contains("sms") || low.contains("сообщение") ->
                Intent.Sms(phoneRe.find(text)?.value?.replace(Regex("[^+\\d]"), ""), quoted(text) ?: after(text, Regex("(смс|sms|сообщение)\\s*(на|для)?", RegexOption.IGNORE_CASE)))
            low.startsWith("открой почту") || low.startsWith("открыть почту") || low.startsWith("запусти почту") -> Intent.Open(Target.EMAIL)
            low.contains("почта") || low.contains("email") || low.contains("e-mail") || low.contains("письмо на") ->
                Intent.Email(emailRe.find(text)?.value, quoted(text), after(text, Regex("(письмо|email|почта|почту)\\s*(на|для)?", RegexOption.IGNORE_CASE)))
            low.contains("батаре") || low.contains("заряд") || low.contains("память") || low.contains("устройство") ||
                low.contains("температур") || low.contains("wifi") || low.contains("wi-fi") -> Intent.Device
            low.startsWith("открой ") || low.startsWith("открыть ") || low.startsWith("запусти ") || low.startsWith("open ") -> parseOpen(text, low)
            else -> Intent.Unknown
        }
    }

    fun toolId(intent: Intent): String = when (intent) {
        Intent.Help -> "help"
        Intent.Home -> "go_home"
        Intent.Back -> "go_back"
        Intent.Recents -> "open_recents"
        Intent.Notifications -> "open_notifications"
        Intent.ReadScreen -> "read_screen"
        is Intent.ClickText -> "click_text"
        is Intent.Tap -> "tap"
        is Intent.Scroll -> "scroll_${if (intent.forward) "forward" else "backward"}"
        is Intent.TypeText -> "type_text"
        is Intent.Open -> "open_${intent.target.name.lowercase(Locale.US)}"
        Intent.Device -> "device_info"
        Intent.Time -> "time"
        is Intent.Call -> "call"
        is Intent.Sms -> "sms"
        is Intent.Email -> "email"
        is Intent.Note -> "save_note"
        is Intent.Reminder -> "create_reminder"
        is Intent.Analyze -> "analyze_text"
        Intent.Vibrate -> "vibrate"
        is Intent.Share -> "share_text"
        Intent.Unknown -> "unknown"
    }

    private fun parseTap(text: String): Intent {
        val parts = Regex("[-+]?\\d+(?:[.,]\\d+)?").findAll(text).map { it.value.replace(',', '.').toFloat() }.toList()
        return if (parts.size >= 2) Intent.Tap(parts[0], parts[1]) else Intent.Unknown
    }

    private fun parseOpen(text: String, low: String): Intent = when {
        low.contains("настройк") -> Intent.Open(Target.SETTINGS)
        low.contains("калькулятор") -> Intent.Open(Target.CALCULATOR)
        low.contains("браузер") -> Intent.Open(Target.BROWSER)
        low.contains("chrome") -> Intent.Open(Target.CHROME)
        low.contains("камер") -> Intent.Open(Target.CAMERA)
        low.contains("карт") -> Intent.Open(Target.MAPS, after(text, Regex("карт\\w*", RegexOption.IGNORE_CASE)).ifBlank { null })
        low.contains("telegram") || low.contains("телеграм") -> Intent.Open(Target.TELEGRAM)
        low.contains("whatsapp") || low.contains("ватсап") -> Intent.Open(Target.WHATSAPP)
        low.contains("youtube") || low.contains("ютуб") -> Intent.Open(Target.YOUTUBE)
        else -> Intent.Unknown
    }

    private fun extractFindTarget(text: String): String {
        var value = text.replaceFirst(Regex("^найди(?:\\s+на\\s+экране)?\\s*", RegexOption.IGNORE_CASE), "").trim()
        value = value.replaceFirst(Regex("\\s+и\\s+нажми\\s*$", RegexOption.IGNORE_CASE), "").trim()
        return value
    }

    private fun quoted(text: String): String? = Regex("[«\"]([^»\"]+)[»\"]").find(text)?.groupValues?.getOrNull(1)?.trim()

    private fun after(text: String, re: Regex): String {
        val m = re.find(text) ?: return text.trim()
        return text.substring((m.range.last + 1).coerceAtMost(text.length)).trim().replace(Regex("^[:\\-\\s]+"), "")
    }

    private fun cleanTarget(value: String): String {
        var v = value.trim().replaceFirst(Regex("^(кнопку|кнопка|элемент|значок)\\s+", RegexOption.IGNORE_CASE), "")
        if (v.length >= 2 && ((v.first() == '"' && v.last() == '"') || (v.first() == '«' && v.last() == '»') || (v.first() == '\'' && v.last() == '\''))) {
            v = v.substring(1, v.length - 1).trim()
        }
        return v
    }
}
