package com.dmitry.myai

import org.json.JSONObject

/**
 * Canonical registry for the LLM-visible tools.
 * The descriptors are static; each ToolManager instance registers its runtime handlers.
 */
class ToolRegistry {
    data class Descriptor(
        val name: String,
        val description: String,
        val allowedArgs: Set<String> = emptySet()
    )

    private val handlers = linkedMapOf<String, (JSONObject) -> ToolManager.Result>()

    fun register(name: String, handler: (JSONObject) -> ToolManager.Result) {
        require(descriptorsByName.containsKey(name)) { "Нельзя зарегистрировать неизвестный tool: $name" }
        require(handlers.put(name, handler) == null) { "Tool уже зарегистрирован: $name" }
    }

    fun registerAll(vararg entries: Pair<String, (JSONObject) -> ToolManager.Result>) {
        entries.forEach { register(it.first, it.second) }
    }

    fun execute(name: String, args: JSONObject): ToolManager.Result? = handlers[name]?.invoke(args)
    fun registeredNames(): Set<String> = handlers.keys

    companion object {
        private val descriptors = listOf(
            Descriptor("go_home", "перейти на главный экран"),
            Descriptor("go_back", "вернуться назад"),
            Descriptor("open_recents", "открыть последние приложения"),
            Descriptor("open_notifications", "открыть уведомления/шторку"),
            Descriptor("read_screen", "прочитать текущий экран"),
            Descriptor("click_text", "найти текст на экране и нажать его; args: text", setOf("text")),
            Descriptor("tap", "нажать по координатам; args: x,y", setOf("x", "y")),
            Descriptor("scroll_forward", "прокрутить вниз"),
            Descriptor("scroll_backward", "прокрутить вверх"),
            Descriptor("type_text", "ввести текст в активное поле; args: text", setOf("text")),
            Descriptor("wait_for_text", "ждать появления текста; args: text", setOf("text")),
            Descriptor("wait_idle", "подождать обновление интерфейса"),
            Descriptor("open_settings", "открыть настройки Android"),
            Descriptor("open_calculator", "открыть калькулятор"),
            Descriptor("open_browser", "открыть браузер; args: query?", setOf("query")),
            Descriptor("open_chrome", "открыть Chrome"),
            Descriptor("open_camera", "открыть камеру"),
            Descriptor("open_maps", "открыть карты; args: query?", setOf("query")),
            Descriptor("open_telegram", "открыть Telegram"),
            Descriptor("open_whatsapp", "открыть WhatsApp"),
            Descriptor("open_youtube", "открыть YouTube"),
            Descriptor("open_email", "открыть почту"),
            Descriptor("open_url", "открыть http/https URL; args: url", setOf("url")),
            Descriptor("device_info", "получить состояние устройства"),
            Descriptor("time", "получить текущую дату и время"),
            Descriptor("call", "открыть набор номера; args: number; требует подтверждения", setOf("number")),
            Descriptor("sms", "подготовить SMS; args: number?, body; требует подтверждения", setOf("number", "body")),
            Descriptor("email", "подготовить письмо; args: to?, subject?, body; требует подтверждения", setOf("to", "subject", "body")),
            Descriptor("save_note", "сохранить локальную заметку; args: title?, body", setOf("title", "body")),
            Descriptor("search_notes", "найти локальные заметки; args: query", setOf("query")),
            Descriptor("create_reminder", "сохранить локальное напоминание; args: title, when?", setOf("title", "when")),
            Descriptor("analyze_text", "локально посчитать характеристики текста; args: text", setOf("text")),
            Descriptor("vibrate", "коротко вибрировать; args: ms?", setOf("ms")),
            Descriptor("share_text", "открыть системное окно поделиться; args: title?, text", setOf("title", "text"))
        )
        private val descriptorsByName = descriptors.associateBy { it.name }

        fun all(): List<Descriptor> = descriptors
        fun names(): Set<String> = descriptorsByName.keys
        fun descriptor(name: String): Descriptor? = descriptorsByName[name.trim()]
        fun allowedArgs(name: String): Set<String> = descriptor(name)?.allowedArgs.orEmpty()

        fun selfTest(): List<String> = buildList {
            require(descriptors.map { it.name }.distinct().size == descriptors.size) { "duplicate tool names" }
            descriptors.forEach {
                require(it.name.matches(Regex("[a-z0-9_]+"))) { "invalid tool name: ${it.name}" }
                require(it.description.isNotBlank()) { "empty description: ${it.name}" }
                add(it.name)
            }
        }
    }
}
