package com.dmitry.myai

import android.content.Context
import android.os.Build
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast

/**
 * Voice input + offline neural TTS.
 * Primary input is the local sherpa-onnx recognizer once its model is installed.
 * Android SpeechRecognizer is a fallback only when local ASR is unavailable or fails to start.
 */
class VoiceController(private val context: Context) : RecognitionListener {
    private var recognizer: SpeechRecognizer? = null
    private var onResult: ((String) -> Unit)? = null
    private var onState: ((String) -> Unit)? = null
    private val neuralTts = NeuralTtsController(context)
    private val offlineAsrManager = OfflineAsrManager(context)
    private val offlineAsr = OfflineAsrController(offlineAsrManager)
    private val prefs = context.getSharedPreferences("voice", Context.MODE_PRIVATE)

    fun tts(): NeuralTtsController = neuralTts
    fun offlineAsrManager(): OfflineAsrManager = offlineAsrManager

    fun autoSpeakEnabled(): Boolean = prefs.getBoolean("auto_speak", true)

    fun setAutoSpeakEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("auto_speak", enabled).apply()
    }

    fun startListening(result: (String) -> Unit, state: (String) -> Unit = {}) {
        onResult = result
        onState = state
        if (offlineAsr.isInstalled()) {
            offlineAsr.start(result, state) {
                // If the native local recorder/model cannot start on an OEM build,
                // immediately fall back to Android's recognizer instead of leaving
                // the microphone apparently dead.
                startSystemRecognition(result, state)
            }
            return
        }
        startSystemRecognition(result, state)
    }

    private fun startSystemRecognition(result: (String) -> Unit, state: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            state("Распознавание речи недоступно на устройстве")
            Toast.makeText(context, "Распознавание речи недоступно", Toast.LENGTH_LONG).show()
            return
        }

        recognizer?.destroy()
        recognizer = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context)) {
            state("Офлайн-распознавание Android — говорите")
            SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
        } else {
            state("Распознавание Android — говорите")
            SpeechRecognizer.createSpeechRecognizer(context)
        }

        recognizer?.setRecognitionListener(this)
        val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        }
        try {
            recognizer?.startListening(intent)
        } catch (e: Throwable) {
            state("Ошибка запуска микрофона: ${e.message ?: "неизвестная"}")
            Toast.makeText(context, "Не удалось запустить микрофон", Toast.LENGTH_LONG).show()
        }
    }

    fun stopListening() {
        offlineAsr.stop()
        runCatching { recognizer?.stopListening() }
        onState?.invoke("Микрофон остановлен")
    }

    override fun onReadyForSpeech(params: android.os.Bundle?) {
        onState?.invoke("🎤 Слушаю… говорите")
    }

    override fun onBeginningOfSpeech() {
        onState?.invoke("🎤 Слышу вас…")
    }

    override fun onEndOfSpeech() {
        onState?.invoke("Распознаю…")
    }

    override fun onResults(results: android.os.Bundle?) {
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
        if (!text.isNullOrBlank()) {
            onState?.invoke("Распознано: $text")
            onResult?.invoke(text)
        } else {
            onState?.invoke("Ничего не распознано — попробуйте ещё раз")
        }
        recognizer?.cancel()
    }

    override fun onError(error: Int) {
        val message = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "ошибка аудио/микрофона"
            SpeechRecognizer.ERROR_CLIENT -> "ошибка клиента распознавания"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "нет разрешения на микрофон"
            SpeechRecognizer.ERROR_NETWORK -> "распознавание потребовало сеть"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "тайм-аут сети"
            SpeechRecognizer.ERROR_NO_MATCH -> "речь не распознана"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "распознаватель занят"
            SpeechRecognizer.ERROR_SERVER -> "ошибка сервиса распознавания"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "не услышал речь"
            else -> "ошибка распознавания ($error)"
        }
        onState?.invoke("Микрофон: $message")
        if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            Toast.makeText(context, "Микрофон: $message", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onPartialResults(partialResults: android.os.Bundle?) {}
    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

    fun shutdown() {
        offlineAsr.shutdown()
        recognizer?.destroy(); recognizer = null
        neuralTts.shutdown()
    }
}
