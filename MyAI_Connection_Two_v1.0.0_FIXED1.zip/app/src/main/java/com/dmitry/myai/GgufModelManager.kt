package com.dmitry.myai

import android.content.Context
import android.net.Uri
import java.io.File

class GgufModelManager(private val context: Context) {
    private val directory = File(context.filesDir, "gguf_models")
    private val prefs = context.getSharedPreferences("gguf_models", Context.MODE_PRIVATE)
    private val defaultThreads = 2
    private val maxModelBytes = 3L * 1024L * 1024L * 1024L

    init { directory.mkdirs() }

    fun directory(): File = directory

    fun models(): List<File> = directory.listFiles()
        ?.filter { it.isFile && it.extension.equals("gguf", ignoreCase = true) }
        ?.sortedBy { it.name.lowercase() }
        ?: emptyList()

    fun selectedModel(): File? {
        val selected = prefs.getString("selected", null)
        val all = models()
        return all.firstOrNull { it.name == selected } ?: all.firstOrNull()
    }

    fun selectModel(file: File) {
        require(file.exists() && file.extension.equals("gguf", true))
        prefs.edit().putString("selected", file.name).apply()
    }


    fun preferredThreads(): Int = selectedModel()?.let(::preferredThreads) ?: prefs.getInt("preferred_threads", defaultThreads).coerceIn(1, 8)

    fun preferredThreads(model: File): Int = prefs.getInt("threads_${model.name}", prefs.getInt("preferred_threads", defaultThreads)).coerceIn(1, 8)

    fun setPreferredThreads(threads: Int) {
        prefs.edit().putInt("preferred_threads", threads.coerceIn(1, 8)).apply()
    }

    fun setPreferredThreads(model: File, threads: Int) {
        prefs.edit()
            .putInt("threads_${model.name}", threads.coerceIn(1, 8))
            .putInt("preferred_threads", threads.coerceIn(1, 8))
            .apply()
    }

    fun importModel(uri: Uri, onProgress: (copiedBytes: Long, totalBytes: Long) -> Unit = { _, _ -> }): File {
        val resolver = context.contentResolver
        val displayName = resolver.query(uri, arrayOf("_display_name"), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            ?: "model.gguf"
        val cleanName = displayName.substringAfterLast('/').trim().ifBlank { "model.gguf" }

        require(cleanName.endsWith(".gguf", ignoreCase = true)) {
            "Нужен файл с расширением .gguf"
        }

        val size = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        require(size <= maxModelBytes || size < 0) { "GGUF слишком большой (> 3 ГБ)" }

        if (size > 0) {
            require(directory.usableSpace > size + 96L * 1024L * 1024L) {
                "Недостаточно свободного места для GGUF"
            }
        }

        val target = File(directory, cleanName)
        val temp = File(directory, ".${cleanName}.part")
        temp.delete()

        try {
            resolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Не удалось открыть GGUF" }
                temp.outputStream().use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var copied = 0L
                    var lastReported = 0L

                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        output.write(buffer, 0, read)
                        copied += read

                        // Do not flood the UI with progress updates.
                        if (copied - lastReported >= 4L * 1024L * 1024L ||
                            (size > 0L && copied >= size)
                        ) {
                            onProgress(copied, size)
                            lastReported = copied
                        }
                    }
                    output.flush()
                    onProgress(copied, size)
                }
            }

            require(temp.length() > 0) { "GGUF-файл пустой" }

            // A provider may report an unknown size; the copied size is authoritative.
            require(temp.length() <= maxModelBytes) { "GGUF слишком большой (> 3 ГБ)" }

            if (target.exists()) target.delete()
            check(temp.renameTo(target)) { "Не удалось сохранить GGUF" }

            selectModel(target)
            return target
        } catch (e: Exception) {
            temp.delete()
            throw e
        }
    }

    fun delete(file: File) {
        val wasSelected = selectedModel()?.name == file.name
        file.delete()
        if (wasSelected) {
            val next = models().firstOrNull()
            if (next != null) selectModel(next) else prefs.edit().remove("selected").apply()
        }
    }
}
