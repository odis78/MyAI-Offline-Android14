package com.dmitry.myai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Small persistent local engineering/action journal.
 * It is intentionally capped so diagnostics can never grow without bounds.
 */
class ActionLog(context: Context) {
    data class Entry(
        val time: String,
        val kind: String,
        val command: String,
        val result: String,
        val ok: Boolean,
    )

    private val file = File(context.filesDir, "action_log.json")

    @Synchronized
    fun record(kind: String, command: String, result: String, ok: Boolean) {
        val entries = recentInternal(MAX_ENTRIES).toMutableList()
        entries += Entry(
            time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
            kind = kind.take(40),
            command = command.take(600),
            result = result.take(1200),
            ok = ok,
        )
        val array = JSONArray()
        entries.takeLast(MAX_ENTRIES).forEach { e ->
            array.put(
                JSONObject()
                    .put("time", e.time)
                    .put("kind", e.kind)
                    .put("command", e.command)
                    .put("result", e.result)
                    .put("ok", e.ok)
            )
        }
        runCatching { file.writeText(array.toString()) }
    }

    fun recent(limit: Int = 30): List<Entry> = synchronized(this) {
        recentInternal(limit.coerceIn(1, MAX_ENTRIES))
    }

    fun exportText(limit: Int = 100): String = recent(limit)
        .joinToString("\n\n") { e ->
            "${e.time} | ${e.kind} | ${if (e.ok) "OK" else "FAIL"}\nКоманда: ${e.command}\nРезультат: ${e.result}"
        }
        .ifBlank { "Журнал MyAI пока пуст." }

    fun count(): Int = recent(MAX_ENTRIES).size

    fun clear() {
        runCatching { if (file.exists()) file.delete() }
    }

    private fun recentInternal(limit: Int): List<Entry> = runCatching {
        if (!file.exists()) return@runCatching emptyList()
        val array = JSONArray(file.readText())
        val start = (array.length() - limit).coerceAtLeast(0)
        buildList {
            for (i in start until array.length()) {
                val o = array.getJSONObject(i)
                add(
                    Entry(
                        time = o.optString("time"),
                        kind = o.optString("kind"),
                        command = o.optString("command"),
                        result = o.optString("result"),
                        ok = o.optBoolean("ok", false),
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    companion object {
        private const val MAX_ENTRIES = 300
    }
}
