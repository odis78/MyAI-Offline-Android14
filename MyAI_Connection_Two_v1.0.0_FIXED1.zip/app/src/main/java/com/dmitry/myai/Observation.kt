package com.dmitry.myai

/** Compact structured observation passed back to the local agent. */
data class Observation(
    val step: Int = 0,
    val tool: String = "",
    val packageNameBefore: String = "",
    val packageNameAfter: String = "",
    val focusedEditable: Boolean = false,
    val actionSuccess: Boolean = true,
    val actionMessage: String = "",
    val screenDiff: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toPrompt(): String = buildString {
        append("step=").append(step)
        append(" | tool=").append(tool.ifBlank { "none" })
        append(" | package=").append(packageNameAfter.ifBlank { "?" })
        append(" | focusedEditable=").append(focusedEditable)
        append(" | success=").append(actionSuccess)
        if (packageNameBefore.isNotBlank() && packageNameBefore != packageNameAfter) {
            append(" | packageChanged=true")
        }
        append('\n').append(actionMessage.take(320))
        if (screenDiff.isNotBlank()) append('\n').append(screenDiff.take(900))
    }
}
