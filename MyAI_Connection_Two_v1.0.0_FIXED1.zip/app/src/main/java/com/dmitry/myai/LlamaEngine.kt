package com.dmitry.myai

import android.content.Context
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import dev.ffmpegkit.llama.LlamaModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext

class LlamaEngine(private val context: Context) {
    /**
     * One-shot offline chat for the free llama-android AAR.
     * The free artifact returns the full completion rather than a Flow of tokens.
     */
    suspend fun chat(
        modelPath: String,
        prompt: String,
        systemPrompt: String = "Ты MyAI — локальный офлайн-помощник. Отвечай по-русски, точно и по делу.",
        threads: Int = 2,
        maxTokens: Int = 256
    ): String = withContext(NonCancellable + Dispatchers.Default) {
        val model = Llama.loadModel(
            modelPath = modelPath,
            config = LlamaConfig(contextSize = 2048, threads = threads.coerceIn(1, 8))
        )
        try {
            val result = Llama.complete(
                model,
                prompt = prompt,
                systemPrompt = systemPrompt,
                maxTokens = maxTokens
            )
            result.text.trim()
        } finally {
            Llama.releaseModel(model)
        }
    }

    /**
     * Opens one serial GGUF session so an agent loop can perform several sequential
     * completions without reloading the 1+ GB model for every step.
     * The underlying LlamaModel is explicitly documented as not thread-safe, so callers
     * must keep calls serial; AgentLoop does exactly that.
     */
    suspend fun openSession(modelPath: String, threads: Int = 2): LlamaSession =
        withContext(NonCancellable + Dispatchers.Default) {
            val model = Llama.loadModel(
                modelPath = modelPath,
                config = LlamaConfig(contextSize = 2048, threads = threads.coerceIn(1, 8))
            )
            LlamaSession(model)
        }

    suspend fun benchmark(modelPath: String, threadCounts: List<Int> = listOf(1, 2, 4, 6, 8)): LlamaBenchmarkReport =
        withContext(Dispatchers.Default) {
            val rows = mutableListOf<LlamaBenchmarkRow>()
            val thermalBefore = ThermalSnapshot(context)
            for (threads in threadCounts) {
                val startLoad = System.nanoTime()
                val loaded = Llama.loadModel(
                    modelPath = modelPath,
                    config = LlamaConfig(contextSize = 2048, threads = threads)
                )
                val loadMs = (System.nanoTime() - startLoad) / 1_000_000L
                try {
                    // Warm-up removes most first-run initialization noise from the timed sample.
                    Llama.complete(
                        loaded,
                        prompt = "Коротко ответь: 2+2=?",
                        systemPrompt = "Отвечай только числом.",
                        maxTokens = 8
                    )

                    val start = System.nanoTime()
                    val result = Llama.complete(
                        loaded,
                        prompt = "Напиши короткий список из пяти слов на русском языке.",
                        systemPrompt = "Отвечай кратко, без объяснений.",
                        maxTokens = 64
                    )
                    val elapsedMs = ((System.nanoTime() - start) / 1_000_000L).coerceAtLeast(1L)
                    rows += LlamaBenchmarkRow(
                        threads = threads,
                        tokensPerSecond = result.tokensPerSecond.toDouble(),
                        elapsedMs = elapsedMs,
                        loadMs = loadMs,
                        outputChars = result.text.length
                    )
                } finally {
                    Llama.releaseModel(loaded)
                }
            }
            val best = rows.maxByOrNull { it.tokensPerSecond }
            LlamaBenchmarkReport(rows, best?.threads ?: 4, thermalBefore, ThermalSnapshot(context))
        }
}

/** Serial session over one loaded model. */
class LlamaSession internal constructor(private val model: LlamaModel) : AutoCloseable {
    suspend fun complete(
        prompt: String,
        systemPrompt: String,
        maxTokens: Int
    ): String = withContext(NonCancellable + Dispatchers.Default) {
        Llama.complete(
            model,
            prompt = prompt,
            systemPrompt = systemPrompt,
            maxTokens = maxTokens
        ).text.trim()
    }

    override fun close() {
        Llama.releaseModel(model)
    }
}

data class LlamaBenchmarkRow(
    val threads: Int,
    val tokensPerSecond: Double,
    val elapsedMs: Long,
    val loadMs: Long,
    val outputChars: Int
)

data class LlamaBenchmarkReport(
    val rows: List<LlamaBenchmarkRow>,
    val bestThreads: Int,
    val thermalBefore: ThermalSnapshot,
    val thermalAfter: ThermalSnapshot
)

data class ThermalSnapshot(val context: Context) {
    val thermalStatus: String = if (android.os.Build.VERSION.SDK_INT >= 29) {
        when (context.getSystemService(android.os.PowerManager::class.java)?.currentThermalStatus) {
            android.os.PowerManager.THERMAL_STATUS_NONE -> "норма"
            android.os.PowerManager.THERMAL_STATUS_LIGHT -> "лёгкая нагрузка"
            android.os.PowerManager.THERMAL_STATUS_MODERATE -> "умеренная нагрузка"
            android.os.PowerManager.THERMAL_STATUS_SEVERE -> "высокая нагрузка"
            android.os.PowerManager.THERMAL_STATUS_CRITICAL -> "критическая нагрузка"
            android.os.PowerManager.THERMAL_STATUS_EMERGENCY -> "аварийная нагрузка"
            android.os.PowerManager.THERMAL_STATUS_SHUTDOWN -> "аварийное отключение"
            else -> "неизвестно"
        }
    } else "API < 29"
}
