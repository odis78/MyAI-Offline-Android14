package com.dmitry.myai

import org.json.JSONObject

/** Strict parser/validator for LLM -> ToolManager decisions. */
object AgentToolParser {
    data class Decision(
        val tool: String?,
        val args: JSONObject,
        val answer: String?,
        val done: Boolean = false
    )

    private val allowedTools = AgentToolSchema.toolNames()
    private val allowedTopLevel = setOf("tool", "args", "answer", "done")

    fun allowedToolNames(): Set<String> = allowedTools

    fun parse(raw: String): Decision {
        require(raw.length <= 24000) { "Ответ модели слишком большой для agent-протокола" }
        val cleaned = raw.trim()
            .removePrefix("```json")
            .removePrefix("```JSON")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        val jsonText = extractObject(cleaned)
            ?: error("Модель должна вернуть JSON-объект tool/answer/done")
        val o = runCatching { JSONObject(jsonText) }.getOrElse {
            error("Некорректный JSON в ответе агента")
        }

        val unknownTop = o.keys().asSequence().filterNot { it in allowedTopLevel }.toList()
        require(unknownTop.isEmpty()) { "Неизвестные поля верхнего уровня: ${unknownTop.joinToString(", ")}" }

        val hasDone = o.has("done")
        require(!hasDone || o.opt("done") is Boolean) { "Поле done должно быть boolean" }
        val done = o.optBoolean("done", false)
        val answer = o.optString("answer", "").trim().takeIf { it.isNotBlank() }
        val tool = o.optString("tool", "").trim().takeIf { it.isNotBlank() }

        if (tool != null) {
            require(!done) { "tool нельзя использовать вместе с done=true" }
            require(tool in allowedTools) { "Недопустимый tool: $tool" }
            val args = o.optJSONObject("args") ?: JSONObject()
            val allowedArgs = AgentToolSchema.allowedArgs(tool)
            val unknownArgs = args.keys().asSequence().filterNot { it in allowedArgs }.toList()
            require(unknownArgs.isEmpty()) { "$tool: неизвестные args: ${unknownArgs.joinToString(", ")}" }
            validate(tool, args)
            return Decision(tool, args, answer, false)
        }

        require(answer != null || done) { "Нужно вернуть tool или answer/done" }
        require(done || answer == null) { "Финальный answer должен иметь done=true" }
        require(!o.has("args") || o.optJSONObject("args") != null) { "args должен быть JSON-объектом" }
        return Decision(null, JSONObject(), answer, done)
    }

    private fun extractObject(text: String): String? {
        val start = text.indexOf('{')
        if (start < 0) return null
        var depth = 0
        var inString = false
        var escaped = false
        for (i in start until text.length) {
            val c = text[i]
            if (inString) {
                if (escaped) escaped = false
                else if (c == '\\') escaped = true
                else if (c == '"') inString = false
                continue
            }
            when (c) {
                '"' -> inString = true
                '{' -> depth++
                '}' -> {
                    depth--
                    if (depth == 0) return text.substring(start, i + 1)
                }
            }
        }
        return null
    }

    private fun validate(tool: String, args: JSONObject) {
        fun strictString(name: String, max: Int = 4000, required: Boolean = false): String? {
            if (!args.has(name)) {
                if (required) error("$tool требует args.$name")
                return null
            }
            val value = args.opt(name)
            require(value is String) { "$tool: args.$name должен быть строкой" }
            val text = value.trim()
            require(text.length <= max) { "$tool: args.$name слишком длинный (максимум $max)" }
            if (required) require(text.isNotBlank()) { "$tool: args.$name не может быть пустым" }
            return text.takeIf { it.isNotBlank() }
        }
        fun strictDouble(name: String, min: Double? = null, max: Double? = null): Double {
            val value = args.opt(name)
            require(value is Number) { "$tool: args.$name должен быть числом" }
            val d = value.toDouble()
            require(d.isFinite()) { "$tool: args.$name некорректно" }
            if (min != null) require(d >= min) { "$tool: args.$name меньше минимума" }
            if (max != null) require(d <= max) { "$tool: args.$name больше максимума" }
            return d
        }
        fun strictLong(name: String, min: Long, max: Long, required: Boolean = false): Long {
            if (!args.has(name)) {
                if (required) error("$tool требует args.$name")
                return min
            }
            val value = args.opt(name)
            require(value is Number) { "$tool: args.$name должен быть числом" }
            val d = value.toDouble()
            require(d.isFinite() && d % 1.0 == 0.0) { "$tool: args.$name должен быть целым числом" }
            val l = value.toLong()
            require(l in min..max) { "$tool: args.$name вне диапазона" }
            return l
        }

        when (tool) {
            "click_text", "type_text", "wait_for_text" -> strictString("text", 1000, true)
            "tap" -> {
                strictDouble("x", 0.0, 5000.0)
                strictDouble("y", 0.0, 5000.0)
            }
            "open_browser", "open_maps" -> strictString("query", 500, false)
            "open_url" -> {
                val url = strictString("url", 500, true)!!
                require(url.startsWith("https://") || url.startsWith("http://")) { "Разрешены только http/https URL" }
            }
            "call" -> {
                val number = strictString("number", 24, true)!!
                require(number.matches(Regex("[+\\d\\s()\\-]{7,24}"))) { "Некорректный номер для call" }
            }
            "sms" -> {
                if (args.has("number")) strictString("number", 24, false)
                strictString("body", 4000, true)
            }
            "email" -> {
                if (args.has("to")) strictString("to", 320, false)
                if (args.has("subject")) strictString("subject", 300, false)
                strictString("body", 8000, true)
            }
            "save_note" -> {
                if (args.has("title")) strictString("title", 120, false)
                strictString("body", 12000, true)
            }
            "search_notes" -> strictString("query", 500, true)
            "create_reminder" -> {
                strictString("title", 300, true)
                if (args.has("when")) strictString("when", 100, false)
            }
            "analyze_text" -> strictString("text", 12000, true)
            "vibrate" -> strictLong("ms", 10L, 500L, false)
            "share_text" -> {
                if (args.has("title")) strictString("title", 200, false)
                strictString("text", 8000, true)
            }
        }
    }
}
