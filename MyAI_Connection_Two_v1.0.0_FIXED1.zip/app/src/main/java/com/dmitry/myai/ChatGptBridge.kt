package com.dmitry.myai

import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * First safe integration layer for the separate ChatGPT Android app.
 * It never embeds or modifies the ChatGPT APK; it uses Android app-to-app intents.
 */
object ChatGptBridge {
    private const val CHATGPT_PACKAGE = "com.openai.chatgpt"

    fun isInstalled(context: Context): Boolean = runCatching {
        context.packageManager.getApplicationInfo(CHATGPT_PACKAGE, 0)
        true
    }.getOrDefault(false)

    fun open(context: Context) {
        val pm = context.packageManager
        val launch = pm.getLaunchIntentForPackage(CHATGPT_PACKAGE)
        if (launch == null) {
            Toast.makeText(context, "ChatGPT не найден. Установите приложение ChatGPT.", Toast.LENGTH_LONG).show()
            return
        }
        runCatching { context.startActivity(launch) }
            .onFailure { Toast.makeText(context, "Не удалось открыть ChatGPT: ${it.message ?: "ошибка"}", Toast.LENGTH_LONG).show() }
    }

    fun sendText(context: Context, text: String) {
        if (!isInstalled(context)) {
            Toast.makeText(context, "ChatGPT не найден. Установите приложение ChatGPT.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            setPackage(CHATGPT_PACKAGE)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
            .onFailure {
                Toast.makeText(context, "ChatGPT не принял передачу текста; откройте его обычной кнопкой.", Toast.LENGTH_LONG).show()
            }
    }
}
