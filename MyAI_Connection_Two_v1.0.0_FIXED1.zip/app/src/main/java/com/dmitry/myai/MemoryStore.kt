package com.dmitry.myai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/** Small durable local memory for notes/reminders. No cloud sync. */
class MemoryStore(context: Context) {
    data class Note(val id: String, val title: String, val body: String, val updatedAt: Long)
    data class Reminder(val id: String, val title: String, val whenLabel: String, val done: Boolean, val createdAt: Long)

    private val dir = File(context.filesDir, "memory").apply { mkdirs() }
    private val notesFile = File(dir, "notes.json")
    private val remindersFile = File(dir, "reminders.json")

    @Synchronized fun saveNote(title: String, body: String): Note {
        val note = Note("note-${System.currentTimeMillis()}", title.take(120).ifBlank { "Заметка" }, body.take(12000), System.currentTimeMillis())
        val notes = readNotes().toMutableList()
        notes.add(0, note)
        writeNotes(notes.take(200))
        return note
    }

    @Synchronized fun searchNotes(query: String, limit: Int = 8): List<Note> {
        val q = query.trim().lowercase(Locale.getDefault())
        if (q.isBlank()) return readNotes().take(limit)
        return readNotes().filter { (it.title + "\n" + it.body).lowercase(Locale.getDefault()).contains(q) }.take(limit)
    }

    @Synchronized fun addReminder(title: String, whenLabel: String): Reminder {
        val r = Reminder("rem-${System.currentTimeMillis()}", title.take(300), whenLabel.take(100), false, System.currentTimeMillis())
        val list = readReminders().toMutableList()
        list.add(0, r)
        writeReminders(list.take(200))
        return r
    }

    fun memorySummary(): String = buildString {
        val notes = readNotes().take(5)
        val reminders = readReminders().filterNot { it.done }.take(5)
        if (notes.isEmpty() && reminders.isEmpty()) {
            append("Локальная память пока пуста.")
            return@buildString
        }
        if (notes.isNotEmpty()) {
            append("Заметки:\n")
            notes.forEach { append("- ${it.title}: ${it.body.take(240)}\n") }
        }
        if (reminders.isNotEmpty()) {
            append("Напоминания:\n")
            reminders.forEach { append("- ${it.title} (${it.whenLabel})\n") }
        }
    }

    private fun readNotes(): List<Note> = runCatching {
        if (!notesFile.exists()) return@runCatching emptyList()
        val a = JSONArray(notesFile.readText())
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(Note(o.optString("id"), o.optString("title"), o.optString("body"), o.optLong("updatedAt")))
            }
        }
    }.getOrDefault(emptyList())

    private fun writeNotes(list: List<Note>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("updatedAt", it.updatedAt)) }
        runCatching { notesFile.writeText(a.toString()) }
    }

    private fun readReminders(): List<Reminder> = runCatching {
        if (!remindersFile.exists()) return@runCatching emptyList()
        val a = JSONArray(remindersFile.readText())
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(Reminder(o.optString("id"), o.optString("title"), o.optString("whenLabel"), o.optBoolean("done"), o.optLong("createdAt")))
            }
        }
    }.getOrDefault(emptyList())

    private fun writeReminders(list: List<Reminder>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("whenLabel", it.whenLabel).put("done", it.done).put("createdAt", it.createdAt)) }
        runCatching { remindersFile.writeText(a.toString()) }
    }
}
