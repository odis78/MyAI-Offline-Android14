package com.dmitry.myai

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import kotlin.math.roundToInt

/**
 * Hardware/thermal profile for the experimental "Second Branch".
 *
 * This class deliberately does not assume that a fixed thread count is optimal.
 * It reports the device state and gives a conservative starting point; the
 * inference benchmark will be the authority once a GGUF/llama.cpp backend is added.
 */
data class InferenceSettings(val threads: Int, val maxTokens: Int, val reason: String)

data class RealmePerformanceSnapshot(
    val cpuCores: Int,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val thermalStatus: String,
    val recommendedThreads: Int,
    val profile: String
)

class RealmePerformanceProfile(private val context: Context) {
    fun snapshot(): RealmePerformanceSnapshot {
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val am = context.getSystemService(ActivityManager::class.java)
        val mem = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(mem)
        val totalMb = mem.totalMem / (1024L * 1024L)
        val availableMb = mem.availMem / (1024L * 1024L)
        val thermal = thermalStatus()

        // Conservative starting point. It is intentionally benchmark-driven later.
        val threads = when {
            thermal.level >= 3 -> 2
            cores >= 8 -> 4
            cores >= 4 -> 2
            else -> 1
        }

        val profile = when {
            thermal.level >= 4 -> "Холодный: ограниченная нагрузка"
            thermal.level >= 3 -> "Тепловая защита: 2 потока"
            availableMb < 1200 -> "Память ограничена: лёгкий режим"
            else -> "Сбалансированный"
        }

        return RealmePerformanceSnapshot(
            cpuCores = cores,
            totalRamMb = totalMb,
            availableRamMb = availableMb,
            thermalStatus = thermal.label,
            recommendedThreads = threads,
            profile = profile
        )
    }


    fun inferenceSettings(preferredThreads: Int, requestedMaxTokens: Int): InferenceSettings {
        val thermal = thermalStatus()
        val baseThreads = preferredThreads.coerceIn(1, 8)
        val threads = when {
            thermal.level >= 4 -> 1
            thermal.level >= 3 -> minOf(baseThreads, 2)
            thermal.level >= 2 -> minOf(baseThreads, 3)
            else -> baseThreads
        }
        val maxTokens = when {
            thermal.level >= 4 -> minOf(requestedMaxTokens, 96)
            thermal.level >= 3 -> minOf(requestedMaxTokens, 160)
            thermal.level >= 2 -> minOf(requestedMaxTokens, 192)
            else -> requestedMaxTokens.coerceIn(32, 512)
        }
        val reason = if (threads == baseThreads && maxTokens == requestedMaxTokens) "профиль без ограничений" else "thermal governor: ${thermal.label}"
        return InferenceSettings(threads, maxTokens, reason)
    }

    private data class Thermal(val level: Int, val label: String)

    private fun thermalStatus(): Thermal {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return Thermal(0, "не поддерживается")
        val pm = context.getSystemService(PowerManager::class.java)
            ?: return Thermal(0, "неизвестно")
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> Thermal(0, "норма")
            PowerManager.THERMAL_STATUS_LIGHT -> Thermal(1, "слегка повышена")
            PowerManager.THERMAL_STATUS_MODERATE -> Thermal(2, "умеренная")
            PowerManager.THERMAL_STATUS_SEVERE -> Thermal(3, "высокая")
            PowerManager.THERMAL_STATUS_CRITICAL -> Thermal(4, "критическая")
            PowerManager.THERMAL_STATUS_EMERGENCY -> Thermal(5, "аварийная")
            PowerManager.THERMAL_STATUS_SHUTDOWN -> Thermal(6, "аварийное отключение")
            else -> Thermal(0, "неизвестно")
        }
    }
}
