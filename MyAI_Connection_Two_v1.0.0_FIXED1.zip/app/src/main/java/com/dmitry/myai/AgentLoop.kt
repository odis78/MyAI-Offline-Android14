package com.dmitry.myai

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.currentCoroutineContext
import java.io.File

/**
 * Agent orchestration, intentionally separated from UI state.
 * One model session is reused for the complete multi-step task.
 */
class AgentLoop(
    private val context: Context,
    private val toolManager: ToolManager,
    private val memory: MemoryStore,
    private val actionLog: ActionLog,
    private val profile: RealmePerformanceProfile,
    private val ggufManager: GgufModelManager,
) {
    data class Result(
        val text: String,
        val pending: ToolManager.PendingConfirmation? = null,
        val trace: List<String> = emptyList()
    )

    suspend fun run(
        model: File,
        task: String,
        conversationContext: String,
        onTrace: (List<String>) -> Unit = {}
    ): Result = withContext(Dispatchers.Default) {
        val engine = LlamaEngine(context)
        val preferred = ggufManager.preferredThreads(model)
        val trace = AgentTrace()
        var observation = "Начало задачи. Подтверждения действия пока нет."
        var lastToolMessage = ""
        var sessionThreads = profile.inferenceSettings(preferred, 220).threads
        var session = engine.openSession(model.absolutePath, sessionThreads)

        fun pushTrace(item: String) {
            trace.add(item)
            onTrace(trace.snapshot())
        }

        try {
            for (step in 0 until AgentToolSchema.MAX_STEPS) {
                currentCoroutineContext().ensureActive()
                val requestedTokens = if (step == 0) 220 else 180
                val settings = profile.inferenceSettings(preferred, requestedTokens)
                if (settings.threads != sessionThreads) {
                    session.close()
                    sessionThreads = settings.threads
                    session = engine.openSession(model.absolutePath, sessionThreads)
                    pushTrace("thermal: ${settings.reason}; threads=${settings.threads}")
                }

                val agentPrompt = buildPrompt(
                    task = task,
                    conversationContext = conversationContext,
                    observation = observation,
                    workingTrace = trace.prompt(),
                    step = step,
                    settingsReason = settings.reason
                )

                var decision: AgentToolParser.Decision? = null
                var protocolError = ""
                for (retry in 0 until AgentToolSchema.MAX_PROTOCOL_RETRIES) {
                    val retryPrompt = if (protocolError.isBlank()) {
                        agentPrompt
                    } else {
                        agentPrompt + "\n\nПРЕДЫДУЩАЯ ОШИБКА ПРОТОКОЛА: $protocolError\nНЕ НАЧИНАЙ ЗАДАЧУ ЗАНОВО. Сохрани последнее observation и верни только исправленный JSON."
                    }
                    currentCoroutineContext().ensureActive()
                    val raw = session.complete(
                        prompt = retryPrompt,
                        systemPrompt = AgentToolSchema.systemPrompt(),
                        maxTokens = settings.maxTokens
                    )
                    currentCoroutineContext().ensureActive()
                    val parsed = runCatching { AgentToolParser.parse(raw) }
                        .onFailure { error ->
                            protocolError = error.message ?: "validation error"
                            actionLog.record("agent-validator", raw.take(500), "Попытка ${retry + 1}: $protocolError", false)
                        }
                        .getOrNull()
                    if (parsed != null) {
                        decision = parsed
                        break
                    }
                }

                val parsed = decision
                if (parsed == null) {
                    observation = "JSON-протокол не прошёл проверку после ${AgentToolSchema.MAX_PROTOCOL_RETRIES} попыток: $protocolError"
                    pushTrace("validator FAIL: $protocolError")
                    actionLog.record("agent-protocol-fail", task, observation, false)
                    return@withContext Result("Не удалось безопасно разобрать команду локального агента. $protocolError", trace = trace.snapshot())
                }

                if (parsed.done) {
                    val answer = parsed.answer?.trim().orEmpty()
                    pushTrace("done=true")
                    return@withContext Result(answer.ifBlank { lastToolMessage.ifBlank { "Готово." } }, trace = trace.snapshot())
                }

                currentCoroutineContext().ensureActive()
                val toolName = parsed.tool?.trim().orEmpty()
                if (toolName.isBlank()) {
                    observation = "Ответ без tool. Если задача выполнена — верни done=true с answer. Иначе верни один разрешённый tool."
                    pushTrace("protocol: отсутствует tool")
                    continue
                }

                val beforeScreen = MyAiAccessibilityService.readScreen().take(2400)
                val beforePackage = MyAiAccessibilityService.activePackage()
                val result = toolManager.executeToolCall(toolName, parsed.args)
                lastToolMessage = result.message

                if (result.pending != null) {
                    pushTrace("$toolName: требуется подтверждение")
                    return@withContext Result(result.message, pending = result.pending, trace = trace.snapshot())
                }

                MyAiAccessibilityService.waitIdle(450)
                val afterScreen = MyAiAccessibilityService.readScreen().take(2400)
                val afterPackage = MyAiAccessibilityService.activePackage()
                val diff = screenDiff(beforeScreen, afterScreen)
                val focused = MyAiAccessibilityService.hasFocusedEditable()
                val structured = Observation(
                    step = step + 1,
                    tool = toolName,
                    packageNameBefore = beforePackage,
                    packageNameAfter = afterPackage,
                    focusedEditable = focused,
                    actionSuccess = result.ok,
                    actionMessage = result.message,
                    screenDiff = diff
                )
                observation = structured.toPrompt()
                pushTrace("$toolName: ${if (result.ok) "OK" else "FAIL"} | ${diff.lines().firstOrNull().orEmpty()}")
                actionLog.record("agent-observation", toolName, observation.take(3000), result.ok)
            }
        } catch (e: CancellationException) {
            actionLog.record("agent-cancel", task, "Генерация отменена", false)
            throw e
        } finally {
            session.close()
        }

        Result(
            text = lastToolMessage.ifBlank { "Я выполнил доступные шаги, но агент не вернул итоговый ответ." },
            trace = trace.snapshot()
        )
    }

    private fun buildPrompt(
        task: String,
        conversationContext: String,
        observation: String,
        workingTrace: String,
        step: Int,
        settingsReason: String
    ): String = buildString {
        append("ИСТОРИЯ ДИАЛОГА:\n").append(conversationContext.take(6200))
        append("\n\nЛОКАЛЬНАЯ ПАМЯТЬ:\n").append(memory.memorySummary().take(1300))
        append("\n\nРАБОЧАЯ ПАМЯТЬ АГЕНТА:\n").append(workingTrace)
        append("\n\nСТРУКТУРИРОВАННОЕ OBSERVATION:\n").append(observation.take(1500))
        append("\n\nЗАДАЧА ПОЛЬЗОВАТЕЛЯ:\n").append(task.take(2000))
        append("\n\nШаг ${step + 1}/${AgentToolSchema.MAX_STEPS}; режим: ").append(settingsReason)
        append(". Выполни ровно один tool ИЛИ верни {\"done\":true,\"answer\":\"...\"}. Заверши раньше, если задача выполнена.")
    }

    private fun screenDiff(before: String, after: String): String {
        if (before.isBlank() && after.isBlank()) return "Экран недоступен."
        if (before == after) return "Экран не изменился."
        val beforeSet = before.lines().map { it.trim() }.filter { it.isNotBlank() }.toSet()
        val afterSet = after.lines().map { it.trim() }.filter { it.isNotBlank() }.toSet()
        val added = afterSet.minus(beforeSet).take(12)
        val removed = beforeSet.minus(afterSet).take(8)
        return buildString {
            if (added.isNotEmpty()) append("Добавлено:\n").append(added.joinToString("\n") { "+ $it" }).append('\n')
            if (removed.isNotEmpty()) append("Убрано:\n").append(removed.joinToString("\n") { "- $it" })
            if (isBlank()) append("Экран изменился, но короткий текстовый diff не определён.")
        }.trim()
    }
}
