package com.dmitry.myai

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import com.k2fsa.sherpa.onnx.EndpointConfig
import com.k2fsa.sherpa.onnx.EndpointRule
import com.k2fsa.sherpa.onnx.OnlineModelConfig
import com.k2fsa.sherpa.onnx.OnlineRecognizer
import com.k2fsa.sherpa.onnx.OnlineRecognizerConfig
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig
import com.k2fsa.sherpa.onnx.OnlineStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/** Fully local Russian microphone ASR using the downloaded sherpa-onnx model. */
class OfflineAsrController(private val manager: OfflineAsrManager) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private var recognizer: OnlineRecognizer? = null
    private var stream: OnlineStream? = null
    private val stopping = AtomicBoolean(false)

    fun isInstalled(): Boolean = manager.isInstalled()

    fun start(onResult: (String) -> Unit, onState: (String) -> Unit = {}, onFailure: (Throwable) -> Unit = {}) {
        if (!manager.isInstalled()) {
            postState(onState, "Сначала установите офлайн-распознавание в Настройках")
            return
        }
        stop()
        stopping.set(false)
        job = scope.launch {
            var record: AudioRecord? = null
            try {
                val model = manager.modelDir()
                val r = recognizer ?: OnlineRecognizer(
                    config = OnlineRecognizerConfig(
                        modelConfig = OnlineModelConfig(
                            transducer = OnlineTransducerModelConfig(
                                encoder = FilePath(model, "encoder.int8.onnx"),
                                decoder = FilePath(model, "decoder.onnx"),
                                joiner = FilePath(model, "joiner.int8.onnx")
                            ),
                            tokens = FilePath(model, "tokens.txt"),
                            numThreads = 2,
                            provider = "cpu",
                            modelType = "zipformer2"
                        ),
                        endpointConfig = EndpointConfig(
                            rule1 = EndpointRule(false, 1.8f, 0.0f),
                            rule2 = EndpointRule(true, 1.2f, 0.0f),
                            rule3 = EndpointRule(false, 0.0f, 20.0f)
                        ),
                        enableEndpoint = true,
                        decodingMethod = "greedy_search"
                    )
                ).also { recognizer = it }

                val s = r.createStream().also { stream = it }
                val minBuffer = AudioRecord.getMinBufferSize(
                    16000,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                require(minBuffer > 0) { "Микрофон недоступен" }
                val bufferSize = max(minBuffer * 2, 16000)
                record = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    16000,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                require(record?.state == AudioRecord.STATE_INITIALIZED) { "Не удалось открыть микрофон" }
                record?.startRecording()
                postState(onState, "🎤 Локальный микрофон слушает…")

                val shorts = ShortArray(3200)
                var lastText = ""
                while (scope.isActive && !stopping.get()) {
                    val n = record?.read(shorts, 0, shorts.size, AudioRecord.READ_BLOCKING) ?: 0
                    if (n <= 0) continue
                    val samples = FloatArray(n) { i -> shorts[i] / 32768f }
                    s.acceptWaveform(samples, 16000)
                    while (r.isReady(s)) r.decode(s)
                    val current = r.getResult(s).text.trim()
                    if (current.isNotBlank()) lastText = current
                    if (r.isEndpoint(s)) {
                        val finalText = r.getResult(s).text.trim()
                        if (finalText.isNotBlank()) {
                            postState(onState, "Распознано: $finalText")
                            main.post { onResult(finalText) }
                        } else {
                            postState(onState, "Ничего не распознано — попробуйте ещё раз")
                        }
                        r.reset(s)
                        lastText = ""
                        break
                    }
                }
            } catch (e: Throwable) {
                postState(onState, "Ошибка офлайн-микрофона: ${e.message ?: "неизвестная"}")
                main.post { onFailure(e) }
            } finally {
                runCatching { record?.stop() }
                runCatching { record?.release() }
                stream?.release()
                stream = null
            }
        }
    }

    fun stop() {
        stopping.set(true)
        job?.cancel()
        job = null
        stream?.release()
        stream = null
    }

    fun shutdown() {
        stop()
        recognizer?.release()
        recognizer = null
        scope.cancel()
    }

    private fun postState(onState: (String) -> Unit, text: String) {
        main.post { onState(text) }
    }

    private fun FilePath(root: java.io.File, name: String): String = java.io.File(root, name).absolutePath
}
