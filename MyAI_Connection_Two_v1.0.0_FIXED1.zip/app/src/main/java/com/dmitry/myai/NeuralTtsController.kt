package com.dmitry.myai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Speech output with two layers:
 * 1) downloaded Sherpa/Piper neural voice when available;
 * 2) Android system TTS as an immediate fallback, so speaking never depends
 *    on downloading a neural voice first.
 */
class NeuralTtsController(context: Context) {
    private val appContext = context.applicationContext
    private val manager = NeuralVoiceManager(appContext)
    private val prefs = appContext.getSharedPreferences("voice", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.Default)
    private var job: Job? = null
    private var tts: OfflineTts? = null
    private var currentVoiceId: String? = null
    private var track: AudioTrack? = null
    private var systemTts: TextToSpeech? = null
    @Volatile private var systemTtsReady = false
    private var speed = prefs.getFloat("speed", 1.0f).coerceIn(0.7f, 1.3f)

    init {
        systemTts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                systemTtsReady = true
                systemTts?.setLanguage(Locale("ru", "RU"))
                systemTts?.setSpeechRate(speed)
                systemTts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
            }
        }
    }

    fun manager(): NeuralVoiceManager = manager
    fun speed(): Float = speed
    fun setSpeed(value: Float) {
        speed = value.coerceIn(0.7f, 1.3f)
        prefs.edit().putFloat("speed", speed).apply()
        systemTts?.setSpeechRate(speed)
    }

    fun speak(text: String, onDone: () -> Unit = {}, onError: (Throwable) -> Unit = {}) {
        if (text.isBlank()) return
        stop()
        val voice = manager.selected()
        if (voice == null) {
            speakSystem(text, onDone, onError)
            return
        }
        job = scope.launch {
            try {
                val audio = withContext(Dispatchers.Default) { synthesize(voice, text) }
                play(audio.samples, audio.sampleRate)
                withContext(Dispatchers.Main) { onDone() }
            } catch (e: Throwable) {
                // A damaged/missing neural voice must not silence MyAI. Fall back
                // to the Android TTS engine and report only if that also fails.
                speakSystem(text, onDone, onError)
            }
        }
    }

    private fun speakSystem(text: String, onDone: () -> Unit, onError: (Throwable) -> Unit) {
        val engine = systemTts
        if (engine == null || !systemTtsReady) {
            onError(IllegalStateException("Системный голос Android ещё не готов"))
            return
        }
        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "myai-${System.nanoTime()}")
        if (result == TextToSpeech.ERROR) {
            onError(IllegalStateException("Android TTS не смог озвучить текст"))
        } else {
            onDone()
        }
    }

    private fun synthesize(voice: NeuralVoiceManager.Voice, text: String): com.k2fsa.sherpa.onnx.GeneratedAudio {
        val dir = manager.voiceDir(voice)
        val modelFile = dir.walkTopDown().firstOrNull { it.isFile && it.extension.equals("onnx", true) }
            ?: error("ONNX-модель голоса не найдена")
        val dataDir = manager.sharedEspeakDir()
        if (!dataDir.isDirectory || !File(dir, "tokens.txt").exists()) error("Файлы Piper/Sherpa повреждены")
        if (currentVoiceId != voice.id) {
            tts?.release()
            val config = OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    vits = OfflineTtsVitsModelConfig(
                        model = modelFile.absolutePath,
                        tokens = File(dir, "tokens.txt").absolutePath,
                        dataDir = dataDir.absolutePath
                    ),
                    numThreads = 2,
                    provider = "cpu",
                    debug = false
                )
            )
            tts = OfflineTts(config = config)
            currentVoiceId = voice.id
        }
        return requireNotNull(tts).generate(text = text, sid = 0, speed = speed)
    }

    private fun play(samples: FloatArray, sampleRate: Int) {
        stopTrack()
        val pcm = ShortArray(samples.size) { i -> (samples[i].coerceIn(-1f, 1f) * Short.MAX_VALUE).roundToInt().toShort() }
        val minBuffer = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(4096)
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(minBuffer, pcm.size * 2))
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = at
        at.write(pcm, 0, pcm.size)
        at.play()
    }

    fun stop() {
        job?.cancel(); job = null
        stopTrack()
        systemTts?.stop()
    }

    private fun stopTrack() {
        runCatching { track?.stop() }
        runCatching { track?.flush() }
        runCatching { track?.release() }
        track = null
    }

    fun isSpeaking(): Boolean = track?.playState == AudioTrack.PLAYSTATE_PLAYING

    fun shutdown() {
        stop()
        tts?.release()
        tts = null
        currentVoiceId = null
        systemTts?.shutdown()
        systemTts = null
        systemTtsReady = false
    }
}
