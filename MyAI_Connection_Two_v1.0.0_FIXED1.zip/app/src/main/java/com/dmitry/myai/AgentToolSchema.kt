package com.dmitry.myai

/** Canonical LLM -> tool contract used by the third branch agent. */
object AgentToolSchema {
    const val MAX_STEPS = 4
    const val MAX_PROTOCOL_RETRIES = 2
    const val MAX_TRACE_ITEMS = 5

    private val descriptions = ToolRegistry.all().associate { it.name to it.description }

    private val allowedArgs = ToolRegistry.all().associate { it.name to it.allowedArgs }

    fun toolNames(): Set<String> = descriptions.keys

    fun allowedArgs(tool: String): Set<String> = allowedArgs[tool].orEmpty()

    fun compactPrompt(): String = buildString {
        descriptions.forEach { (name, description) ->
            append(name).append(" — ").append(description).append('\n')
        }
    }

    fun systemPrompt(): String = """Ты — MyAI, локальный Android-агент. Работай только через разрешённые tools.

Каждый ответ ДОЛЖЕН быть одним JSON-объектом без markdown.
Для действия:
{"tool":"click_text","args":{"text":"Настройки"}}
Для завершения:
{"done":true,"answer":"Готово."}

`done=true` означает завершение задачи. Не используй `tool` вместе с `done=true`.
Запрещено придумывать tools, параметры и выполненные действия. После действия используй observation.
Не говори «готово», пока результат не подтверждён observation или результатом инструмента.
Для call/sms/email жди подтверждения пользователя.
Один шаг = один tool или финальный done=true.

Доступные tools:
${compactPrompt()}"""
}
