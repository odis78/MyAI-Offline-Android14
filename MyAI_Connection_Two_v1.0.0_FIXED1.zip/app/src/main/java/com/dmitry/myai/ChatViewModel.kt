package com.dmitry.myai

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File


data class ChatLine(val text: String, val user: Boolean)

enum class AiState { NO_MODEL, IMPORTING, READY_TO_START, STARTING, READY, ERROR, GENERATING, WAITING_CONFIRMATION }

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val manager = ModelManager(app)
    private val ggufManager = GgufModelManager(app)
    private val ai = LocalAiEngine(app)
    private val toolManager = ToolManager(app)
    private val actionLog = ActionLog(app)
    private val memory = MemoryStore(app)
    private val agentLoop by lazy {
        AgentLoop(
            context = app,
            toolManager = toolManager,
            memory = memory,
            actionLog = actionLog,
            profile = RealmePerformanceProfile(app),
            ggufManager = ggufManager
        )
    }
    private val historyFile = File(app.filesDir, "chat_history.json")

    private val _messages = MutableStateFlow(loadHistory().ifEmpty {
        listOf(
            ChatLine(
                if (ggufManager.selectedModel() != null)
                    "Я готов к офлайн-режиму. Выбрана GGUF-модель Qwen / llama.cpp. Можешь писать или говорить со мной."
                else
                    "Я готов к офлайн-режиму. Импортируй .litertlm модель и запусти AI.",
                false
            )
        )
    })
    val messages = _messages.asStateFlow()

    private val _state = MutableStateFlow(
        when {
            ggufManager.selectedModel() != null -> AiState.READY
            manager.hasModel() -> AiState.READY_TO_START
            else -> AiState.NO_MODEL
        }
    )
    val state = _state.asStateFlow()
    private val _status = MutableStateFlow(statusText(_state.value))
    val status = _status.asStateFlow()

    private val _ggufStatus = MutableStateFlow("")
    val ggufStatus = _ggufStatus.asStateFlow()

    private val _ggufRevision = MutableStateFlow(0)
    val ggufRevision = _ggufRevision.asStateFlow()

    // One-shot assistant replies used by the UI for automatic neural TTS.
    private val _assistantReplies = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val assistantReplies = _assistantReplies.asSharedFlow()

    private val _pendingConfirmation = MutableStateFlow<ToolManager.PendingConfirmation?>(null)
    val pendingConfirmation = _pendingConfirmation.asStateFlow()

    private var job: Job? = null

    private val _agentTrace = MutableStateFlow<List<String>>(emptyList())
    val agentTrace = _agentTrace.asStateFlow()

    fun modelDirectory() = manager.directory()
    fun modelName(): String = manager.selectedModel()?.name ?: "—"
    fun models(): List<File> = manager.models()
    fun selectModel(file: File) {
        manager.selectModel(file)
        ai.close()
        setState(AiState.READY_TO_START, "Выбрана: ${file.name}")
    }
    fun deleteModel(file: File) {
        if (manager.selectedModel()?.name == file.name) ai.close()
        manager.delete(file)
        setState(if (manager.hasModel()) AiState.READY_TO_START else AiState.NO_MODEL)
    }

    private fun setState(value: AiState, detail: String? = null) {
        _state.value = value
        _status.value = detail ?: statusText(value)
    }

    fun importModel(uri: Uri) {
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                setState(AiState.IMPORTING)
                ai.close()
                val file = manager.importModel(uri)
                setState(AiState.READY_TO_START, "Модель готова: ${file.name}")
            } catch (e: Exception) {
                setState(AiState.ERROR, "Ошибка импорта: ${e.message ?: "неизвестная"}")
            }
        }
    }


    fun importGgufModel(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            _ggufStatus.value = "Подготовка импорта GGUF…"
            try {
                val file = ggufManager.importModel(uri) { copied, total ->
                    _ggufStatus.value = if (total > 0L) {
                        val percent = ((copied * 100L) / total).coerceIn(0L, 100L)
                        "Импорт GGUF: $percent% — ${copied / (1024L * 1024L)} / ${total / (1024L * 1024L)} MB"
                    } else {
                        "Импорт GGUF: ${copied / (1024L * 1024L)} MB"
                    }
                }
                _ggufRevision.value += 1
                ai.close()
                setState(AiState.READY, "GGUF / llama.cpp готов: ${file.name}")
                _ggufStatus.value = "GGUF импортирован: ${file.name}"
            } catch (e: Exception) {
                _ggufStatus.value = "Ошибка импорта GGUF: ${e.message ?: "неизвестная"}"
            }
        }
    }

    fun loadModel() {
        val model = manager.selectedModel()
        if (model == null) { setState(AiState.NO_MODEL); return }
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                setState(AiState.STARTING)
                ai.initialize(model.absolutePath)
                setState(AiState.READY)
            } catch (e: Exception) {
                ai.close()
                setState(AiState.ERROR, "Ошибка запуска: ${e.message ?: "неизвестная"}")
            }
        }
    }

    fun send(text: String) {
        val prompt = text.trim()
        if (prompt.isEmpty() || _state.value == AiState.GENERATING || _state.value == AiState.WAITING_CONFIRMATION) return

        // All deterministic device commands go through one native ToolManager.
        // The LLM is used only for free-form requests and never has to guess how
        // an Android action should be invoked.
        val tool = toolManager.execute(prompt)
        if (tool.handled) {
            _messages.value = _messages.value + ChatLine(prompt, true) + ChatLine(tool.message, false)
            saveHistory()
            if (tool.pending != null) {
                _pendingConfirmation.value = tool.pending
                setState(AiState.WAITING_CONFIRMATION, "Ожидается подтверждение действия")
            } else {
                _assistantReplies.tryEmit(tool.message)
                setState(if (tool.ok) AiState.READY else AiState.ERROR, if (tool.ok) "Инструмент: ${tool.toolId}" else "Инструмент не выполнил действие")
            }
            return
        }

        val gguf = ggufManager.selectedModel()

        // Unknown requests enter the local agent loop: LLM -> validated tool -> observation -> LLM.
        if (gguf != null) {
            _messages.value = _messages.value + ChatLine(prompt, true) + ChatLine("", false)
            saveHistory()
            job?.cancel()
            job = viewModelScope.launch(Dispatchers.IO) {
                try {
                    _agentTrace.value = emptyList()
                    setState(AiState.GENERATING, "GGUF / агент работает…")
                    val answer = agentLoop.run(
                        model = gguf,
                        task = prompt,
                        conversationContext = buildConversationPrompt(prompt),
                        onTrace = { _agentTrace.value = it }
                    )
                    if (answer.pending != null) {
                        _messages.value = _messages.value.dropLast(1) + ChatLine(answer.text, false)
                        _pendingConfirmation.value = answer.pending
                        saveHistory()
                        setState(AiState.WAITING_CONFIRMATION, "Ожидается подтверждение действия")
                        return@launch
                    }
                    val finalText = answer.text.ifBlank { "Агент не получил итогового ответа." }
                    _messages.value = _messages.value.dropLast(1) + ChatLine(finalText, false)
                    _agentTrace.value = _agentTrace.value.takeLast(AgentToolSchema.MAX_TRACE_ITEMS)
                    saveHistory()
                    _assistantReplies.tryEmit(finalText)
                    actionLog.record("agent", prompt, "Итог: ${finalText.take(180)}", true)
                    setState(AiState.READY, "Агент готов")
                } catch (e: CancellationException) {
                    actionLog.record("agent-cancel", prompt, "Генерация отменена", false)
                    throw e
                } catch (e: Exception) {
                    val detail = e.message ?: e.javaClass.simpleName
                    _messages.value = _messages.value.dropLast(1) + ChatLine("Ошибка агента: $detail", false)
                    saveHistory()
                    actionLog.record("agent-error", prompt, detail, false)
                    setState(AiState.ERROR, "Ошибка агента")
                }
            }
            return
        }

        if (!ai.isInitialized()) {
            _messages.value = _messages.value + ChatLine("Сначала запусти AI в настройках.", false)
            saveHistory()
            return
        }
        _messages.value = _messages.value + ChatLine(prompt, true) + ChatLine("", false)
        saveHistory()
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                setState(AiState.GENERATING)
                var answer = ""
                ai.streamChat(prompt).collect { token ->
                    answer += token
                    _messages.value = _messages.value.dropLast(1) + ChatLine(answer, false)
                }
                saveHistory()
                if (answer.isNotBlank()) _assistantReplies.tryEmit(answer)
                setState(AiState.READY)
            } catch (e: Exception) {
                _messages.value = _messages.value.dropLast(1) +
                    ChatLine("Ошибка локального AI: ${e.message ?: "неизвестная"}", false)
                saveHistory()
                setState(AiState.ERROR)
            }
        }
    }



    private fun buildConversationPrompt(currentPrompt: String): String {
        val previous = _messages.value
            .dropLast(2)
            .takeLast(10)
            .joinToString("\n") { line ->
                if (line.user) "Пользователь: ${line.text}" else "MyAI: ${line.text}"
            }
        return if (previous.isBlank()) {
            "Пользователь: $currentPrompt\nMyAI:"
        } else {
            "$previous\nПользователь: $currentPrompt\nMyAI:"
        }
    }

    fun cancelAgent() {
        job?.cancel()
        job = null
        _agentTrace.value = emptyList()
        if (_state.value == AiState.GENERATING) setState(AiState.READY, "Генерация остановлена")
    }

    fun confirmPendingTool() {
        val pending = _pendingConfirmation.value ?: return
        _pendingConfirmation.value = null
        val result = toolManager.confirm(pending.id)
        _messages.value = _messages.value + ChatLine(result.message, false)
        saveHistory()
        _assistantReplies.tryEmit(result.message)
        setState(if (result.ok) AiState.READY else AiState.ERROR, if (result.ok) "Инструмент: ${result.toolId}" else "Ошибка инструмента")
    }

    fun cancelPendingTool() {
        val pending = _pendingConfirmation.value ?: return
        _pendingConfirmation.value = null
        val result = toolManager.cancel(pending.id)
        _messages.value = _messages.value + ChatLine(result.message, false)
        saveHistory()
        _assistantReplies.tryEmit(result.message)
        setState(AiState.READY, "Действие отменено")
    }

    fun clearChat() {
        _messages.value = listOf(ChatLine("Чат очищен. История удалена с устройства.", false))
        saveHistory()
    }

    private fun saveHistory() {
        runCatching {
            val array = JSONArray()
            _messages.value.takeLast(200).forEach {
                array.put(JSONObject().put("text", it.text).put("user", it.user))
            }
            historyFile.writeText(array.toString())
        }
    }

    private fun loadHistory(): List<ChatLine> = runCatching {
        if (!historyFile.exists()) return emptyList()
        val a = JSONArray(historyFile.readText())
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(ChatLine(o.optString("text"), o.optBoolean("user")))
            }
        }
    }.getOrDefault(emptyList())

    override fun onCleared() {
        job?.cancel()
        _pendingConfirmation.value = null
        ai.close()
        super.onCleared()
    }

    companion object {
        private fun statusText(state: AiState) = when (state) {
            AiState.NO_MODEL -> "Модель не установлена"
            AiState.IMPORTING -> "Копирование модели…"
            AiState.READY_TO_START -> "Модель установлена"
            AiState.STARTING -> "Запуск локальной модели…"
            AiState.READY -> "OFFLINE AI готов"
            AiState.GENERATING -> "AI генерирует ответ…"
            AiState.ERROR -> "Ошибка"
            AiState.WAITING_CONFIRMATION -> "Ожидается подтверждение"
        }
    }
}
