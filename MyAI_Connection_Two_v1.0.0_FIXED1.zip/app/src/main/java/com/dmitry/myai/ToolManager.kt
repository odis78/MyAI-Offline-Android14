package com.dmitry.myai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Vibrator
import android.os.VibrationEffect
import android.provider.MediaStore
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Native tool layer. Deterministic commands and validated LLM tool calls share this class. */
class ToolManager(private val context: Context) {
    enum class Risk { SAFE, CONFIRM }

    data class PendingConfirmation(
        val id: String,
        val title: String,
        val detail: String,
        val risk: Risk = Risk.CONFIRM,
    )

    data class Result(
        val handled: Boolean,
        val message: String = "",
        val pending: PendingConfirmation? = null,
        val toolId: String = "",
        val ok: Boolean = true,
    )

    private data class PendingAction(val confirmation: PendingConfirmation, val action: () -> Result)

    private val log = ActionLog(context)
    private val memory = MemoryStore(context)
    private val pending = LinkedHashMap<String, PendingAction>()

    fun preview(command: String): MyAiIntentEngine.Intent = MyAiIntentEngine.parse(command)

    @Synchronized fun execute(command: String): Result {
        val intent = MyAiIntentEngine.parse(command)
        if (intent is MyAiIntentEngine.Intent.Unknown) return Result(handled = false)
        return executeIntent(command, intent, allowConfirmation = true)
    }

    /** Execute one schema-validated LLM tool call without routing back through the natural-language parser. */
    private val registry = ToolRegistry().apply {
        register("go_home") { runAccessibility("go_home", "go_home", "Готово. Открыт главный экран.") { MyAiAccessibilityService.goHome() } }
        register("go_back") { runAccessibility("go_back", "go_back", "Готово. Выполнено «Назад».") { MyAiAccessibilityService.goBack() } }
        register("open_recents") { runAccessibility("open_recents", "open_recents", "Готово. Открыты последние приложения.") { MyAiAccessibilityService.openRecents() } }
        register("open_notifications") { runAccessibility("open_notifications", "open_notifications", "Готово. Открыты уведомления.") { MyAiAccessibilityService.notifications() } }
        register("read_screen") { readScreenTool("read_screen") }
        register("click_text") { args -> val text = args.getString("text"); runAccessibility("click_text", "click_text", "Готово. Нажал «${text.take(160)}».") { MyAiAccessibilityService.clickText(text) } }
        register("tap") { args -> runAccessibility("tap", "tap", "Готово. Выполнено касание ${format(args.getDouble("x").toFloat())}, ${format(args.getDouble("y").toFloat())}.") { MyAiAccessibilityService.tapAndWait(args.getDouble("x").toFloat(), args.getDouble("y").toFloat()) } }
        register("scroll_forward") { runAccessibility("scroll_forward", "scroll_forward", "Готово. Экран прокручен вниз.") { MyAiAccessibilityService.scroll(true) } }
        register("scroll_backward") { runAccessibility("scroll_backward", "scroll_backward", "Готово. Экран прокручен вверх.") { MyAiAccessibilityService.scroll(false) } }
        register("type_text") { args -> runTypeText("type_text", args.getString("text")) }
        register("wait_for_text") { args -> waitForText(args.getString("text")) }
        register("wait_idle") { waitIdle() }
        register("open_settings") { openTargetDirect("open_settings", "Настройки", Settings.ACTION_SETTINGS) }
        register("open_calculator") { openCalculatorTool("open_calculator") }
        register("open_browser") { args -> openBrowser(args.optString("query", "")).copy(toolId = "open_browser") }
        register("open_chrome") { openPackageTool("open_chrome", "Chrome", "com.android.chrome") }
        register("open_camera") { start("Камера", Intent(MediaStore.ACTION_IMAGE_CAPTURE)).copy(toolId = "open_camera") }
        register("open_maps") { args -> openMapsTool("open_maps", args.optString("query", "")) }
        register("open_telegram") { openPackageTool("open_telegram", "Telegram", "org.telegram.messenger") }
        register("open_whatsapp") { openPackageTool("open_whatsapp", "WhatsApp", "com.whatsapp") }
        register("open_youtube") { openPackageTool("open_youtube", "YouTube", "com.google.android.youtube") }
        register("open_email") { start("Почта", Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_EMAIL)).copy(toolId = "open_email") }
        register("open_url") { args -> openUrl(args.getString("url")).copy(toolId = "open_url") }
        register("device_info") { Result(true, deviceText(), toolId = "device_info") }
        register("time") { Result(true, currentTime(), toolId = "time") }
        register("call") { args -> requestConfirmation("LLM: call", "call", "Разрешить звонок?", "Будет открыт системный набор номера ${args.getString("number")}.") { dial(args.getString("number"), "call") } }
        register("sms") { args -> requestConfirmation("LLM: sms", "sms", "Разрешить открыть SMS?", "Откроется системное окно SMS с подготовленным текстом.") { sms(args.optString("number", ""), args.getString("body"), "sms") } }
        register("email") { args -> requestConfirmation("LLM: email", "email", "Разрешить открыть письмо?", "Откроется системный почтовый экран с подготовленным текстом.") { email(args.optString("to", ""), args.optString("subject", ""), args.getString("body"), "email") } }
        register("save_note") { args -> val body = args.getString("body"); val title = args.optString("title", body.substringBeforeAny(".!?\n").take(80).ifBlank { "Заметка" }); val n = memory.saveNote(title, body); Result(true, "Заметка сохранена: ${n.title}", toolId = "save_note") }
        register("search_notes") { args -> val notes = memory.searchNotes(args.getString("query")); val message = if (notes.isEmpty()) "Ничего не найдено в локальной памяти." else notes.joinToString("\n\n") { "${it.title}: ${it.body}" }; Result(true, message, toolId = "search_notes") }
        register("create_reminder") { args -> val r = memory.addReminder(args.getString("title"), args.optString("when", "позже")); Result(true, "Локальное напоминание сохранено: ${r.title} (${r.whenLabel}).", toolId = "create_reminder") }
        register("analyze_text") { args -> analyzeText(args.getString("text")).copy(toolId = "analyze_text") }
        register("vibrate") { args -> vibrate(args.optLong("ms", 40L)).copy(toolId = "vibrate") }
        register("share_text") { args -> shareText(args.optString("title", "MyAI"), args.getString("text")).copy(toolId = "share_text") }
    }

    fun registeredToolNames(): Set<String> = registry.registeredNames()

    /** Execute one schema-validated LLM tool call without routing back through the natural-language parser. */
    @Synchronized fun executeToolCall(tool: String, args: org.json.JSONObject): Result {
        val normalized = tool.trim()
        if (normalized !in ToolRegistry.names()) {
            return Result(true, "Инструмент заблокирован валидатором: $normalized", toolId = normalized, ok = false)
        }
        return try {
            val result = registry.execute(normalized, args)
                ?: return Result(true, "Инструмент не зарегистрирован: $normalized", toolId = normalized, ok = false)
            log.record("agent-tool", normalized, result.message, result.ok)
            result
        } catch (e: Exception) {
            val detail = e.message ?: e.javaClass.simpleName
            log.record("agent-tool-error", normalized, detail, false)
            Result(true, "Ошибка инструмента $normalized: $detail", toolId = normalized, ok = false)
        }
    }

    private fun readScreenTool(toolId: String): Result {
        val screen = MyAiAccessibilityService.readScreen()
        return if (screen.isBlank()) Result(true, accessibilityRequired(), toolId = toolId, ok = false)
        else Result(true, "Текст текущего экрана:\n${screen.take(5000)}", toolId = toolId)
    }

    private fun runTypeText(toolId: String, text: String): Result {
        if (!MyAiAccessibilityService.isEnabled()) return Result(true, accessibilityRequired(), toolId = toolId, ok = false)
        val before = MyAiAccessibilityService.focusedEditableText()
        val ok = MyAiAccessibilityService.typeText(text)
        if (!ok) return Result(true, "Не удалось ввести текст: активное редактируемое поле не найдено.", toolId = toolId, ok = false)
        MyAiAccessibilityService.waitIdle(250)
        val after = MyAiAccessibilityService.focusedEditableText()
        val verified = text.isBlank() || after.contains(text, ignoreCase = false)
        val verification = if (verified) "Ввод подтверждён в поле." else "Ввод не подтверждён: содержимое поля не совпало полностью."
        return Result(true, "Текст введён. $verification\nПредыдущее содержимое: ${before.take(240)}\nТекущее содержимое: ${after.take(240)}", toolId = toolId, ok = verified)
    }

    private fun openTargetDirect(toolId: String, label: String, action: String): Result =
        start(label, Intent(action)).copy(toolId = toolId)

    private fun openPackageTool(toolId: String, label: String, pkg: String): Result =
        if (openPackage(pkg)) Result(true, "Готово. Открыт $label.", toolId = toolId) else Result(true, "$label не найден на телефоне.", toolId = toolId, ok = false)

    private fun openCalculatorTool(toolId: String): Result =
        if (openFirstMatching("com.google.android.calculator", "com.android.calculator2", "com.coloros.calculator")) Result(true, "Готово. Открыт калькулятор.", toolId = toolId)
        else Result(true, "Не нашёл калькулятор на телефоне.", toolId = toolId, ok = false)

    private fun openMapsTool(toolId: String, query: String): Result {
        val q = query.trim()
        val uri = if (q.isBlank()) Uri.parse("geo:0,0?q=пункт назначения") else Uri.parse("geo:0,0?q=${Uri.encode(q)}")
        return start("Карты", Intent(Intent.ACTION_VIEW, uri)).copy(toolId = toolId)
    }

    @Synchronized fun confirm(id: String): Result {
        val request = pending.remove(id) ?: return Result(true, "Подтверждение устарело. Повтори команду.", toolId = "confirmation", ok = false)
        val result = request.action()
        log.record("tool-confirm", request.confirmation.title, result.message, result.ok)
        return result
    }

    @Synchronized fun cancel(id: String): Result {
        val request = pending.remove(id)
        val result = Result(true, if (request == null) "Действие уже отменено." else "Действие отменено.", toolId = "confirmation-cancel")
        log.record("tool-cancel", request?.confirmation?.title ?: "unknown", result.message, true)
        return result
    }

    private fun executeIntent(command: String, intent: MyAiIntentEngine.Intent, allowConfirmation: Boolean): Result {
        val toolId = MyAiIntentEngine.toolId(intent)
        val result = when (intent) {
            MyAiIntentEngine.Intent.Help -> Result(true, helpText(), toolId = toolId)
            MyAiIntentEngine.Intent.Home -> runAccessibility(toolId, command, "Готово. Открыт главный экран.") { MyAiAccessibilityService.goHome() }
            MyAiIntentEngine.Intent.Back -> runAccessibility(toolId, command, "Готово. Выполнено «Назад».") { MyAiAccessibilityService.goBack() }
            MyAiIntentEngine.Intent.Recents -> runAccessibility(toolId, command, "Готово. Открыты последние приложения.") { MyAiAccessibilityService.openRecents() }
            MyAiIntentEngine.Intent.Notifications -> runAccessibility(toolId, command, "Готово. Открыты уведомления.") { MyAiAccessibilityService.notifications() }
            MyAiIntentEngine.Intent.ReadScreen -> {
                val screen = MyAiAccessibilityService.readScreen()
                if (screen.isBlank()) Result(true, accessibilityRequired(), toolId = toolId, ok = false)
                else Result(true, "Текст текущего экрана:\n${screen.take(5000)}", toolId = toolId)
            }
            is MyAiIntentEngine.Intent.ClickText -> {
                if (intent.text.isBlank()) Result(true, "Укажи, что найти и нажать.", toolId = toolId, ok = false)
                else runAccessibility(toolId, command, "Готово. Нажал «${intent.text}».") { MyAiAccessibilityService.clickText(intent.text) }
            }
            is MyAiIntentEngine.Intent.Tap -> runAccessibility(toolId, command, "Готово. Выполнено касание ${format(intent.x)}, ${format(intent.y)}.") { MyAiAccessibilityService.tapAndWait(intent.x, intent.y) }
            is MyAiIntentEngine.Intent.Scroll -> runAccessibility(toolId, command, "Готово. Экран прокручен ${if (intent.forward) "вниз" else "вверх"}.") { MyAiAccessibilityService.scroll(intent.forward) }
            is MyAiIntentEngine.Intent.TypeText -> runAccessibility(toolId, command, "Готово. Текст введён в активное поле.") { MyAiAccessibilityService.typeText(intent.text) }
            MyAiIntentEngine.Intent.Device -> Result(true, deviceText(), toolId = toolId)
            MyAiIntentEngine.Intent.Time -> Result(true, currentTime(), toolId = toolId)
            is MyAiIntentEngine.Intent.Open -> openTarget(command, intent)
            is MyAiIntentEngine.Intent.Call -> {
                if (intent.number.isBlank()) Result(true, "Укажи номер, например: «позвони +79001234567».", toolId = toolId, ok = false)
                else if (allowConfirmation) requestConfirmation(command, toolId, "Разрешить звонок?", "Будет открыт системный экран набора номера ${intent.number}. Сам MyAI звонок автоматически не совершает.") { dial(intent.number, toolId) }
                else dial(intent.number, toolId)
            }
            is MyAiIntentEngine.Intent.Sms -> {
                if (allowConfirmation) requestConfirmation(command, toolId, "Разрешить открыть SMS?", "Откроется системное окно сообщения. Текст будет подставлен, но отправка останется под контролем пользователя.") { sms(intent.number.orEmpty(), intent.body, toolId) }
                else sms(intent.number.orEmpty(), intent.body, toolId)
            }
            is MyAiIntentEngine.Intent.Email -> {
                if (allowConfirmation) requestConfirmation(command, toolId, "Разрешить открыть письмо?", "Откроется системный почтовый экран с подготовленным текстом. Автоматической отправки не будет.") { email(intent.to.orEmpty(), intent.subject.orEmpty(), intent.body, toolId) }
                else email(intent.to.orEmpty(), intent.subject.orEmpty(), intent.body, toolId)
            }
            is MyAiIntentEngine.Intent.Note -> {
                val n = memory.saveNote(intent.title, intent.body)
                Result(true, "Заметка сохранена локально: ${n.title}", toolId = toolId)
            }
            is MyAiIntentEngine.Intent.Reminder -> {
                val r = memory.addReminder(intent.title, intent.whenLabel)
                Result(true, "Напоминание сохранено локально: ${r.title} (${r.whenLabel}).", toolId = toolId)
            }
            is MyAiIntentEngine.Intent.Analyze -> analyzeText(intent.text).copy(toolId = toolId)
            MyAiIntentEngine.Intent.Vibrate -> vibrate(40L).copy(toolId = toolId)
            is MyAiIntentEngine.Intent.Share -> shareText("MyAI", intent.text).copy(toolId = toolId)
            MyAiIntentEngine.Intent.Unknown -> Result(false)
        }
        if (result.handled && result.pending == null) log.record("tool", command, result.message, result.ok)
        return result
    }

    private fun requestConfirmation(command: String, toolId: String, title: String, detail: String, action: () -> Result): Result {
        val id = "confirm-${System.currentTimeMillis()}-${pending.size}"
        val confirmation = PendingConfirmation(id, title, detail)
        pending[id] = PendingAction(confirmation, action)
        val result = Result(true, "Требуется подтверждение: $title", confirmation, toolId = toolId)
        log.record("tool-pending", command, detail, true)
        return result
    }

    private fun runAccessibility(toolId: String, command: String, success: String, block: () -> Boolean): Result {
        val ok = runCatching { block() }.getOrDefault(false)
        if (!ok) return Result(true, accessibilityRequired(), toolId = toolId, ok = false)
        MyAiAccessibilityService.waitIdle(650)
        val observation = MyAiAccessibilityService.readScreen().take(1800)
        val pkg = MyAiAccessibilityService.activePackage()
        val pkgLine = if (pkg.isBlank()) "Активное приложение: неизвестно." else "Активное приложение: $pkg"
        val detail = if (observation.isBlank()) "Экран после действия прочитать не удалось." else "Проверка экрана после действия:\n$observation"
        return Result(true, "$success\n$pkgLine\n$detail", toolId = toolId)
    }

    private fun waitForText(text: String): Result {
        val ok = MyAiAccessibilityService.waitForText(text.take(300), 2500)
        return if (ok) Result(true, "Элемент «$text» найден на экране.", toolId = "wait_for_text")
        else Result(true, "Не дождался текста «$text» за 2,5 с. Экран:\n${MyAiAccessibilityService.readScreen().take(1800)}", toolId = "wait_for_text", ok = false)
    }

    private fun waitIdle(): Result {
        MyAiAccessibilityService.waitIdle(800)
        return Result(true, "Подождал обновление интерфейса. Текущий экран:\n${MyAiAccessibilityService.readScreen().take(1800)}", toolId = "wait_idle")
    }

    private fun openBrowser(query: String): Result {
        val target = query.trim()
        val uri = if (target.isBlank()) Uri.parse("https://www.google.com") else Uri.parse(if (target.startsWith("http://") || target.startsWith("https://")) target else "https://www.google.com/search?q=${Uri.encode(target)}")
        return start("Браузер", Intent(Intent.ACTION_VIEW, uri)).copy(toolId = "open_browser")
    }

    private fun openUrl(url: String): Result = start("Ссылка", Intent(Intent.ACTION_VIEW, Uri.parse(url))).copy(toolId = "open_url")

    private fun openTarget(command: String, intent: MyAiIntentEngine.Intent.Open): Result {
        val result = when (intent.target) {
            MyAiIntentEngine.Target.SETTINGS -> start("Настройки", Intent(Settings.ACTION_SETTINGS))
            MyAiIntentEngine.Target.CALCULATOR -> if (openFirstMatching("com.google.android.calculator", "com.android.calculator2", "com.coloros.calculator")) Result(true, "Готово. Открыт калькулятор.") else Result(true, "Не нашёл калькулятор на телефоне.", ok = false)
            MyAiIntentEngine.Target.BROWSER -> openBrowser(intent.query.orEmpty())
            MyAiIntentEngine.Target.CHROME -> if (openPackage("com.android.chrome")) Result(true, "Готово. Открыт Chrome.") else openBrowser("")
            MyAiIntentEngine.Target.CAMERA -> start("Камера", Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            MyAiIntentEngine.Target.MAPS -> {
                val q = intent.query?.trim().orEmpty()
                val uri = if (q.isBlank()) Uri.parse("geo:0,0?q=пункт назначения") else Uri.parse("geo:0,0?q=${Uri.encode(q)}")
                start("Карты", Intent(Intent.ACTION_VIEW, uri))
            }
            MyAiIntentEngine.Target.TELEGRAM -> if (openPackage("org.telegram.messenger")) Result(true, "Готово. Открыт Telegram.") else appMissing("Telegram")
            MyAiIntentEngine.Target.WHATSAPP -> if (openPackage("com.whatsapp")) Result(true, "Готово. Открыт WhatsApp.") else appMissing("WhatsApp")
            MyAiIntentEngine.Target.YOUTUBE -> if (openPackage("com.google.android.youtube")) Result(true, "Готово. Открыт YouTube.") else appMissing("YouTube")
            MyAiIntentEngine.Target.EMAIL -> start("Почта", Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_EMAIL))
        }
        val withId = result.copy(toolId = MyAiIntentEngine.toolId(intent))
        if (!withId.ok) return withId
        if (intent.target == MyAiIntentEngine.Target.SETTINGS || intent.target == MyAiIntentEngine.Target.CALCULATOR ||
            intent.target == MyAiIntentEngine.Target.BROWSER || intent.target == MyAiIntentEngine.Target.MAPS ||
            intent.target == MyAiIntentEngine.Target.CAMERA || intent.target == MyAiIntentEngine.Target.TELEGRAM ||
            intent.target == MyAiIntentEngine.Target.WHATSAPP || intent.target == MyAiIntentEngine.Target.YOUTUBE ||
            intent.target == MyAiIntentEngine.Target.CHROME || intent.target == MyAiIntentEngine.Target.EMAIL) {
            MyAiAccessibilityService.waitIdle(800)
            val screen = MyAiAccessibilityService.readScreen().take(1200)
            val pkg = MyAiAccessibilityService.activePackage()
            val packageLine = if (pkg.isBlank()) "" else "\nАктивное приложение: $pkg"
            return if (screen.isBlank()) withId else withId.copy(message = withId.message + packageLine + "\nПроверка экрана:\n" + screen)
        }
        return withId
    }

    private fun dial(number: String, toolId: String): Result = start("Набор номера", Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))).copy(toolId = toolId)
    private fun sms(number: String, body: String, toolId: String): Result {
        val uri = if (number.isBlank()) Uri.parse("smsto:") else Uri.parse("smsto:${Uri.encode(number)}")
        return start("Сообщения", Intent(Intent.ACTION_SENDTO, uri).apply { putExtra("sms_body", body.take(4000)) }).copy(toolId = toolId)
    }
    private fun email(to: String, subject: String, body: String, toolId: String): Result {
        val uri = Uri.parse("mailto:${Uri.encode(to)}")
        return start("Почта", Intent(Intent.ACTION_SENDTO, uri).apply { putExtra(Intent.EXTRA_SUBJECT, subject.take(300)); putExtra(Intent.EXTRA_TEXT, body.take(8000)) }).copy(toolId = toolId)
    }
    private fun start(label: String, intent: Intent): Result {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent); Result(true, "Готово. Открыт экран: $label.") }
            .getOrElse { Result(true, "Не удалось открыть $label: ${it.message ?: it.javaClass.simpleName}", ok = false) }
    }
    private fun openPackage(pkg: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent); true }.getOrDefault(false)
    }
    private fun openFirstMatching(vararg packages: String): Boolean = packages.any { openPackage(it) }
    private fun appMissing(name: String) = Result(true, "$name не найден на телефоне.", ok = false)

    private fun analyzeText(text: String): Result {
        val words = text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        val sentences = text.split(Regex("[.!?…]+" )).count { it.isNotBlank() }
        val chars = text.length
        val lang = if (text.count { it in 'а'..'я' || it in 'А'..'Я' } > text.count { it in 'a'..'z' || it in 'A'..'Z' }) "русский" else "латиница/смешанный"
        return Result(true, "Локальный анализ текста:\nСимволов: $chars\nСлов: ${words.size}\nПредложений: $sentences\nЯзык: $lang", toolId = "analyze_text")
    }

    private fun vibrate(ms: Long): Result {
        return runCatching {
            val vibrator = context.getSystemService(Vibrator::class.java) ?: error("Vibrator не найден")
            vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            Result(true, "Короткая вибрация выполнена.", toolId = "vibrate")
        }.getOrElse { Result(true, "Не удалось вибрировать: ${it.message ?: it.javaClass.simpleName}", toolId = "vibrate", ok = false) }
    }

    private fun shareText(title: String, text: String): Result {
        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, title.take(200)); putExtra(Intent.EXTRA_TEXT, text.take(8000)) }
        return start("Окно «Поделиться»", Intent.createChooser(send, "Отправить через MyAI"))
            .copy(toolId = "share_text")
    }

    private fun accessibilityRequired() = "Для этого инструмента включи службу «MyAI — управление телефоном» в настройках специальных возможностей."
    private fun currentTime(): String = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale("ru", "RU")).format(Date())
    private fun deviceText(): String {
        val am = context.getSystemService(android.app.ActivityManager::class.java)
        val mem = android.app.ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val p = RealmePerformanceProfile(context).snapshot()
        return """Устройство: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}
Android: ${android.os.Build.VERSION.RELEASE} / API ${android.os.Build.VERSION.SDK_INT}
CPU-ядер: ${p.cpuCores}
Свободная RAM: ${mem.availMem / 1_048_576} MB из ${mem.totalMem / 1_048_576} MB
Thermal: ${p.thermalStatus}
Стартовый профиль: ${p.profile} / ${p.recommendedThreads} поток(а)"""
    }
    private fun format(value: Float): String = if (value % 1f == 0f) value.toInt().toString() else "%.1f".format(Locale.US, value)
    private fun String.substringBeforeAny(chars: String): String { val idx = chars.map { indexOf(it) }.filter { it >= 0 }.minOrNull() ?: length; return substring(0, idx) }
    private fun helpText() = """Я умею работать с телефоном через Android-инструменты и выполнять цепочки действий.
Безопасные: «домой», «назад», «последние приложения», «уведомления», «прочитай экран», «найди … и нажми», «прокрути», «введи», «открой настройки/Telegram/Chrome/камеру/карты».
Дополнительно: заметки, поиск по памяти, локальные напоминания, анализ текста, вибрация и окно «Поделиться». После действия MyAI старается проверить экран и может подождать появления нужного текста.
Звонки/SMS/почта требуют подтверждения.
Свободные задачи обрабатывает выбранная локальная GGUF-модель."""
}
