# MyAI Third Branch — текущая инженерная итерация

Версия приложения: 0.8.0-neural-voice-realme8 (versionCode 800)

## Добавлено
- Agent Loop до 4 последовательных шагов.
- `done=true` для досрочного безопасного завершения задачи.
- Строгая JSON-схема: только `tool/args/answer/done`.
- Строгая проверка типов args: строки, числа, URL, телефонные номера и диапазоны.
- Сохранение последнего observation при protocol retry.
- Рабочая память агента: последние 5 шагов в текущей задаче.
- Короткий Observation Diff вместо передачи полного экрана после каждого действия.
- Проверка изменения активного Android package.
- LLM -> ToolManager без повторного запуска natural-language parser.
- `click_text`: exact → contains → консервативный fuzzy match.
- `type_text`: проверка focused editable field после ввода.
- Trace последних шагов агента в интерфейсе чата.
- Thermal governor между шагами агента.
- Per-model GGUF thread profile остаётся отдельным для каждой модели.

## Сохранено
- Offline ASR как primary путь; Android SpeechRecognizer остаётся fallback.
- Neural TTS + System TTS fallback.
- GGUF/Qwen/llama.cpp.
- Android Accessibility Service.
- Локальные модели, голоса, ASR, история, память и настройки.
- Версия `0.8.0`, versionCode `800`.

## Проверки
- `sanity_check.sh`: PASS
- 34/34 schema tools имеют обработчики `ToolManager`
- Kotlin source/static architecture check: PASS
- ZIP integrity: PASS
- Полная Gradle-сборка в этой среде не подтверждена из-за отсутствия доступа к загрузке Gradle/dependencies; финальная сборка выполняется GitHub Actions.


## Итерация 2 — Agent/Tool refactor
- `runAgentLoop` вынесен из `ChatViewModel` в `AgentLoop.kt`.
- Добавлены `Observation.kt` и `AgentTrace.kt` как отдельные модели контекста.
- `ToolRegistry.kt` стал единым реестром LLM-visible tools и runtime handlers.
- `ToolManager.executeToolCall()` больше не содержит гигантский `when`: обработчики зарегистрированы через `ToolRegistry`.
- `AgentToolSchema` теперь получает descriptions/args из `ToolRegistry`, исключая расхождение двух списков.
- Cancellation проверяется между native generation calls; во время одного llama.cpp вызова используется существующая защита `NonCancellable`.
- Accessibility добавил явный `hasFocusedEditable()`; observation больше не считает пустое поле потерянным фокусом.
- CI дополнен проверками новой агентной архитектуры и arm64 native libraries.

### Проверка этой итерации
- sanity_check.sh: PASS
- shell syntax: PASS
- ToolRegistry: 34 canonical tools / 34 runtime handlers
- ChatViewModel: `runAgentLoop` отсутствует
- ZIP integrity: PASS
