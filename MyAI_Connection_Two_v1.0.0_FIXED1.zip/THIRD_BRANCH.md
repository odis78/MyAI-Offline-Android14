# MyAI — Third Branch

Experimental agent branch based on the tested second-branch foundation.

## Added in this iteration
- Canonical AgentToolSchema for model-to-tool communication.
- Strict JSON validation and protocol retry (max 2 attempts).
- Serial LlamaSession so a multi-step agent loop does not reload the GGUF model on every step.
- Agent loop limited to 4 steps.
- Observation after Android actions.
- Thermal-aware session thread selection and step-level maxTokens governor.
- Offline sherpa-onnx ASR remains the primary voice path; Android SpeechRecognizer is fallback.
- RMX3085 release checklist.

## Version policy
- versionCode = 800
- versionName = 0.8.0-neural-voice-realme8

This branch must remain independent of the first and second branches.
