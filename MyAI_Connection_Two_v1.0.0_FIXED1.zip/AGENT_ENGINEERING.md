# MyAI v0.8.0 — Agent Engineering layer

## Added
- Strict LLM JSON tool protocol (`AgentToolParser`).
- Agent loop: local GGUF/llama.cpp -> tool -> observation -> next step, max 4 steps.
- Tool allowlist and argument validation.
- Accessibility calls marshalled to Android main thread.
- Post-action screen observation plus `wait_for_text` / `wait_idle`.
- Per-model GGUF thread profile.
- Thermal governor for agent inference threads/maxTokens.
- Durable local `MemoryStore` for notes/reminders.
- Deterministic note/reminder/analyze/vibrate/share fast paths.
- Engineering diagnostics for agent protocol, memory and GGUF profile.

## Data preservation
Existing app-private data paths remain unchanged. The new memory is under `filesDir/memory`.
The app version remains `versionCode=800`, `versionName=0.8.0-neural-voice-realme8`.

## Validation
- `sanity_check.sh`: expected to pass.
- Kotlin parser smoke test: deterministic command cases pass.
- Full Gradle build must be verified in CI because this environment cannot reach `services.gradle.org`.

## Third Branch hardening
- `done=true` terminates the agent without wasting a tool step.
- Observation is reduced to a short line-set diff plus active package.
- LLM tool calls go directly to `ToolManager`, bypassing the natural-language parser.
- Accessibility click uses exact, contains, then conservative fuzzy matching.
- `type_text` verifies the focused editable field after input.
- JSON top-level fields and argument primitive types are validated.
