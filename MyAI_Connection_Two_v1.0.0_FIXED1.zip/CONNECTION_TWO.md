# Соединение двух — первый рабочий прототип

## Что соединено
- База: MyAI Offline Realme 8 v0.8.0 Neural Voice (третья ветка).
- Второе приложение: установленный Android-клиент ChatGPT, package `com.openai.chatgpt`.
- Интеграция реализована как отдельное Android-приложение/мост, а не как модификация или встраивание APK ChatGPT.

## Первый этап
1. Открыть ChatGPT из MyAI.
2. Передать произвольный текст в ChatGPT через стандартный Android `ACTION_SEND`.
3. MyAI продолжает работать автономно независимо от наличия ChatGPT.

## Ограничение
Закрытый APK ChatGPT не содержит исходников, поэтому его внутренний код/модель/историю нельзя легально и технически надёжно встроить в MyAI только из APK. Более глубокий обмен требует официального API/поддерживаемого Android-механизма.

## Сборка
- package: `com.dmitry.myai.connectiontwo`
- versionName: `1.0.0-connection-two`
- minSdk 28
- target/compile SDK 34
- JDK 17
- Gradle 8.9
