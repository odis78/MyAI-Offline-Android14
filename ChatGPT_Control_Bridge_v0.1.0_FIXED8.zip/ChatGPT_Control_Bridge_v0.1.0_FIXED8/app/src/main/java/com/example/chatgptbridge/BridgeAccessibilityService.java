package com.example.chatgptbridge;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.graphics.Rect;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;

public class BridgeAccessibilityService extends AccessibilityService {
    public static final String CHATGPT = "com.openai.chatgpt";
    public static final String BRIDGE = "com.example.chatgptbridge";
    private static BridgeAccessibilityService instance;
    private String currentPackage="", previousPackage="";
    private final ArrayDeque<String> logs=new ArrayDeque<>();

    public static BridgeAccessibilityService getInstance(){ return instance; }
    @Override public void onServiceConnected(){ super.onServiceConnected(); instance=this; log("SERVICE CONNECTED FIXED8"); }
    @Override public void onDestroy(){ if(instance==this) instance=null; log("SERVICE DESTROYED"); super.onDestroy(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        CharSequence p=e.getPackageName(); if(p==null) return; String pkg=p.toString();
        if(!pkg.equals(BRIDGE) && !pkg.equals("com.android.launcher") && !pkg.equals("com.android.systemui") && !pkg.equals(currentPackage)) { previousPackage=currentPackage; currentPackage=pkg; log("WINDOW "+pkg); }
    }
    @Override public void onInterrupt(){ log("SERVICE INTERRUPT"); }

    public synchronized void log(String s){ String line=String.format(Locale.US,"%tT  %s",new Date(),s); logs.addLast(line); while(logs.size()>300) logs.removeFirst(); MainActivity.pushLog(line); }
    public synchronized String dumpLog(){ StringBuilder b=new StringBuilder(); for(String s:logs)b.append(s).append('\n'); return b.toString(); }

    public boolean executeCommand(String raw){
        String x=raw==null?"":raw.trim().toLowerCase(Locale.ROOT); if(x.isEmpty()) return false;
        log("COMMAND: "+raw);
        if(x.equals("домой")||x.equals("home")){ boolean r=performGlobalAction(GLOBAL_ACTION_HOME); log("ACTION HOME result="+r); return r; }
        if(x.contains("вверх")){ boolean r=scroll(false); log("ACTION SCROLL UP result="+r); return r; }
        if(x.contains("вниз")){ boolean r=scroll(true); log("ACTION SCROLL DOWN result="+r); return r; }
        if(x.equals("назад")||x.equals("back")){ boolean r=backSmart(); log("ACTION BACK SMART result="+r); return r; }
        if(x.contains("прочитать экран")||x.contains("читать экран")||x.equals("экран")){ readScreen(); return true; }
        if(x.contains("показать журнал")||x.contains("прочитать журнал")){ MainActivity.openAndShowLog(); log("ACTION SHOW LOG result=OK"); return true; }
        if(x.startsWith("ввести текст ")||x.startsWith("введи текст ")||x.startsWith("написать ")){ String t=raw.substring(raw.indexOf(' ')+1); if(t.toLowerCase(Locale.ROOT).startsWith("текст ")) t=t.substring(6); return setTextSmart(t); }
        if(x.contains("микрофон")){ return clickSmart("микрофон|microphone|voice input|voice|диктов|голос"); }
        if(x.startsWith("нажать ")){ return clickSmart(raw.substring(raw.indexOf(' ')+1)); }
        if(x.startsWith("открыть ")){ String name=raw.substring(raw.indexOf(' ')+1).trim(); return launchApp(name); }
        log("UNKNOWN COMMAND"); return false;
    }

    private AccessibilityNodeInfo getTargetRoot(){
        // The command is entered in Bridge itself, so getRootInActiveWindow() often points
        // to Bridge instead of the app the user wants to control. Prefer the last non-Bridge
        // interactive window (ChatGPT first), then fall back to the active window.
        try{
            List<android.view.accessibility.AccessibilityWindowInfo> ws=getWindows();
            AccessibilityNodeInfo fallback=null;
            for(android.view.accessibility.AccessibilityWindowInfo w:ws){
                AccessibilityNodeInfo r=w.getRoot();
                if(r==null) continue;
                CharSequence p=r.getPackageName();
                String pkg=p==null?"":p.toString();
                if(BRIDGE.equals(pkg)) continue;
                if(currentPackage.equals(pkg) || CHATGPT.equals(pkg)) return r;
                if(fallback==null) fallback=r;
            }
            if(fallback!=null) return fallback;
        }catch(Exception e){ log("WINDOW ROOT ERROR "+e); }
        AccessibilityNodeInfo active=getRootInActiveWindow();
        if(active!=null && BRIDGE.equals(String.valueOf(active.getPackageName()))){
            try{
                List<android.view.accessibility.AccessibilityWindowInfo> ws=getWindows();
                for(android.view.accessibility.AccessibilityWindowInfo w:ws){
                    AccessibilityNodeInfo r=w.getRoot();
                    if(r!=null && !BRIDGE.equals(String.valueOf(r.getPackageName()))) return r;
                }
            }catch(Exception ignored){}
        }
        return active;
    }

    private boolean scroll(boolean down){ AccessibilityNodeInfo root=getTargetRoot(); if(root==null)return false; AccessibilityNodeInfo n=findScrollable(root); if(n==null)return false; return n.performAction(down?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD); }
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n){ if(n==null)return null; if(n.isScrollable())return n; for(int i=0;i<n.getChildCount();i++){ AccessibilityNodeInfo r=findScrollable(n.getChild(i)); if(r!=null)return r; } return null; }
    private boolean backSmart(){
        String target=!TextUtils.isEmpty(currentPackage)&&!currentPackage.equals(BRIDGE)?currentPackage:previousPackage;
        if(TextUtils.isEmpty(target)||target.equals(BRIDGE)||target.equals("com.android.launcher")){ target=CHATGPT; }
        try{
            Intent i=getPackageManager().getLaunchIntentForPackage(target);
            if(i!=null){
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(i);
                log("ACTION BACK FOCUS "+target);
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(()->{
                    boolean r=performGlobalAction(GLOBAL_ACTION_BACK);
                    log("ACTION BACK AFTER FOCUS result="+r);
                },350);
                return true;
            }
        }catch(Exception e){log("BACK FOCUS ERROR "+e);}
        boolean r=performGlobalAction(GLOBAL_ACTION_BACK); log("ACTION BACK GLOBAL result="+r); return r;
    }
    private boolean launchApp(String name){
        String n=name.toLowerCase(Locale.ROOT); String pkg=null;
        if(n.contains("chatgpt")) pkg=CHATGPT; else if(n.contains("калькулятор")||n.contains("calculator")) pkg=findPackageAny("калькулятор","calculator"); else pkg=findPackageByLabel(name);
        if(pkg==null){ log("LAUNCH APP NOT FOUND: "+name); return false; }
        boolean r=launchPackage(pkg); log("LAUNCH "+pkg+" result="+r); return r;
    }
    private boolean launchPackage(String pkg){ try{ Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i==null)return false; i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED); startActivity(i); return true; }catch(Exception e){log("LAUNCH ERROR "+e);return false;} }
    private String findPackageAny(String... needles){ for(android.content.pm.ApplicationInfo a:getPackageManager().getInstalledApplications(0)){String l=a.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT); for(String needle:needles) if(l.contains(needle)) return a.packageName;} return null; }
    private String findPackageByLabel(String name){ String q=name.toLowerCase(Locale.ROOT); for(android.content.pm.ApplicationInfo a:getPackageManager().getInstalledApplications(0)){String l=a.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT); if(l.equals(q)||l.contains(q))return a.packageName;} return null; }

    private boolean setTextSmart(String text){
        AccessibilityNodeInfo root=getTargetRoot(); if(root==null){log("SET TEXT: no target root");return false;}
        AccessibilityNodeInfo n=findEditable(root); if(n==null){log("SET TEXT: editable node not found");return false;}
        Bundle b=new Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text);
        boolean r=n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b); log("SET TEXT result="+r+" class="+n.getClassName()); return r;
    }
    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n){ if(n==null)return null; if(n.isEditable() || "android.widget.EditText".contentEquals(n.getClassName()))return n; for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=findEditable(n.getChild(i));if(r!=null)return r;} return null; }

    private boolean clickSmart(String query){ AccessibilityNodeInfo root=getTargetRoot(); if(root==null){log("CLICK: no target root");return false;} String[] q=query.toLowerCase(Locale.ROOT).split("\\|"); AccessibilityNodeInfo n=findNode(root,q); if(n==null){log("CLICK NOT FOUND: "+query);return false;} boolean r=false; if(n.isClickable())r=n.performAction(AccessibilityNodeInfo.ACTION_CLICK); if(!r){ AccessibilityNodeInfo p=n.getParent(); if(p!=null&&p.isClickable())r=p.performAction(AccessibilityNodeInfo.ACTION_CLICK); } log("CLICK result="+r+" text="+n.getText()+" desc="+n.getContentDescription()+" class="+n.getClassName()); return r; }
    private AccessibilityNodeInfo findNode(AccessibilityNodeInfo n,String[] q){ if(n==null)return null; String s=((n.getText()==null?"":n.getText().toString())+" "+(n.getContentDescription()==null?"":n.getContentDescription().toString())+" "+(n.getViewIdResourceName()==null?"":n.getViewIdResourceName())).toLowerCase(Locale.ROOT); for(String z:q)if(s.contains(z))return n; for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=findNode(n.getChild(i),q);if(r!=null)return r;} return null; }

    private void readScreen(){ AccessibilityNodeInfo root=getTargetRoot(); if(root==null){log("SCREEN READ: no target root");return;} StringBuilder b=new StringBuilder(); dumpNode(root,b,0); log("SCREEN READ:\n"+b); }
    private void dumpNode(AccessibilityNodeInfo n,StringBuilder b,int depth){ if(n==null)return; String t=n.getText()==null?"":n.getText().toString().trim(); String d=n.getContentDescription()==null?"":n.getContentDescription().toString().trim(); if(!t.isEmpty()||!d.isEmpty()){ for(int i=0;i<depth;i++)b.append("  "); b.append("text=").append(t).append(" desc=").append(d).append(" class=").append(n.getClassName()).append(" clickable=").append(n.isClickable()).append(" editable=").append(n.isEditable()).append('\n'); } for(int i=0;i<n.getChildCount();i++)dumpNode(n.getChild(i),b,depth+1); }
}
