# MyAI Offline — realme 8 — v0.6

Локальный AI-ассистент для realme 8 (4G) с LiteRT-LM. Телефон официально использует MediaTek Helio G95 и поставлялся с Android 11; приложение оставлено совместимым с Android 11+ через minSdk 28. citeturn0search0turn0search7. Архитектура **offline-first**: после установки совместимой `.litertlm` модели обычный чат не требует облачного сервера.

## Что добавлено в v0.6
- сохранение истории чата локально в `files/chat_history.json`;
- менеджер нескольких `.litertlm` моделей: импорт, выбор и удаление;
- проверка свободного места перед импортом;
- голосовой ввод через Android SpeechRecognizer с приоритетом on-device recognition на Android 12+;
- озвучивание ответов через Android Text-to-Speech;
- диагностика Android/API/SoC/RAM;
- CPU backend как безопасный базовый режим для телефона;
- модель хранится отдельно от APK.

## Первая модель
Рекомендуемый старт — `Gemma3-1B-IT` INT4 LiteRT-LM, файл `gemma3-1b-it-int4.litertlm` (~584 MB). Официальный репозиторий LiteRT Community находится на Hugging Face и требует принять условия лицензии Gemma перед скачиванием.

Официальная страница модели:
https://huggingface.co/litert-community/Gemma3-1B-IT

SHA-256 канонического файла: `1325ae366d31950f137c9c357b9fa89448b176d76998180c08ceaca78bba98be`.

## Как запустить
1. Открой проект в Android Studio.
2. Дай Gradle синхронизироваться.
3. Собери APK.
4. На телефоне открой **Настройки → Импорт** и выбери `.litertlm`.
5. Нажми **Запустить**.
6. Перейди в **Чат**.

LiteRT-LM инициализируется на фоне; загрузка большой модели может занять несколько секунд.

## Важно
- APK не содержит модель.
- Не загружай модель в GitHub вместе с исходниками: модель сотни мегабайт и не нужна для сборки приложения.
- Gemma распространяется по собственным условиям лицензии Google; перед использованием ознакомься с ними.
- Голосовой ввод зависит от наличия системного on-device recognizer и языкового пакета. Полностью автономный ASR на следующем этапе можно сделать отдельным локальным Whisper/Moonshine-модулем.

## Профиль realme 8

Целевая конфигурация — **realme 8 4G (RMX3085)** на MediaTek Helio G95. Официальные характеристики realme указывают Helio G95, ARM Mali-G76 и варианты 4/6/8 ГБ RAM в зависимости от рынка. citeturn0search0turn0search3

Для первого запуска используется **CPU backend**. NPU специально не включаем: LiteRT-LM документирует NPU как аппаратно-зависимый режим, поэтому для Helio G95 безопасной базой остаётся CPU. citeturn1search1

### Рекомендуемый режим
- Gemma 3 1B IT INT4 — первый вариант для тестирования.
- Если модель окажется медленной или будет не хватать памяти, следующим вариантом можно попробовать меньшую Qwen-модель.
- Не держи одновременно много тяжёлых приложений в фоне при запуске LLM.

### Совместимость
Проект использует `minSdk 28` и `targetSdk 34`, поэтому Android 11 realme 8 подходит для установки приложения. Сам LiteRT-LM предоставляет Android Maven package и CPU/GPU/NPU backend API. citeturn1search1


## v0.6.3 FINAL
- Corrected AndroidManifest.xml: optional native libraries are declared inside `<application>`.
- Added executable `gradlew` launcher using Gradle 8.7 for GitHub Actions builds.
