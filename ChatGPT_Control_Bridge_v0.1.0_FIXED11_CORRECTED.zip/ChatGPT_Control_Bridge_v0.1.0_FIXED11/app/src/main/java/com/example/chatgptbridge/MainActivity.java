package com.example.chatgptbridge;

import android.app.*;import android.content.*;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 static final String CHATGPT="com.openai.chatgpt";
 static TextView logView;
 static ScrollView logScroll;
 static StringBuilder journal=new StringBuilder();
 static MainActivity active;
 EditText command; Uri selectedFile;

 @Override public void onCreate(Bundle b){
  super.onCreate(b); active=this;
  setContentView(R.layout.activity_main);
  logView=findViewById(R.id.log); logScroll=findViewById(R.id.logScroll); command=findViewById(R.id.command);
  loadJournal();
  findViewById(R.id.btnAccessibility).setOnClickListener(v->{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));});
  findViewById(R.id.btnChatGPT).setOnClickListener(v->launchPackage(CHATGPT));
  findViewById(R.id.btnFile).setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,10);});
  findViewById(R.id.btnEditFile).setOnClickListener(v->{if(selectedFile!=null){Intent i=new Intent(Intent.ACTION_VIEW,selectedFile);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}else appendLog("FILE: no selected file");});
  findViewById(R.id.btnExecute).setOnClickListener(v->{String c=command.getText().toString(); BridgeAccessibilityService s=BridgeAccessibilityService.getInstance(); if(s!=null)s.executeCommand(c);else appendLog("SERVICE NOT CONNECTED");});
  findViewById(R.id.btnRefresh).setOnClickListener(v->refreshJournal());
  refreshStatus();
  refreshJournal();
 }
 @Override protected void onResume(){super.onResume();active=this;refreshStatus();refreshJournal();}
 @Override protected void onDestroy(){if(active==this)active=null;super.onDestroy();}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==10&&c==RESULT_OK&&d!=null){selectedFile=d.getData();appendLog("FILE SELECTED: "+selectedFile);}}
 private void refreshStatus(){TextView s=findViewById(R.id.status);s.setText(BridgeAccessibilityService.getInstance()!=null?"Accessibility: подключён":"Accessibility: проверьте разрешение");}
 private void loadJournal(){
  String saved=getSharedPreferences("bridge_log",MODE_PRIVATE).getString("journal","");
  journal.setLength(0); journal.append(saved==null?"":saved);
  if(logView!=null) showJournal();
 }
 private void saveJournal(){getSharedPreferences("bridge_log",MODE_PRIVATE).edit().putString("journal",journal.toString()).apply();}
 private void showJournal(){
  if(logView==null)return;
  logView.setText(journal.length()==0?"Журнал пока пуст.":journal.toString());
  logView.post(()->{ if(logScroll!=null) logScroll.fullScroll(View.FOCUS_DOWN); });
 }
 private void refreshJournal(){
  BridgeAccessibilityService s=BridgeAccessibilityService.getInstance();
  if(s!=null){String serviceLog=s.dumpLog(); if(serviceLog!=null&&!serviceLog.trim().isEmpty()){journal.setLength(0);journal.append(serviceLog);saveJournal();}}
  showJournal();
 }
 static void pushLog(String x){appendLog(x);}
 static void appendLog(String x){
  if(x==null||x.isEmpty())return;
  journal.append(x).append('\n');
  if(journal.length()>30000)journal.delete(0,journal.length()-30000);
  if(active!=null)active.saveJournal();
  if(logView!=null&&active!=null)active.showJournal();
 }
 static void openAndShowLog(){Intent i=new Intent();i.setClassName(BRIDGE(),MainActivity.class.getName());i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra("show_log",true); if(BridgeAccessibilityService.getInstance()!=null)BridgeAccessibilityService.getInstance().startActivity(i);}
 static String BRIDGE(){return "com.example.chatgptbridge";}
 private boolean launchPackage(String p){try{Intent i=getPackageManager().getLaunchIntentForPackage(p);if(i==null){appendLog("CHATGPT NOT FOUND");return false;}startActivity(i);appendLog("CHATGPT LAUNCH OK");return true;}catch(Exception e){appendLog("LAUNCH ERROR "+e);return false;}}
}
