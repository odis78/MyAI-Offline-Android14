#!/usr/bin/env bash
set -euo pipefail
test -x ./gradlew
python3 -c "import xml.etree.ElementTree as ET; ET.parse(\"app/src/main/AndroidManifest.xml\")"
grep -q 'id("com.android.application") version "8.6.1"' build.gradle.kts
grep -q 'litertlm-android:0.17.1' app/build.gradle.kts
grep -q 'versionCode = 700' app/build.gradle.kts
! grep -Rqs 'kotlinOptions' app build.gradle.kts
! grep -Rqs '\.text' app/src/main/java/com/dmitry/myai/LocalAiEngine.kt
grep -q 'versionCode = 700' app/build.gradle.kts
echo "MyAI sanity check: OK"
