package com.dmitry.myai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Android control bridge for MyAI.
 *
 * The user explicitly enables this service in Android Accessibility settings.
 * Tools are intentionally deterministic: the local LLM may request a named
 * tool, but it never receives arbitrary accessibility internals to execute.
 */
class MyAiAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var instance: MyAiAccessibilityService? = null

        fun isEnabled(): Boolean = instance != null

        fun goHome(): Boolean = instance?.onMainBlocking { performGlobalAction(GLOBAL_ACTION_HOME) } == true
        fun goBack(): Boolean = instance?.onMainBlocking { performGlobalAction(GLOBAL_ACTION_BACK) } == true
        fun openRecents(): Boolean = instance?.onMainBlocking { performGlobalAction(GLOBAL_ACTION_RECENTS) } == true
        fun notifications(): Boolean = instance?.onMainBlocking { performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) } == true
        fun readScreen(): String = instance?.onMainBlocking { screenText() } ?: ""
        fun activePackage(): String = instance?.onMainBlocking {
            rootInActiveWindow?.packageName?.toString()?.trim().orEmpty()
        } ?: ""
        fun clickText(text: String): Boolean = instance?.onMainBlocking { clickTextInternal(text) } == true
        fun tap(x: Float, y: Float): Boolean = instance?.onMainBlocking { tapInternal(x, y) } == true
        fun scroll(forward: Boolean): Boolean = instance?.onMainBlocking { scrollInternal(forward) } == true
        fun typeText(text: String): Boolean = instance?.onMainBlocking { typeTextInternal(text) } == true
        fun focusedEditableText(): String = instance?.onMainBlocking { focusedEditableTextInternal() } ?: ""
        fun hasFocusedEditable(): Boolean = instance?.onMainBlocking { hasFocusedEditableInternal() } == true
        fun tapAndWait(x: Float, y: Float): Boolean = tap(x, y)
        fun waitIdle(ms: Long = 500) { Thread.sleep(ms.coerceIn(100L, 1500L)) }
        fun waitForText(text: String, timeoutMs: Long = 2500): Boolean {
            val service = instance ?: return false
            val needle = text.trim()
            if (needle.isBlank()) return false
            val deadline = System.currentTimeMillis() + timeoutMs.coerceIn(300L, 5000L)
            while (System.currentTimeMillis() < deadline) {
                if (service.onMainBlocking { service.hasTextInternal(needle) } == true) return true
                Thread.sleep(120L)
            }
            return false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private fun <T> onMainBlocking(block: () -> T): T? {
        if (Looper.myLooper() == Looper.getMainLooper()) return runCatching { block() }.getOrNull()
        val latch = CountDownLatch(1)
        val result = AtomicReference<T?>(null)
        mainHandler.post {
            try { result.set(block()) } finally { latch.countDown() }
        }
        latch.await(2500L, TimeUnit.MILLISECONDS)
        return result.get()
    }

    private fun hasTextInternal(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return try {
            findText(root, text, false)?.let { found -> found.recycle(); true } ?: false
        } finally {
            root.recycle()
        }
    }

    private fun screenText(): String {
        val root = rootInActiveWindow ?: return ""
        val out = StringBuilder()
        try {
            appendNodeText(root, out, 0)
            val pkg = root.packageName?.toString()?.trim().orEmpty()
            if (pkg.isNotBlank() && out.isNotBlank()) {
                out.insert(0, "Приложение: $pkg\n")
            }
            return out.toString().trim().take(12000)
        } finally {
            root.recycle()
        }
    }

    private fun appendNodeText(node: AccessibilityNodeInfo, out: StringBuilder, depth: Int) {
        if (depth > 45) return
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrBlank()) out.appendLine(text)
        if (!desc.isNullOrBlank() && desc != text) out.appendLine(desc)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                appendNodeText(child, out, depth + 1)
                child.recycle()
            }
        }
    }

    private fun clickTextInternal(target: String): Boolean {
        val cleanTarget = target.trim()
        if (cleanTarget.isBlank()) return false
        val root = rootInActiveWindow ?: return false
        try {
            findText(root, cleanTarget, true)?.let { node ->
                return try { performNodeClick(node) } finally { node.recycle() }
            }
            findText(root, cleanTarget, false)?.let { node ->
                return try { performNodeClick(node) } finally { node.recycle() }
            }
            findFuzzyText(root, cleanTarget)?.let { node ->
                return try { performNodeClick(node) } finally { node.recycle() }
            }
            return false
        } finally {
            root.recycle()
        }
    }

    private fun performNodeClick(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

        var parent = node.parent
        var levels = 0
        while (parent != null && levels < 7) {
            if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                parent.recycle()
                return true
            }
            val next = parent.parent
            parent.recycle()
            parent = next
            levels++
        }

        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        return if (bounds.width() > 0 && bounds.height() > 0) {
            tapInternal(bounds.centerX().toFloat(), bounds.centerY().toFloat())
        } else false
    }

    private data class FuzzyMatch(val node: AccessibilityNodeInfo, val score: Double)

    private fun findFuzzyText(root: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val normalizedTarget = normalizeForMatch(target)
        if (normalizedTarget.length < 4) return null
        val best = findBestFuzzy(root, normalizedTarget, 0) ?: return null
        val threshold = when {
            normalizedTarget.length < 7 -> 0.90
            normalizedTarget.length < 12 -> 0.84
            else -> 0.78
        }
        return if (best.score >= threshold) best.node else { best.node.recycle(); null }
    }

    private fun findBestFuzzy(node: AccessibilityNodeInfo, target: String, depth: Int): FuzzyMatch? {
        if (depth > 45) return null
        var best: FuzzyMatch? = null
        val candidates = listOf(
            node.text?.toString()?.trim().orEmpty(),
            node.contentDescription?.toString()?.trim().orEmpty()
        ).filter { it.isNotBlank() }
        for (candidate in candidates) {
            val normalized = normalizeForMatch(candidate)
            if (normalized.isBlank() || kotlin.math.abs(normalized.length - target.length) > maxOf(12, target.length)) continue
            val distance = levenshtein(target, normalized)
            val score = 1.0 - distance.toDouble() / maxOf(target.length, normalized.length)
            if (best == null || score > best!!.score) {
                best?.node?.recycle()
                best = FuzzyMatch(AccessibilityNodeInfo.obtain(node), score)
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val childBest = try { findBestFuzzy(child, target, depth + 1) } finally { child.recycle() }
            if (childBest != null && (best == null || childBest.score > best!!.score)) {
                best?.node?.recycle()
                best = childBest
            } else {
                childBest?.node?.recycle()
            }
        }
        return best
    }

    private fun normalizeForMatch(value: String): String = value
        .lowercase(java.util.Locale.getDefault())
        .replace('ё', 'е')
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var curr = IntArray(b.length + 1)
        for (i in a.indices) {
            curr[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                curr[j + 1] = minOf(curr[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = curr; curr = tmp
        }
        return prev[b.length]
    }

    private fun scrollInternal(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = findScrollable(root) ?: return false
        return try {
            val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            target.performAction(action)
        } finally {
            target.recycle()
        }
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = try {
                findScrollable(child)
            } finally {
                child.recycle()
            }
            if (found != null) return found
        }
        return null
    }

    private fun typeTextInternal(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = findFocusedEditable(root) ?: findEditable(root) ?: return false
        return try {
            val args = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        } finally {
            target.recycle()
        }
    }

    private fun hasFocusedEditableInternal(): Boolean {
        val root = rootInActiveWindow ?: return false
        return try { findFocusedEditable(root)?.let { it.recycle(); true } ?: false } finally { root.recycle() }
    }

    private fun focusedEditableTextInternal(): String {
        val root = rootInActiveWindow ?: return ""
        return try {
            val node = findFocusedEditable(root) ?: return ""
            try { node.text?.toString().orEmpty() } finally { node.recycle() }
        } finally {
            root.recycle()
        }
    }

    private fun findFocusedEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isFocused && node.isEditable) return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = try {
                findFocusedEditable(child)
            } finally {
                child.recycle()
            }
            if (found != null) return found
        }
        return null
    }

    private fun findEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = try {
                findEditable(child)
            } finally {
                child.recycle()
            }
            if (found != null) return found
        }
        return null
    }

    private fun tapInternal(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, Handler(Looper.getMainLooper()))
    }
}
