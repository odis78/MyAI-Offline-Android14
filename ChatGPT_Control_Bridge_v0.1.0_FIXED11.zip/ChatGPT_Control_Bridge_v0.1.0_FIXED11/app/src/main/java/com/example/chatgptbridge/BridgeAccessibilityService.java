package com.example.chatgptbridge;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityWindowInfo;
import android.accessibilityservice.GestureDescription;
import android.os.Handler;
import android.os.Looper;
import java.util.*;

public class BridgeAccessibilityService extends AccessibilityService {
    public static final String CHATGPT = "com.openai.chatgpt";
    public static final String BRIDGE = "com.example.chatgptbridge";
    private static final String SMART_SIDEBAR = "com.coloros.smartsidebar";
    private static final String LEFTSCREEN = "com.oplus.leftscreen";
    private static BridgeAccessibilityService instance;
    private String currentPackage="", previousPackage="", lastTargetPackage="";
    private AccessibilityNodeInfo lastSourceNode;
    private String lastSourcePackage="";
    private final Handler mainHandler=new Handler(Looper.getMainLooper());
    private final ArrayDeque<String> logs=new ArrayDeque<>();

    public static BridgeAccessibilityService getInstance(){ return instance; }
    @Override public void onServiceConnected(){ super.onServiceConnected(); instance=this; log("SERVICE CONNECTED FIXED11 TARGET-FIX"); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        CharSequence p=e.getPackageName();
        if(p==null) return;
        String pkg=p.toString();
        // System overlays, the Bridge itself and the keyboard must never replace
        // the real application as the command target.
        if(isIgnoredWindowPackage(pkg)) return;
        try {
            AccessibilityNodeInfo src=e.getSource();
            if(src!=null){
                if(lastSourceNode!=null) lastSourceNode.recycle();
                lastSourceNode=AccessibilityNodeInfo.obtain(src);
                lastSourcePackage=pkg;
            }
        } catch(Exception ignored) {}
        if(!pkg.equals(currentPackage)) {
            previousPackage=currentPackage;
            currentPackage=pkg;
            lastTargetPackage=pkg;
            log("WINDOW "+pkg);
        }
    }
    @Override public void onInterrupt(){ log("SERVICE INTERRUPT"); }
    @Override public void onDestroy(){
        try{ if(lastSourceNode!=null){lastSourceNode.recycle(); lastSourceNode=null;} }catch(Exception ignored){}
        if(instance==this) instance=null;
        log("SERVICE DESTROYED");
        super.onDestroy();
    }

    public synchronized void log(String s){ String line=String.format(Locale.US,"%tT  %s",new Date(),s); logs.addLast(line); while(logs.size()>300) logs.removeFirst(); MainActivity.pushLog(line); }
    public synchronized String dumpLog(){ StringBuilder b=new StringBuilder(); for(String s:logs)b.append(s).append('\n'); return b.toString(); }

    public boolean executeCommand(String raw){
        String x=raw==null?"":raw.trim().toLowerCase(Locale.ROOT); if(x.isEmpty()) return false;
        log("COMMAND: "+raw);
        if(x.equals("домой")||x.equals("home")){ boolean r=performGlobalAction(GLOBAL_ACTION_HOME); log("ACTION HOME result="+r); return r; }
        if(x.equals("вверх")||x.equals("верх")||x.equals("в верх")){ return scrollByGesture(false); }
        if(x.equals("вниз")||x.equals("низ")||x.equals("в низ")){ return scrollByGesture(true); }
        if(x.equals("назад")||x.equals("back")){ return backSmart(); }
        if(x.contains("прочитать экран")||x.contains("читать экран")||x.equals("экран")){
            runWithTargetRoot(this::readScreen); return true;
        }
        if(x.contains("показать журнал")||x.contains("прочитать журнал")){ MainActivity.openAndShowLog(); log("ACTION SHOW LOG result=OK"); return true; }
        if(x.startsWith("ввести текст ")||x.startsWith("введи текст ")||x.startsWith("ввод текста ")||x.startsWith("ввод текста: ")||x.startsWith("написать ")){
            int sp=raw.indexOf(' '); String t=sp>=0?raw.substring(sp+1).trim():"";
            if(t.toLowerCase(Locale.ROOT).startsWith("текст ")) t=t.substring(6);
            final String textForInput=t;
            return runWithTargetRootResult(()->setTextSmartNow(textForInput));
        }
        if(x.contains("микрофон")){ return runWithTargetRootResult(()->clickSmartNow("микрофон|microphone|voice input|voice|диктов|голос")); }
        if(x.startsWith("нажать ")){ return runWithTargetRootResult(()->clickSmartNow(raw.substring(raw.indexOf(' ')+1))); }
        if(x.startsWith("открыть файл ")){ return openFileCommand(raw.substring(raw.indexOf(' ')+1).trim()); }
        if(x.startsWith("открыть ")){ String name=raw.substring(raw.indexOf(' ')+1).trim(); return launchApp(name); }
        log("UNKNOWN COMMAND"); return false;
    }

    private boolean isIgnoredWindowPackage(String pkg){
        if(pkg==null||pkg.isEmpty()) return true;
        return BRIDGE.equals(pkg)
            || "com.android.launcher".equals(pkg)
            || "com.android.launcher3".equals(pkg)
            || "com.android.systemui".equals(pkg)
            || "com.google.android.inputmethod.latin".equals(pkg)
            || "com.android.inputmethod.latin".equals(pkg)
            || "com.google.android.inputmethod.latin.debug".equals(pkg)
            || "com.coloros.screenshot".equals(pkg)
            || "com.oplus.screenshot".equals(pkg)
            || "com.android.documentsui".equals(pkg)
            || SMART_SIDEBAR.equals(pkg)
            || LEFTSCREEN.equals(pkg);
    }

    private String resolveTargetPackage(){
        // Prefer the actual foreground application. If Bridge/system UI is on top,
        // keep the last real application instead of switching to an overlay.
        if(currentPackage!=null && !currentPackage.isEmpty() && !isIgnoredWindowPackage(currentPackage))
            return currentPackage;
        if(lastTargetPackage!=null && !lastTargetPackage.isEmpty() && !isIgnoredWindowPackage(lastTargetPackage))
            return lastTargetPackage;
        return CHATGPT;
    }

    private AccessibilityNodeInfo getTargetRoot(){
        String wanted=resolveTargetPackage();
        try{
            AccessibilityNodeInfo active=getRootInActiveWindow();
            if(active!=null){
                String pkg=String.valueOf(active.getPackageName());
                if(wanted.equals(pkg) && !isIgnoredWindowPackage(pkg)) return active;
            }
        }catch(Exception e){ log("ACTIVE ROOT ERROR "+e); }

        try{
            clearCache();
            List<AccessibilityWindowInfo> ws=getWindows();
            for(AccessibilityWindowInfo w:ws){
                AccessibilityNodeInfo r=w.getRoot();
                if(r==null) continue;
                String pkg=String.valueOf(r.getPackageName());
                if(wanted.equals(pkg) && !isIgnoredWindowPackage(pkg)) return r;
            }
        }catch(Exception e){ log("WINDOW ROOT ERROR "+e); }

        // A recent event source is often available even when ColorOS returns a
        // null window root. Walk its parent chain to recover the highest node.
        try{
            if(lastSourceNode!=null && wanted.equals(lastSourcePackage)){
                AccessibilityNodeInfo n=AccessibilityNodeInfo.obtain(lastSourceNode);
                AccessibilityNodeInfo top=n;
                for(int i=0;i<40;i++){
                    AccessibilityNodeInfo parent=top.getParent();
                    if(parent==null) break;
                    if(top!=n) top.recycle();
                    top=parent;
                }
                if(top!=null && wanted.equals(String.valueOf(top.getPackageName()))) return top;
                if(n!=top) n.recycle();
            }
        }catch(Exception e){ log("SOURCE ROOT ERROR "+e); }

        try{
            AccessibilityNodeInfo f=findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
            if(f==null) f=findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if(f!=null && wanted.equals(String.valueOf(f.getPackageName()))) return f;
        }catch(Exception e){ log("FOCUS ROOT ERROR "+e); }

        log("TARGET ROOT NOT FOUND wanted="+wanted+" current="+currentPackage+" last="+lastTargetPackage);
        return null;
    }

    private void runWithTargetRoot(Runnable action){
        String target=resolveTargetPackage();
        if(isIgnoredWindowPackage(target)){ log("TARGET ROOT: ignored target="+target); return; }
        if(isTargetForeground(target)){ action.run(); return; }
        if(!launchTargetForOperation(target)) return;
        mainHandler.postDelayed(()->action.run(),650);
    }

    private boolean runWithTargetRootResult(java.util.concurrent.Callable<Boolean> action){
        String target=resolveTargetPackage();
        if(isIgnoredWindowPackage(target)){ log("TARGET ROOT: ignored target="+target); return false; }
        if(isTargetForeground(target)){
            try{return action.call();}catch(Exception e){log("TARGET ACTION ERROR "+e);return false;}
        }
        if(!launchTargetForOperation(target)) return false;
        mainHandler.postDelayed(()->{try{action.call();}catch(Exception e){log("TARGET ACTION ERROR "+e);}},650);
        return true;
    }

    private boolean isTargetForeground(String target){
        try{AccessibilityNodeInfo r=getRootInActiveWindow(); return r!=null && target.equals(String.valueOf(r.getPackageName()));}
        catch(Exception e){return false;}
    }

    private boolean launchTargetForOperation(String target){
        try{
            Intent i=getPackageManager().getLaunchIntentForPackage(target);
            if(i==null){log("TARGET LAUNCH INTENT NOT FOUND "+target);return false;}
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
            log("TARGET LAUNCH FOR OPERATION "+target);
            return true;
        }catch(Exception e){log("TARGET LAUNCH ERROR "+e);return false;}
    }

    private boolean scrollByGesture(boolean down){
        final String target=resolveTargetPackage();
        log("GESTURE SCROLL REQUEST target="+target+" down="+down);
        if(isIgnoredWindowPackage(target)){ log("GESTURE SCROLL: ignored target="+target); return false; }
        if(isTargetForeground(target)){
            dispatchScrollGesture(down);
            return true;
        }
        if(!launchTargetForOperation(target)) return false;
        mainHandler.postDelayed(()->dispatchScrollGesture(down),650);
        return true;
    }

    private void dispatchScrollGesture(boolean down){
        try{
            // Never derive gesture coordinates from AccessibilityNodeInfo root
            // bounds. On ColorOS the root can represent only a small/hidden
            // window, which previously produced 60-70 px swipes and unintended
            // navigation. Use the real display area instead.
            int w=getResources().getDisplayMetrics().widthPixels;
            int h=getResources().getDisplayMetrics().heightPixels;
            int navSafe=96;
            int topSafe=80;
            float x=w*0.50f;
            float top=topSafe+h*0.18f;
            float bottom=h-navSafe-h*0.12f;
            if(bottom<=top+160){top=topSafe+40;bottom=h-navSafe-40;}
            float y1=down ? bottom : top;
            float y2=down ? top : bottom;
            PathData path=new PathData(x,y1,x,y2);
            GestureDescription.Builder gb=new GestureDescription.Builder();
            android.graphics.Path pathObj=new android.graphics.Path();
            pathObj.moveTo(path.x1,path.y1); pathObj.lineTo(path.x2,path.y2);
            gb.addStroke(new GestureDescription.StrokeDescription(pathObj,0,500));
            boolean dispatched=dispatchGesture(gb.build(),new GestureResultCallback(){
                @Override public void onCompleted(GestureDescription g){ log("GESTURE SCROLL "+(down?"DOWN":"UP")+" completed"); }
                @Override public void onCancelled(GestureDescription g){ log("GESTURE SCROLL "+(down?"DOWN":"UP")+" cancelled"); }
            },null);
            log("GESTURE SCROLL "+(down?"DOWN":"UP")+" dispatched="+dispatched+" x="+(int)x+" y1="+(int)y1+" y2="+(int)y2);
        }catch(Exception e){ log("GESTURE SCROLL ERROR "+e); }
    }

    private static final class PathData{ final float x1,y1,x2,y2; PathData(float a,float b,float c,float d){x1=a;y1=b;x2=c;y2=d;} }

    private boolean scroll(boolean down){
        AccessibilityNodeInfo root=getTargetRoot();
        if(root==null){log("SCROLL: no target root");return false;}
        int action=down?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD;
        AccessibilityNodeInfo n=findScrollable(root,action);
        if(n==null){log("SCROLL: no node supports action="+action);return false;}
        boolean r=n.performAction(action);
        log("SCROLL NODE action="+action+" result="+r+" class="+n.getClassName());
        return r;
    }
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n,int action){
        if(n==null)return null;
        if(n.isScrollable()){
            List<AccessibilityNodeInfo.AccessibilityAction> a=n.getActionList();
            for(AccessibilityNodeInfo.AccessibilityAction z:a)if(z.getId()==action)return n;
        }
        List<AccessibilityNodeInfo.AccessibilityAction> a=n.getActionList();
        for(AccessibilityNodeInfo.AccessibilityAction z:a)if(z.getId()==action)return n;
        for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=findScrollable(n.getChild(i),action);if(r!=null)return r;}
        return null;
    }

    private boolean backSmart(){
        final String target=resolveTargetPackage();
        if(isIgnoredWindowPackage(target)){ log("BACK: ignored target="+target+"; skipped"); return false; }

        // The command is normally entered in the Bridge itself. In that case
        // the target app is underneath the Bridge in the task stack. Launching
        // the target again and then sending GLOBAL_BACK starts a fresh/root
        // activity and can exit the app to the launcher. Instead, send Back
        // while the Bridge is on top so Android returns to the underlying app.
        if(isBridgeForeground()){
            boolean r=performGlobalAction(GLOBAL_ACTION_BACK);
            log("BACK FROM BRIDGE target="+target+" result="+r);
            return r;
        }

        // If the target itself is already foreground, prefer a real target UI
        // Back control. Only fall back to system Back when no such control can
        // be activated. Never launch the target merely to perform Back.
        if(isTargetForeground(target)) return performBackOnTarget(target);

        log("BACK: target not foreground; no launch target="+target);
        return false;
    }

    private boolean performBackOnTarget(String expectedTarget){
        try{
            AccessibilityNodeInfo root=getTargetRoot();
            if(root!=null){
                String pkg=String.valueOf(root.getPackageName());
                if(!isIgnoredWindowPackage(pkg) && pkg.equals(expectedTarget)){
                    AccessibilityNodeInfo back=findNode(root,new String[]{
                        "назад","back","navigate up","go back","вернуться",
                        "arrow_back","navigation_back","up"
                    });
                    if(back!=null){
                        AccessibilityNodeInfo c=back;
                        for(int depth=0;c!=null&&depth<8;depth++){
                            if(c.isClickable() && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)){
                                log("BACK UI CLICK OK pkg="+pkg);
                                return true;
                            }
                            c=c.getParent();
                        }
                    }
                }
            }
            boolean r=performGlobalAction(GLOBAL_ACTION_BACK);
            log("BACK GLOBAL target="+expectedTarget+" result="+r);
            return r;
        }catch(Exception e){
            log("BACK EXEC ERROR "+e);
            return false;
        }
    }

    private boolean isBridgeForeground(){
        try{AccessibilityNodeInfo active=getRootInActiveWindow();return active!=null&&BRIDGE.equals(String.valueOf(active.getPackageName()));}catch(Exception e){return false;}
    }

    private boolean launchApp(String name){String n=name.toLowerCase(Locale.ROOT);String pkg=null;if(n.contains("chatgpt"))pkg=CHATGPT;else if(n.contains("калькулятор")||n.contains("calculator"))pkg=findCalculatorPackage();else pkg=findPackageByLabel(name);if(pkg==null){log("LAUNCH APP NOT FOUND: "+name);return false;}boolean r=launchPackage(pkg);log("LAUNCH "+pkg+" result="+r);return r;}
    private boolean launchPackage(String pkg){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i==null)return false;i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);startActivity(i);return true;}catch(Exception e){log("LAUNCH ERROR "+e);return false;}}
    private String findCalculatorPackage(){String[] known={"com.google.android.calculator","com.android.calculator2","com.coloros.calculator","com.oppo.calculator"};for(String p:known){try{if(getPackageManager().getLaunchIntentForPackage(p)!=null)return p;}catch(Exception ignored){}}return findPackageAny("калькулятор","calculator");}
    private String findPackageAny(String... needles){for(android.content.pm.ApplicationInfo a:getPackageManager().getInstalledApplications(0)){String l=a.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);for(String needle:needles)if(l.contains(needle))return a.packageName;}return null;}
    private String findPackageByLabel(String name){String q=name.toLowerCase(Locale.ROOT);for(android.content.pm.ApplicationInfo a:getPackageManager().getInstalledApplications(0)){String l=a.loadLabel(getPackageManager()).toString().toLowerCase(Locale.ROOT);if(l.equals(q)||l.contains(q))return a.packageName;}return null;}

    private boolean openFileCommand(String name){
        // A command cannot safely guess a filesystem path from a display name.
        // If the user already selected a file, open that exact URI; otherwise
        // open the system document picker so the user can choose it.
        try{
            Uri selected=MainActivity.getSelectedFile();
            if(selected!=null){
                String tail=selected.getLastPathSegment()==null?"":selected.getLastPathSegment();
                if(name.isEmpty() || tail.toLowerCase(Locale.ROOT).contains(name.toLowerCase(Locale.ROOT))){
                    Intent i=new Intent(Intent.ACTION_VIEW,selected);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(i); log("OPEN FILE SELECTED OK "+selected); return true;
                }
            }
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
            log("OPEN FILE PICKER requested name="+name); return true;
        }catch(Exception e){log("OPEN FILE ERROR "+e);return false;}
    }

    private boolean setTextSmartNow(String text){AccessibilityNodeInfo root=getTargetRoot();if(root==null){log("SET TEXT: no target root");return false;}AccessibilityNodeInfo n=findEditable(root);if(n==null){log("SET TEXT: editable node not found");return false;}Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text);boolean r=n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b);log("SET TEXT result="+r+" class="+n.getClassName());return r;}
    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n){if(n==null)return null;if(n.isEditable()||"android.widget.EditText".contentEquals(n.getClassName()))return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=findEditable(n.getChild(i));if(r!=null)return r;}return null;}
    private boolean clickSmartNow(String query){AccessibilityNodeInfo root=getTargetRoot();if(root==null){log("CLICK: no target root");return false;}String[] q=query.toLowerCase(Locale.ROOT).split("\\|");AccessibilityNodeInfo n=findNode(root,q);if(n==null){log("CLICK NOT FOUND: "+query);return false;}AccessibilityNodeInfo clickNode=n;boolean r=false;for(int depth=0;clickNode!=null&&depth<8;depth++){if(clickNode.isClickable()){r=clickNode.performAction(AccessibilityNodeInfo.ACTION_CLICK);if(r)break;}clickNode=clickNode.getParent();}log("CLICK result="+r+" text="+n.getText()+" desc="+n.getContentDescription()+" class="+n.getClassName());return r;}
    private AccessibilityNodeInfo findNode(AccessibilityNodeInfo n,String[] q){
        if(n==null)return null;
        String s=((n.getText()==null?"":n.getText().toString())+" "+
            (n.getContentDescription()==null?"":n.getContentDescription().toString())+" "+
            (n.getViewIdResourceName()==null?"":n.getViewIdResourceName())+" "+
            (n.getClassName()==null?"":n.getClassName().toString())).toLowerCase(Locale.ROOT);
        for(String z:q)if(!z.trim().isEmpty()&&s.contains(z.trim()))return n;
        for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo r=findNode(n.getChild(i),q);if(r!=null)return r;}
        return null;
    }
    private void readScreen(){AccessibilityNodeInfo root=getTargetRoot();if(root==null){log("SCREEN READ: no target root");return;}StringBuilder b=new StringBuilder();dumpNode(root,b,0);log("SCREEN READ:\n"+b);}
    private void dumpNode(AccessibilityNodeInfo n,StringBuilder b,int depth){if(n==null)return;String t=n.getText()==null?"":n.getText().toString().trim();String d=n.getContentDescription()==null?"":n.getContentDescription().toString().trim();if(!t.isEmpty()||!d.isEmpty()){for(int i=0;i<depth;i++)b.append("  ");b.append("text=").append(t).append(" desc=").append(d).append(" class=").append(n.getClassName()).append(" clickable=").append(n.isClickable()).append(" editable=").append(n.isEditable()).append('\n');}for(int i=0;i<n.getChildCount();i++)dumpNode(n.getChild(i),b,depth+1);}
}
