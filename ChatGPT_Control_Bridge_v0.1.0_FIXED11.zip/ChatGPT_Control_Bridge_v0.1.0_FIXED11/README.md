# ChatGPT Control Bridge v0.1.0-FIXED11

FIXED11 keeps the working FIXED9/FIXED11 command set and changes only the confirmed issues:
- target-window selection no longer switches to the Latin IME when the Bridge command field is focused; ChatGPT remains the preferred target.
- `назад` never uses a blind global BACK that can exit ChatGPT to Home; it uses an exposed target-app back control when available.
- the journal is now a dedicated fixed-height ScrollView, separate from the main controls, so it can be scrolled and inspected independently.
