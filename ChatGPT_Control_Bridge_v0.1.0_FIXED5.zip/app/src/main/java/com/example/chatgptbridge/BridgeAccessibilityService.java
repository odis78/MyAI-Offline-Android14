package com.example.chatgptbridge;

import android.accessibilityservice.*;
import android.content.*;
import android.view.accessibility.*;
import android.os.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class BridgeAccessibilityService extends AccessibilityService {
  static volatile BridgeAccessibilityService instance;
  static final String F = "bridge.log";

  @Override public void onServiceConnected() {
    super.onServiceConnected();
    instance = this;
    log(this, "ACCESSIBILITY CONNECTED");
  }

  @Override public void onDestroy() {
    if (instance == this) {
      instance = null;
      log(this, "ACCESSIBILITY DISCONNECTED");
    }
    super.onDestroy();
  }

  @Override public void onInterrupt() {}

  static boolean isConnected() {
    return instance != null;
  }

  @Override public void onAccessibilityEvent(AccessibilityEvent e) {
    if (e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
      log(this, "WINDOW " + e.getPackageName());
    }
  }

  public void back() {
    boolean ok = performGlobalAction(GLOBAL_ACTION_BACK);
    log(this, "ACTION BACK result=" + ok);
  }

  public void home() {
    boolean ok = performGlobalAction(GLOBAL_ACTION_HOME);
    log(this, "ACTION HOME result=" + ok);
  }

  public void scrollDown() {
    scrollActive(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD, "DOWN");
  }

  public void scrollUp() {
    scrollActive(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD, "UP");
  }

  private void scrollActive(int action, String direction) {
    AccessibilityNodeInfo root = getRootInActiveWindow();

    if (root == null) {
      log(this, "ACTION SCROLL " + direction + " result=NO_ROOT");
      return;
    }

    /*
     * The old implementation recursively tried every node and returned
     * after the first successful performAction(). That can scroll a nested
     * container different from the one the user is looking at.
     *
     * Prefer actual scrollable containers and try the active window from
     * the deepest useful node upward.
     */
    ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
    collectScrollable(root, nodes);

    boolean done = false;
    for (int i = nodes.size() - 1; i >= 0; i--) {
      AccessibilityNodeInfo n = nodes.get(i);
      try {
        if (n.performAction(action)) {
          log(this, "ACTION SCROLL " + direction +
              " result=OK class=" + n.getClassName());
          done = true;
          break;
        }
      } catch (Exception e) {
        log(this, "ACTION SCROLL " + direction +
            " result=ERROR " + e.getClass().getSimpleName());
      }
    }

    if (!done) {
      /*
       * Some apps expose no scrollable AccessibilityNodeInfo but still
       * expose a focused view. Try the root once as a fallback.
       */
      try {
        if (root.performAction(action)) {
          log(this, "ACTION SCROLL " + direction + " result=OK root");
          return;
        }
      } catch (Exception ignored) {}

      log(this, "ACTION SCROLL " + direction + " result=NOT_SUPPORTED");
    }
  }

  private void collectScrollable(AccessibilityNodeInfo n,
                                 ArrayList<AccessibilityNodeInfo> out) {
    if (n == null) return;

    try {
      if (n.isScrollable()) out.add(n);
    } catch (Exception ignored) {}

    for (int i = 0; i < n.getChildCount(); i++) {
      AccessibilityNodeInfo c = null;
      try {
        c = n.getChild(i);
        if (c != null) collectScrollable(c, out);
      } catch (Exception ignored) {
      }
    }
  }

  static synchronized void log(Context c, String s) {
    try {
      FileOutputStream o = c.openFileOutput(F, Context.MODE_APPEND);
      String x = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
          .format(new Date()) + "  " + s + "\n";
      o.write(x.getBytes());
      o.close();
    } catch (Exception ignored) {}
  }

  static String readLog(Context c) {
    try {
      FileInputStream i = c.openFileInput(F);
      ByteArrayOutputStream b = new ByteArrayOutputStream();
      byte[] chunk = new byte[8192];
      int n;
      while ((n = i.read(chunk)) != -1) b.write(chunk, 0, n);
      i.close();
      return new String(b.toByteArray());
    } catch (Exception e) {
      return "Журнал пуст.";
    }
  }
}
