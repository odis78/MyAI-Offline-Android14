package com.example.chatgptbridge;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  TextView status, log;
  EditText command;
  Uri currentUri;

  static final int OPEN_FILE = 20;
  static final String CHATGPT_PACKAGE = "com.openai.chatgpt";
  static final String BUILD_TAG = "v0.1.0-FIXED5";

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    build();
  }

  @Override protected void onResume() {
    super.onResume();
    if (status != null) refreshStatus();
    if (log != null) refreshLog();
  }

  TextView tv(String s) {
    TextView v = new TextView(this);
    v.setText(s);
    v.setTextSize(16);
    v.setPadding(12, 12, 12, 12);
    return v;
  }

  Button btn(String s, View.OnClickListener l) {
    Button b = new Button(this);
    b.setText(s);
    b.setOnClickListener(l);
    return b;
  }

  void build() {
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(18, 18, 18, 18);

    TextView title = tv("ChatGPT Control Bridge\nЛокальный мост управления Android\n" + BUILD_TAG);
    title.setTextSize(21);
    root.addView(title);

    status = tv("Accessibility: проверка...");
    root.addView(status);

    root.addView(btn("⚙ Включить Accessibility",
        v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

    root.addView(btn("📱 Открыть ChatGPT", v -> openChatGPT()));

    root.addView(btn("📁 Выбрать файл", v -> {
      Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
      i.setType("*/*");
      i.addCategory(Intent.CATEGORY_OPENABLE);
      startActivityForResult(i, OPEN_FILE);
    }));

    root.addView(btn("📝 Редактировать выбранный файл", v -> editCurrent()));

    command = new EditText(this);
    command.setHint("Команда мосту: назад / домой / вверх / вниз");
    root.addView(command);

    root.addView(btn("▶ Выполнить команду",
        v -> runCommand(command.getText().toString())));

    root.addView(btn("📋 Обновить журнал", v -> refreshLog()));

    ScrollView scroll = new ScrollView(this);
    log = tv("");
    scroll.addView(log);
    root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

    setContentView(root);
    refreshStatus();
    refreshLog();
  }

  void refreshStatus() {
    boolean on = BridgeAccessibilityService.isConnected();
    boolean installed = isChatGPTInstalled();
    status.setText(
        "Accessibility: " + (on ? "ВКЛЮЧЁН" : "не подключён") +
        "\nChatGPT: " + (installed ? "НАЙДЕН (com.openai.chatgpt)" : "НЕ НАЙДЕН") +
        "\nСборка: " + BUILD_TAG);
  }

  boolean isChatGPTInstalled() {
    try {
      getPackageManager().getApplicationInfo(CHATGPT_PACKAGE, 0);
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  void openChatGPT() {
    PackageManager pm = getPackageManager();
    BridgeAccessibilityService.log(this,
        "CHATGPT OPEN REQUEST package=" + CHATGPT_PACKAGE);

    try {
      Intent launch = pm.getLaunchIntentForPackage(CHATGPT_PACKAGE);

      if (launch != null) {
        /*
         * Do NOT add FLAG_ACTIVITY_NEW_TASK here.
         * The bridge is an Activity, so keeping the launch in the current
         * task lets Android Back return to the bridge instead of immediately
         * dropping to the launcher.
         */
        launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(launch);

        BridgeAccessibilityService.log(this,
            "CHATGPT LAUNCH OK getLaunchIntent flags=" + launch.getFlags());
        return;
      }

      Intent launcher = new Intent(Intent.ACTION_MAIN);
      launcher.addCategory(Intent.CATEGORY_LAUNCHER);
      launcher.setPackage(CHATGPT_PACKAGE);

      java.util.List<android.content.pm.ResolveInfo> matches =
          pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL);

      BridgeAccessibilityService.log(this,
          "CHATGPT LAUNCHER MATCHES=" + matches.size());

      if (!matches.isEmpty()) {
        android.content.pm.ActivityInfo ai = matches.get(0).activityInfo;
        Intent explicit = new Intent(Intent.ACTION_MAIN);
        explicit.addCategory(Intent.CATEGORY_LAUNCHER);
        explicit.setClassName(ai.packageName, ai.name);
        explicit.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(explicit);

        BridgeAccessibilityService.log(this,
            "CHATGPT LAUNCH OK explicit=" + ai.name);
        return;
      }

      if (isChatGPTInstalled()) {
        toast("ChatGPT найден, но launcher Activity недоступна");
        BridgeAccessibilityService.log(this,
            "CHATGPT FOUND BUT NO LAUNCHER ACTIVITY");
      } else {
        toast("ChatGPT не найден. Проверь установку официального приложения.");
        BridgeAccessibilityService.log(this, "CHATGPT NOT INSTALLED");
      }
    } catch (Exception e) {
      toast("Ошибка запуска ChatGPT: " + e.getClass().getSimpleName());
      BridgeAccessibilityService.log(this, "CHATGPT LAUNCH ERROR " + e);
    }
  }

  void refreshLog() {
    if (log != null) log.setText(BridgeAccessibilityService.readLog(this));
  }

  void runCommand(String c) {
    BridgeAccessibilityService s = BridgeAccessibilityService.instance;

    if (s == null || !BridgeAccessibilityService.isConnected()) {
      toast("Сначала включи Accessibility");
      refreshStatus();
      return;
    }

    String x = c.trim().toLowerCase(java.util.Locale.ROOT);

    if (x.equals("назад") || x.contains("назад")) {
      s.back();
    } else if (x.equals("домой") || x.contains("домой")) {
      s.home();
    } else if (x.contains("вверх")) {
      s.scrollUp();
    } else if (x.contains("вниз")) {
      s.scrollDown();
    } else if (x.contains("прокрут")) {
      toast("Укажи направление: прокрути вверх или прокрути вниз");
    } else {
      toast("Пока поддерживаются: назад, домой, вверх, вниз");
    }

    refreshLog();
  }

  void editCurrent() {
    if (currentUri == null) {
      toast("Сначала выбери файл");
      return;
    }

    try {
      InputStream in = getContentResolver().openInputStream(currentUri);
      ByteArrayOutputStream buffer = new ByteArrayOutputStream();
      byte[] chunk = new byte[8192];
      int n;
      while ((n = in.read(chunk)) != -1) buffer.write(chunk, 0, n);
      in.close();

      byte[] data = buffer.toByteArray();
      final EditText e = new EditText(this);
      e.setGravity(Gravity.TOP);
      e.setInputType(1 | 0x80000);
      e.setText(new String(data, StandardCharsets.UTF_8));

      new AlertDialog.Builder(this)
          .setTitle("Редактор файла")
          .setView(e)
          .setNegativeButton("Отмена", null)
          .setPositiveButton("Сохранить", (d, w) -> save(e.getText().toString()))
          .show();
    } catch (Exception ex) {
      toast("Не удалось прочитать файл: " + ex.getMessage());
    }
  }

  void save(String text) {
    try {
      OutputStream out = getContentResolver().openOutputStream(currentUri, "wt");
      out.write(text.getBytes(StandardCharsets.UTF_8));
      out.close();
      toast("Файл сохранён");
      BridgeAccessibilityService.log(this, "FILE_SAVE OK");
    } catch (Exception e) {
      toast("Ошибка сохранения: " + e.getMessage());
      BridgeAccessibilityService.log(this, "FILE_SAVE ERROR " + e);
    }
  }

  @Override protected void onActivityResult(int r, int c, Intent d) {
    super.onActivityResult(r, c, d);
    if (r == OPEN_FILE && c == RESULT_OK && d != null) {
      currentUri = d.getData();
      try {
        getContentResolver().takePersistableUriPermission(
            currentUri,
            d.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION |
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
      } catch (Exception ignored) {}
      BridgeAccessibilityService.log(this, "FILE_OPEN " + currentUri);
      toast("Файл выбран");
    }
  }

  void toast(String s) {
    Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
  }
}
