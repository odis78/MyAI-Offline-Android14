# ChatGPT Control Bridge v0.1.0-FIXED9

Локальный мост управления Android через AccessibilityService.

## FIXED9
- Исправлена ошибка workflow FIXED8: статическая проверка больше не требует `com.openai.chatgpt` в AndroidManifest.xml, где этот package name не обязан находиться.
- Версия проекта синхронизирована на `0.1.0-FIXED9`.
- Gradle 8.9 выбран совместимо с Android Gradle Plugin 8.7.3.
- Сохранён ресурсный `@string/accessibility_service_description`.
- Управление окнами использует интерактивные Accessibility windows и избегает корневого окна самого Bridge.
- Поиск кликабельного элемента поднимается по цепочке родителей, чтобы кнопки ChatGPT находились даже если текст/description находится на дочернем View.
- Для калькулятора добавлены распространённые package ID и fallback по названию приложения.

## Сборка
GitHub Actions workflow: `build-chatgpt-control-bridge-v0.1.0-FIXED9.yml`.
