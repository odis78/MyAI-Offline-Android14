package com.example.chatgptbridge;
import android.accessibilityservice.*;import android.content.*;import android.view.accessibility.*;import android.graphics.Path;import android.os.*;import java.io.*;import java.text.*;import java.util.*;
public class BridgeAccessibilityService extends AccessibilityService{
 static BridgeAccessibilityService instance; static final String F="bridge.log";
 public void onServiceConnected(){instance=this;log(this,"ACCESSIBILITY CONNECTED");}
 public void onAccessibilityEvent(AccessibilityEvent e){if(e.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)log(this,"WINDOW "+e.getPackageName());}
 public void onInterrupt(){}
 public void back(){performGlobalAction(GLOBAL_ACTION_BACK);log(this,"ACTION BACK");}
 public void home(){performGlobalAction(GLOBAL_ACTION_HOME);log(this,"ACTION HOME");}
 public void scrollDown(){AccessibilityNodeInfo n=getRootInActiveWindow();if(n!=null)scroll(n,AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);}
 public void scrollUp(){AccessibilityNodeInfo n=getRootInActiveWindow();if(n!=null)scroll(n,AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);}
 void scroll(AccessibilityNodeInfo n,int a){if(n.performAction(a)){log(this,"ACTION SCROLL");return;}for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)scroll(c,a);}}
 static synchronized void log(Context c,String s){try{FileOutputStream o=c.openFileOutput(F,Context.MODE_APPEND);String x=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date())+"  "+s+"\n";o.write(x.getBytes());o.close();}catch(Exception ignored){}}
 static String readLog(Context c){try{FileInputStream i=c.openFileInput(F);ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] chunk=new byte[8192];int n;while((n=i.read(chunk))!=-1)b.write(chunk,0,n);i.close();return new String(b.toByteArray());}catch(Exception e){return "Журнал пуст.";}}
}
