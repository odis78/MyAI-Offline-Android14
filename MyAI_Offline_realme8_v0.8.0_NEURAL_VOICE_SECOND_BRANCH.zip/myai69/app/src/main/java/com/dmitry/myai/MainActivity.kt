package com.dmitry.myai

import android.Manifest
import android.app.ActivityManager
import android.content.pm.PackageManager
import android.widget.Toast
import android.content.Intent
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.io.File

private val Dark = darkColorScheme(
    primary = Color(0xFF8AB4F8),
    background = Color(0xFF101114),
    surface = Color(0xFF18191D),
    surfaceVariant = Color(0xFF25272C)
)

class MainActivity : ComponentActivity() {
    private var pickModel: ((android.net.Uri) -> Unit)? = null
    private var pickGgufModel: ((android.net.Uri) -> Unit)? = null
    private lateinit var voice: VoiceController
    private var pendingMicAction: (() -> Unit)? = null

    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pickModel?.invoke(uri)
    }

    // GetContent is intentionally used for GGUF: the model is copied immediately
    // into app-private storage, so a persistable document URI is not required.
    // This is more compatible with OEM file pickers on Android devices.
    private val ggufPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) pickGgufModel?.invoke(uri)
    }

    private val microphonePermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingMicAction
        pendingMicAction = null
        if (granted) action?.invoke()
        else Toast.makeText(this, "Разрешение на микрофон не предоставлено", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        voice = VoiceController(this)
        setContent {
            MaterialTheme(colorScheme = Dark) {
                val vm: ChatViewModel = viewModel()
                var autoSpeak by remember { mutableStateOf(voice.autoSpeakEnabled()) }
                var voiceSpeed by remember { mutableFloatStateOf(voice.tts().speed()) }
                pickModel = { uri -> vm.importModel(uri) }
                pickGgufModel = { uri -> vm.importGgufModel(uri) }
                App(
                    vm = vm,
                    vmVoiceManager = voice.tts().manager(),
                    offlineAsrManager = voice.offlineAsrManager(),
                    onPickModel = { modelPicker.launch(arrayOf("application/octet-stream", "*/*")) },
                    onPickGgufModel = { ggufPicker.launch("*/*") },
                    onMic = {
                        val start = {
                            voice.startListening(
                                result = { vm.send(it) },
                                state = { message -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
                            )
                        }
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            start()
                        } else {
                            pendingMicAction = start
                            microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onSpeak = { voice.tts().speak(it) },
                    onStopSpeaking = { voice.tts().stop() },
                    autoSpeak = autoSpeak,
                    onAutoSpeakChange = { enabled ->
                        autoSpeak = enabled
                        voice.setAutoSpeakEnabled(enabled)
                    },
                    voiceSpeed = voiceSpeed,
                    onVoiceSpeedChange = { value ->
                        voiceSpeed = value
                        voice.tts().setSpeed(value)
                    }
                )
                LaunchedEffect(vm, autoSpeak) {
                    if (autoSpeak) {
                        vm.assistantReplies.collect { reply ->
                            voice.tts().speak(reply, onError = { error ->
                                Toast.makeText(this@MainActivity, "Ошибка голоса: ${error.message ?: "неизвестная"}", Toast.LENGTH_LONG).show()
                            })
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        voice.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun App(
    vm: ChatViewModel = viewModel(),
    vmVoiceManager: NeuralVoiceManager,
    offlineAsrManager: OfflineAsrManager,
    onPickModel: () -> Unit,
    onPickGgufModel: () -> Unit,
    onMic: () -> Unit,
    onSpeak: (String) -> Unit,
    onStopSpeaking: () -> Unit,
    autoSpeak: Boolean,
    onAutoSpeakChange: (Boolean) -> Unit,
    voiceSpeed: Float,
    onVoiceSpeedChange: (Float) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Dark.background,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF17181C)) {
                listOf("Чат" to Icons.Default.Chat, "Создать" to Icons.Default.AutoAwesome,
                    "Проекты" to Icons.Default.Folder, "Настройки" to Icons.Default.Settings)
                    .forEachIndexed { i, item ->
                        NavigationBarItem(tab == i, { tab = i }, icon = { Icon(item.second, null) }, label = { Text(item.first) })
                    }
            }
        }
    ) { pad ->
        when (tab) {
            0 -> ChatScreen(Modifier.padding(pad), vm, onMic, onSpeak, onStopSpeaking, autoSpeak)
            1 -> CreateScreen(Modifier.padding(pad))
            2 -> ProjectsScreen(Modifier.padding(pad))
            else -> SettingsScreen(Modifier.padding(pad), vm, onPickModel, onPickGgufModel, vmVoiceManager, offlineAsrManager, autoSpeak, onAutoSpeakChange, voiceSpeed, onVoiceSpeedChange)
        }
    }
}

@Composable
private fun ChatScreen(
    modifier: Modifier,
    vm: ChatViewModel,
    onMic: () -> Unit,
    onSpeak: (String) -> Unit,
    onStopSpeaking: () -> Unit,
    autoSpeak: Boolean
) {
    val messages by vm.messages.collectAsState()
    val status by vm.status.collectAsState()
    val state by vm.state.collectAsState()
    var input by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(Dark.primary), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AutoAwesome, null, tint = Color.Black)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Мой AI", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("● $status", color = if (state == AiState.READY) Color(0xFF80CBC4) else Color.Gray, fontSize = 12.sp)
                Text(if (autoSpeak) "🔊 Автоголос включён" else "🔇 Автоголос выключен", color = Color.Gray, fontSize = 10.sp)
            }
            IconButton(onClick = vm::loadModel, enabled = state != AiState.STARTING && state != AiState.GENERATING) {
                Icon(Icons.Default.Refresh, "Загрузить модель")
            }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages) { m -> Bubble(m, onSpeak, onStopSpeaking) }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Спросить локальный AI…") }, shape = RoundedCornerShape(24.dp), maxLines = 4,
                trailingIcon = { IconButton(onClick = { vm.send(input); input = "" }, enabled = input.isNotBlank() && state != AiState.GENERATING) { Icon(Icons.Default.Send, "Отправить") } }
            )
            Spacer(Modifier.width(6.dp))
            IconButton(onClick = onMic, modifier = Modifier.size(52.dp).clip(CircleShape).background(Dark.primary)) {
                Icon(Icons.Default.Mic, "Голос", tint = Color.Black)
            }
        }
    }
}

@Composable
private fun Bubble(
    m: ChatLine,
    onSpeak: (String) -> Unit,
    onStopSpeaking: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.user) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (m.user) Dark.primary else Dark.surfaceVariant,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Column(Modifier.padding(start = 14.dp, top = 10.dp, end = 10.dp, bottom = 8.dp)) {
                Text(
                    m.text.ifBlank { "…" },
                    color = if (m.user) Color.Black else Color.White
                )
                if (!m.user && m.text.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = { onSpeak(m.text) },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            modifier = Modifier.height(38.dp)
                        ) {
                            Icon(Icons.Default.VolumeUp, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("Озвучить")
                        }
                        OutlinedButton(
                            onClick = onStopSpeaking,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            modifier = Modifier.height(38.dp)
                        ) {
                            Icon(Icons.Default.Stop, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("Стоп")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CreateScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("Создать", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Модули для полностью локальной работы", color = Color.Gray, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
        listOf(
            Icons.Default.Image to ("Изображения" to "Локальный анализ и обработка"),
            Icons.Default.VideoLibrary to ("Видео" to "Локальный монтаж"),
            Icons.Default.CameraAlt to ("Камера" to "Фото → AI"),
            Icons.Default.Description to ("Документы" to "Локальная база знаний"),
            Icons.Default.Build to ("Автомобиль" to "Схемы и проекты"),
            Icons.Default.Code to ("Код" to "Программирование")
        ).forEach { (icon, p) ->
            Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = Dark.surface)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, null, Modifier.size(30.dp), tint = Dark.primary); Spacer(Modifier.width(15.dp))
                    Column { Text(p.first, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); Text(p.second, color = Color.Gray, fontSize = 13.sp) }
                }
            }
        }
    }
}

@Composable
private fun ProjectsScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("Мои проекты", fontSize = 28.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp))
        Project("🚗", "Jetour Dashing", "ГУ • усилитель • схемы")
        Project("⚡", "Электробайк", "Рама • мотор • электроника")
        Project("🧠", "AI Assistant", "Локальный AI • инструменты")
    }
}
@Composable private fun Project(icon: String, title: String, sub: String) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = Dark.surface)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 30.sp); Spacer(Modifier.width(15.dp)); Column { Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text(sub, color = Color.Gray, fontSize = 13.sp) }
        }
    }
}

@Composable
private fun SettingsScreen(
    modifier: Modifier,
    vm: ChatViewModel,
    onPickModel: () -> Unit,
    onPickGgufModel: () -> Unit,
    voiceManager: NeuralVoiceManager,
    offlineAsrManager: OfflineAsrManager,
    autoSpeak: Boolean,
    onAutoSpeakChange: (Boolean) -> Unit,
    voiceSpeed: Float,
    onVoiceSpeedChange: (Float) -> Unit
) {
    val status by vm.status.collectAsState()
    val state by vm.state.collectAsState()
    val models = vm.models()
    val context = androidx.compose.ui.platform.LocalContext.current
    val am = remember { context.getSystemService(ActivityManager::class.java) }
    val mem = remember { ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) } }
    val scope = rememberCoroutineScope()
    var downloading by remember { mutableStateOf<String?>(null) }
    var progress by remember { mutableIntStateOf(0) }
    var voiceStage by remember { mutableStateOf("") }
    var voiceRefresh by remember { mutableIntStateOf(0) }
    var speed by remember { mutableFloatStateOf(voiceSpeed) }
    var voiceError by remember { mutableStateOf<String?>(null) }
    var asrDownloading by remember { mutableStateOf(false) }
    var asrProgress by remember { mutableIntStateOf(0) }
    var asrStage by remember { mutableStateOf("") }
    var asrError by remember { mutableStateOf<String?>(null) }
    var asrRevision by remember { mutableIntStateOf(0) }
    var benchmarkRunning by remember { mutableStateOf(false) }
    var benchmarkText by remember { mutableStateOf<String?>(null) }
    var llamaBenchmarkRunning by remember { mutableStateOf(false) }
    var llamaBenchmarkText by remember { mutableStateOf<String?>(null) }
    var ggufRefresh by remember { mutableIntStateOf(0) }
    val ggufStatus by vm.ggufStatus.collectAsState()
    val ggufRevision by vm.ggufRevision.collectAsState()
    val ggufManager = remember { GgufModelManager(context) }
    val ggufModels = remember(ggufRefresh, ggufRevision) { ggufManager.models() }

    val settingsScroll = rememberScrollState()

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(settingsScroll)
            .padding(18.dp)
            .navigationBarsPadding()
    ) {
        Text("Настройки", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Dark.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("🧠 Модели LiteRT-LM", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Для первого запуска: Gemma 3 1B INT4 (~584 MB).", color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(10.dp))
                Text("Статус: $status")
                Text("Выбрана: ${vm.modelName()}", color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                models.forEach { file ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = file.name == vm.modelName(), onClick = { vm.selectModel(file) })
                        Text(file.name, Modifier.weight(1f), fontSize = 13.sp)
                        Text("${file.length() / (1024 * 1024)} MB", color = Color.Gray, fontSize = 11.sp)
                        IconButton(onClick = { vm.deleteModel(file) }) { Icon(Icons.Default.Delete, "Удалить") }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onPickModel) { Text("Импорт") }
                    Button(onClick = vm::loadModel, enabled = state != AiState.IMPORTING && state != AiState.STARTING) { Text("Запустить") }
                }
                Spacer(Modifier.height(8.dp))
                Text("Папка: ${vm.modelDirectory().absolutePath}", color = Color.Gray, fontSize = 11.sp)
                Text("Свободно: ${vm.modelDirectory().usableSpace / (1024L * 1024L * 1024L)} GB", color = Color.Gray, fontSize = 11.sp)
                OutlinedButton(onClick = vm::clearChat, modifier = Modifier.padding(top = 8.dp)) { Text("Очистить историю чата") }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Dark.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("📱 Управление телефоном", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "MyAI может выполнять локальные команды Android через службу специальных возможностей. Служба включается только вручную пользователем.",
                    color = Color.Gray, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    if (AndroidControlManager.accessibilityEnabled()) "Статус: служба включена ✓" else "Статус: служба не включена",
                    color = if (AndroidControlManager.accessibilityEnabled()) Color(0xFF9BE7C1) else Color.Gray
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = { AndroidControlManager.openAccessibilitySettings(context) }) {
                    Text("Настроить управление телефоном")
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "После включения можно сказать: «домой», «назад», «открой настройки», «прочитай экран», «нажми …».",
                    color = Color.Gray, fontSize = 11.sp
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Dark.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("🦙 GGUF / llama.cpp", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Вторая ветка: отдельный CPU-движок для GGUF-моделей. После импорта можно измерить настоящую скорость генерации в токенах/с.",
                    color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
                Spacer(Modifier.height(8.dp))
                val selectedGguf = ggufManager.selectedModel()
                Text("Выбрана: ${selectedGguf?.name ?: "—"}", fontSize = 13.sp)
                ggufModels.forEach { file ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = file.name == selectedGguf?.name, onClick = { ggufManager.selectModel(file); ggufRefresh++ })
                        Text(file.name, Modifier.weight(1f), fontSize = 12.sp)
                        Text("${file.length() / (1024 * 1024)} MB", color = Color.Gray, fontSize = 10.sp)
                        IconButton(onClick = { ggufManager.delete(file); ggufRefresh++ }) { Icon(Icons.Default.Delete, "Удалить GGUF") }
                    }
                }
                if (ggufStatus.isNotBlank()) {
                    Text(
                        ggufStatus,
                        color = if (ggufStatus.startsWith("Ошибка")) Color(0xFFFF9B9B) else Color.LightGray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onPickGgufModel,
                        enabled = !ggufStatus.startsWith("Импорт GGUF:") && !ggufStatus.startsWith("Подготовка импорта")
                    ) { Text(if (ggufStatus.startsWith("Импорт GGUF:") || ggufStatus.startsWith("Подготовка импорта")) "Импорт…" else "Импорт GGUF") }
                    Button(
                        onClick = {
                            if (llamaBenchmarkRunning) return@Button
                            val model = ggufManager.selectedModel()
                            if (model == null) {
                                llamaBenchmarkText = "Сначала импортируй GGUF-модель."
                                return@Button
                            }
                            llamaBenchmarkRunning = true
                            llamaBenchmarkText = "LLM-бенчмарк запущен. Проверяем 1/2/4/6/8 потоков…"
                            scope.launch {
                                try {
                                    val report = LlamaEngine(context).benchmark(model.absolutePath)
                                    ggufManager.setPreferredThreads(report.bestThreads)
                                    val rows = report.rows.joinToString("\n") { r ->
                                        "${r.threads} потока: ${"%.2f".format(r.tokensPerSecond)} ток/с | загрузка ${r.loadMs} мс"
                                    }
                                    llamaBenchmarkText = "Результат GGUF / llama.cpp:\n$rows\n\nЛучший режим: ${report.bestThreads} потока(ов)\nЭтот режим сохранён и будет использоваться обычным GGUF-чатом.\nThermal: ${report.thermalBefore.thermalStatus} → ${report.thermalAfter.thermalStatus}\n\nЭто уже реальная скорость генерации, а не условные CPU-операции."
                                } catch (e: Exception) {
                                    llamaBenchmarkText = "Ошибка LLM-бенчмарка: ${e.message ?: "неизвестная ошибка"}"
                                } finally {
                                    llamaBenchmarkRunning = false
                                }
                            }
                        },
                        enabled = !llamaBenchmarkRunning && ggufModels.isNotEmpty()
                    ) { Text(if (llamaBenchmarkRunning) "Тест…" else "LLM-бенчмарк") }
                }
                llamaBenchmarkText?.let {
                    Text(it, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
                Text(
                    "Рекомендуемый первый тест: Qwen2.5 1.5B Instruct в GGUF Q4_K_M или Q4_0. Модель не входит в APK и импортируется отдельно.",
                    color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Dark.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("🎙 Нейронный голос", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Sherpa-ONNX + Piper. Голос загружается один раз, затем синтез полностью выполняется на телефоне без сети.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(10.dp))
                val selected = voiceManager.selected()
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = if (selected != null) Color(0xFF202A24) else Color(0xFF22242A)
                ) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (selected != null) "✓  ${selected.title} • ${selected.gender}" else "○  Голос пока не выбран",
                            fontWeight = FontWeight.SemiBold,
                            color = if (selected != null) Color(0xFF9BE7C1) else Color.LightGray
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Автоматически озвучивать ответы", fontWeight = FontWeight.SemiBold)
                        Text("После каждого ответа MyAI говорит выбранным русским голосом", color = Color.Gray, fontSize = 11.sp)
                    }
                    Switch(checked = autoSpeak, onCheckedChange = onAutoSpeakChange)
                }
                if (voiceError != null) {
                    Text("Ошибка: $voiceError", color = Color(0xFFFF8A80), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
                Text("Скорость: ${"%.1f".format(speed)}×", color = Color.Gray, fontSize = 12.sp)
                Slider(value = speed, onValueChange = { speed = it; onVoiceSpeedChange(it) }, valueRange = 0.7f..1.3f, steps = 5)
                Spacer(Modifier.height(6.dp))
                NeuralVoiceManager.CATALOG.forEach { voice ->
                    key(voice.id, voiceRefresh) {
                        val installed = voiceManager.isInstalled(voice)
                        val isSelected = selected?.id == voice.id
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .then(
                                    if (installed) Modifier.selectable(
                                        selected = isSelected,
                                        onClick = {
                                            voiceManager.select(voice)
                                            voiceError = null
                                            voiceRefresh++
                                        },
                                        role = androidx.compose.ui.semantics.Role.RadioButton
                                    ) else Modifier
                                ),
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) Color(0xFF202A24) else Color(0xFF202126)
                        ) {
                            Row(
                                Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = null,
                                    enabled = installed
                                )
                                Column(Modifier.weight(1f)) {
                                    Text("${voice.title} • ${voice.gender}", fontWeight = FontWeight.SemiBold)
                                    Text("Piper / русский / medium", color = Color.Gray, fontSize = 11.sp)
                                }
                                when {
                                    installed -> Text(
                                        if (isSelected) "Выбран" else "Установлен",
                                        color = Color(0xFF9BE7C1),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    downloading == voice.id -> Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            if (progress >= 100) voiceStage.ifBlank { "Установка…" } else "$progress%",
                                            color = Color.Gray,
                                            fontSize = 11.sp
                                        )
                                        if (progress >= 100) {
                                            LinearProgressIndicator(Modifier.width(120.dp).padding(top = 3.dp))
                                        }
                                    }
                                    else -> TextButton(onClick = {
                                        downloading = voice.id
                                        progress = 0
                                        voiceStage = "Подготовка…"
                                        voiceError = null
                                        scope.launch {
                                            try {
                                                voiceManager.download(voice) { p, stage ->
                                                    progress = p
                                                    voiceStage = stage
                                                }
                                            } catch (e: Exception) {
                                                voiceError = e.message ?: "неизвестная ошибка"
                                                Toast.makeText(context, voiceError, Toast.LENGTH_LONG).show()
                                            } finally {
                                                downloading = null
                                                progress = 0
                                                voiceStage = ""
                                                voiceRefresh++
                                            }
                                        }
                                    }) { Text("Скачать") }
                                }
                                if (installed) {
                                    IconButton(onClick = {
                                        voiceManager.delete(voice)
                                        voiceRefresh++
                                    }) {
                                        Icon(Icons.Default.Delete, "Удалить голос")
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Общий espeak-ng-data устанавливается один раз и используется всеми русскими голосами.", color = Color.Gray, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Dark.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("🎧 Офлайн-распознавание речи", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Русская sherpa-onnx ASR-модель (~258 MB) устанавливается один раз в память приложения. После установки микрофон работает полностью локально и не использует системный интернет-рекогнайзер.",
                    color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
                Spacer(Modifier.height(8.dp))
                @Suppress("UNUSED_VARIABLE")
                val asrUiRevision = asrRevision
                Text(
                    if (offlineAsrManager.isInstalled()) "Статус: установлено ✓" else "Статус: не установлено",
                    color = if (offlineAsrManager.isInstalled()) Color(0xFF9BE7C1) else Color.Gray
                )
                asrError?.let { Text("Ошибка: $it", color = Color(0xFFFF8A80), fontSize = 12.sp) }
                if (asrDownloading) {
                    Text(if (asrProgress > 0) "$asrProgress% • $asrStage" else asrStage, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    LinearProgressIndicator(progress = { asrProgress / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 5.dp))
                } else {
                    Button(
                        onClick = {
                            asrDownloading = true
                            asrProgress = 0
                            asrStage = "Подготовка…"
                            asrError = null
                            scope.launch {
                                try {
                                    offlineAsrManager.download { p, stage ->
                                        asrProgress = p
                                        asrStage = stage
                                    }
                                } catch (e: Exception) {
                                    asrError = e.message ?: "неизвестная ошибка"
                                    Toast.makeText(context, asrError, Toast.LENGTH_LONG).show()
                                } finally {
                                    asrDownloading = false
                                    asrRevision++
                                }
                            }
                        },
                        enabled = !offlineAsrManager.isInstalled()
                    ) {
                        Text(if (offlineAsrManager.isInstalled()) "Установлено" else "Скачать офлайн-распознавание")
                    }
                }
                Text(
                    "Модель хранится отдельно от APK: обновление приложения не требует скачивать её заново.",
                    color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Dark.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("📱 Диагностика", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT}", color = Color.Gray)
                Text("Производитель/SoC: " + if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else "${Build.MANUFACTURER} ${Build.HARDWARE}", color = Color.Gray)
                Text("RAM: ${mem.totalMem / (1024L * 1024L * 1024L)} GB", color = Color.Gray)
                Text("LLM Backend: CPU", color = Color.Gray)
                Text("TTS Backend: CPU", color = Color.Gray)
                Text("Режим: OFFLINE-FIRST — после установки GGUF, русского ASR и голоса интернет не нужен для чата, команд, микрофона и озвучки", color = Color.Gray)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Dark.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("⚡ Бенчмарк Второй ветки", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Проверяет реальную производительность CPU на этом телефоне в режимах 1/2/4/6/8 потоков. Это предварительный CPU-тест, а не тест LLM. После подключения llama.cpp сюда добавим настоящий тест генерации токенов.",
                    color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (benchmarkRunning) return@Button
                        benchmarkRunning = true
                        benchmarkText = "Тестирование… не блокируй экран и не запускай тяжёлые приложения."
                        scope.launch {
                            try {
                                val report = DeviceBenchmark(context).run()
                                val rows = report.rows.joinToString("\n") { r -> "${r.threads} потока: ${r.opsPerSecond} усл. оп/с" }
                                val temp = report.batteryTempC?.let { "${"%.1f".format(it)} °C" } ?: "нет данных"
                                benchmarkText = "Результат:\n$rows\n\nЛучший старт: ${report.bestThreads} потока(ов)\nТемпературный статус: ${report.thermalStatus}\nТемпература батареи: $temp\nRAM: ${report.freeRamMb} MB свободно из ${report.totalRamMb} MB\n\nВажно: это не токены/с. Финальный профиль выберем после подключения LLM-бенчмарка."
                            } catch (e: Exception) {
                                benchmarkText = "Ошибка бенчмарка: ${e.message ?: "неизвестная ошибка"}"
                            } finally {
                                benchmarkRunning = false
                            }
                        }
                    },
                    enabled = !benchmarkRunning
                ) {
                    Text(if (benchmarkRunning) "Тестирование…" else "Запустить бенчмарк")
                }
                benchmarkText?.let {
                    Text(it, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Dark.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("🎤 Голосовой ввод", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Кнопка микрофона запрашивает русское распознавание и предпочитает офлайн-режим. После распознавания команда сразу передаётся MyAI: обычный текст → Qwen, команды телефона → Android Control.", color = Color.Gray, fontSize = 12.sp)
                Text("Если на телефоне нет локального русского пакета распознавания, приложение покажет ошибку вместо тихого отказа.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}
