package com.dmitry.myai

import android.content.Context
import android.net.Uri
import java.io.File

class GgufModelManager(private val context: Context) {
    private val directory = File(context.filesDir, "gguf_models")
    private val prefs = context.getSharedPreferences("gguf_models", Context.MODE_PRIVATE)
    private val maxModelBytes = 3L * 1024L * 1024L * 1024L

    init { directory.mkdirs() }

    fun directory(): File = directory

    fun models(): List<File> = directory.listFiles()
        ?.filter { it.isFile && it.extension.equals("gguf", ignoreCase = true) }
        ?.sortedBy { it.name.lowercase() }
        ?: emptyList()

    fun selectedModel(): File? {
        val selected = prefs.getString("selected", null)
        val all = models()
        return all.firstOrNull { it.name == selected } ?: all.firstOrNull()
    }

    fun selectModel(file: File) {
        require(file.exists() && file.extension.equals("gguf", true))
        prefs.edit().putString("selected", file.name).apply()
    }

    fun importModel(uri: Uri): File {
        val resolver = context.contentResolver
        val displayName = resolver.query(uri, arrayOf("_display_name"), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            ?: "model.gguf"
        val cleanName = displayName.substringAfterLast('/').trim().ifBlank { "model.gguf" }
        require(cleanName.endsWith(".gguf", ignoreCase = true)) { "Нужен файл с расширением .gguf" }
        val size = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        require(size <= maxModelBytes || size < 0) { "GGUF слишком большой (> 3 ГБ)" }
        if (size > 0) {
            require(directory.usableSpace > size + 96L * 1024L * 1024L) {
                "Недостаточно свободного места для GGUF"
            }
        }
        val target = File(directory, cleanName)
        val temp = File(directory, ".${cleanName}.part")
        temp.delete()
        try {
            resolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Не удалось открыть GGUF" }
                temp.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
            }
            require(temp.length() > 0) { "GGUF-файл пустой" }
            if (target.exists()) target.delete()
            check(temp.renameTo(target)) { "Не удалось сохранить GGUF" }
            selectModel(target)
            return target
        } catch (e: Exception) {
            temp.delete()
            throw e
        }
    }

    fun delete(file: File) {
        val wasSelected = selectedModel()?.name == file.name
        file.delete()
        if (wasSelected) {
            val next = models().firstOrNull()
            if (next != null) selectModel(next) else prefs.edit().remove("selected").apply()
        }
    }
}
