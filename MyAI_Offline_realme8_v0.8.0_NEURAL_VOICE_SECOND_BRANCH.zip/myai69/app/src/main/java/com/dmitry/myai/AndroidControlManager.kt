package com.dmitry.myai

import android.content.Context
import android.content.Intent
import android.provider.Settings

object AndroidControlManager {
    fun accessibilityEnabled(): Boolean = MyAiAccessibilityService.isEnabled()

    fun openAccessibilitySettings(context: Context) {
        context.startActivity(
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
