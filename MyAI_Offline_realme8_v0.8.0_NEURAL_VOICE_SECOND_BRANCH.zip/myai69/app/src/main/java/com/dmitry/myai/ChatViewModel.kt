package com.dmitry.myai

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File


data class ChatLine(val text: String, val user: Boolean)

enum class AiState { NO_MODEL, IMPORTING, READY_TO_START, STARTING, READY, ERROR, GENERATING }

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val manager = ModelManager(app)
    private val ggufManager = GgufModelManager(app)
    private val ai = LocalAiEngine(app)
    private val androidAgent = AndroidAgent(app)
    private val historyFile = File(app.filesDir, "chat_history.json")

    private val _messages = MutableStateFlow(loadHistory().ifEmpty {
        listOf(ChatLine("Я готов к офлайн-режиму. Импортируй .litertlm модель и запусти AI.", false))
    })
    val messages = _messages.asStateFlow()

    private val _state = MutableStateFlow(if (manager.hasModel()) AiState.READY_TO_START else AiState.NO_MODEL)
    val state = _state.asStateFlow()
    private val _status = MutableStateFlow(statusText(_state.value))
    val status = _status.asStateFlow()

    private val _ggufStatus = MutableStateFlow("")
    val ggufStatus = _ggufStatus.asStateFlow()

    private val _ggufRevision = MutableStateFlow(0)
    val ggufRevision = _ggufRevision.asStateFlow()

    private var job: Job? = null

    fun modelDirectory() = manager.directory()
    fun modelName(): String = manager.selectedModel()?.name ?: "—"
    fun models(): List<File> = manager.models()
    fun selectModel(file: File) {
        manager.selectModel(file)
        ai.close()
        setState(AiState.READY_TO_START, "Выбрана: ${file.name}")
    }
    fun deleteModel(file: File) {
        if (manager.selectedModel()?.name == file.name) ai.close()
        manager.delete(file)
        setState(if (manager.hasModel()) AiState.READY_TO_START else AiState.NO_MODEL)
    }

    private fun setState(value: AiState, detail: String? = null) {
        _state.value = value
        _status.value = detail ?: statusText(value)
    }

    fun importModel(uri: Uri) {
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                setState(AiState.IMPORTING)
                ai.close()
                val file = manager.importModel(uri)
                setState(AiState.READY_TO_START, "Модель готова: ${file.name}")
            } catch (e: Exception) {
                setState(AiState.ERROR, "Ошибка импорта: ${e.message ?: "неизвестная"}")
            }
        }
    }


    fun importGgufModel(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            _ggufStatus.value = "Подготовка импорта GGUF…"
            try {
                val file = ggufManager.importModel(uri) { copied, total ->
                    _ggufStatus.value = if (total > 0L) {
                        val percent = ((copied * 100L) / total).coerceIn(0L, 100L)
                        "Импорт GGUF: $percent% — ${copied / (1024L * 1024L)} / ${total / (1024L * 1024L)} MB"
                    } else {
                        "Импорт GGUF: ${copied / (1024L * 1024L)} MB"
                    }
                }
                _ggufRevision.value += 1
                _ggufStatus.value = "GGUF импортирован: ${file.name}"
            } catch (e: Exception) {
                _ggufStatus.value = "Ошибка импорта GGUF: ${e.message ?: "неизвестная"}"
            }
        }
    }

    fun loadModel() {
        val model = manager.selectedModel()
        if (model == null) { setState(AiState.NO_MODEL); return }
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                setState(AiState.STARTING)
                ai.initialize(model.absolutePath)
                setState(AiState.READY)
            } catch (e: Exception) {
                ai.close()
                setState(AiState.ERROR, "Ошибка запуска: ${e.message ?: "неизвестная"}")
            }
        }
    }

    fun send(text: String) {
        val prompt = text.trim()
        if (prompt.isEmpty() || _state.value == AiState.GENERATING) return

        // Deterministic Android tools run locally and do not consume the LLM.
        androidAgent.execute(prompt)?.let { result ->
            _messages.value = _messages.value + ChatLine(prompt, true) + ChatLine(result, false)
            saveHistory()
            return
        }

        if (!ai.isInitialized()) {
            _messages.value = _messages.value + ChatLine("Сначала запусти AI в настройках.", false)
            saveHistory()
            return
        }
        _messages.value = _messages.value + ChatLine(prompt, true) + ChatLine("", false)
        saveHistory()
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                setState(AiState.GENERATING)
                var answer = ""
                ai.streamChat(prompt).collect { token ->
                    answer += token
                    _messages.value = _messages.value.dropLast(1) + ChatLine(answer, false)
                }
                saveHistory()
                setState(AiState.READY)
            } catch (e: Exception) {
                _messages.value = _messages.value.dropLast(1) +
                    ChatLine("Ошибка локального AI: ${e.message ?: "неизвестная"}", false)
                saveHistory()
                setState(AiState.ERROR)
            }
        }
    }

    fun clearChat() {
        _messages.value = listOf(ChatLine("Чат очищен. История удалена с устройства.", false))
        saveHistory()
    }

    private fun saveHistory() {
        runCatching {
            val array = JSONArray()
            _messages.value.takeLast(200).forEach {
                array.put(JSONObject().put("text", it.text).put("user", it.user))
            }
            historyFile.writeText(array.toString())
        }
    }

    private fun loadHistory(): List<ChatLine> = runCatching {
        if (!historyFile.exists()) return emptyList()
        val a = JSONArray(historyFile.readText())
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(ChatLine(o.optString("text"), o.optBoolean("user")))
            }
        }
    }.getOrDefault(emptyList())

    override fun onCleared() {
        job?.cancel()
        ai.close()
        super.onCleared()
    }

    companion object {
        private fun statusText(state: AiState) = when (state) {
            AiState.NO_MODEL -> "Модель не установлена"
            AiState.IMPORTING -> "Копирование модели…"
            AiState.READY_TO_START -> "Модель установлена"
            AiState.STARTING -> "Запуск локальной модели…"
            AiState.READY -> "OFFLINE AI готов"
            AiState.GENERATING -> "AI генерирует ответ…"
            AiState.ERROR -> "Ошибка"
        }
    }
}
