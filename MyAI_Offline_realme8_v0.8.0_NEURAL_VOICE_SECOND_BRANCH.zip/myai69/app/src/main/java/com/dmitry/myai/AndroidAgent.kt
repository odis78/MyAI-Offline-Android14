package com.dmitry.myai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import java.util.Locale

/**
 * Deterministic local command router.
 *
 * It handles a small set of safe Android actions without asking the LLM to guess
 * how to control the phone. This becomes the foundation for the future Tool Engine.
 */
class AndroidAgent(private val context: Context) {

    fun execute(text: String): String? {
        val command = text.trim()
        if (command.isEmpty()) return null
        val normalized = command.lowercase(Locale.getDefault())

        return when {
            normalized == "домой" ||
                normalized == "на главный экран" ||
                normalized.contains("перейди на главный экран") -> {
                if (MyAiAccessibilityService.goHome()) "Готово. Открыт главный экран." else accessibilityRequired()
            }

            normalized == "назад" ||
                normalized == "вернись назад" ||
                normalized.contains("нажми назад") -> {
                if (MyAiAccessibilityService.goBack()) "Готово. Выполнено «Назад»." else accessibilityRequired()
            }

            normalized.contains("последние приложения") ||
                normalized.contains("открой последние") -> {
                if (MyAiAccessibilityService.openRecents()) "Готово. Открыты последние приложения." else accessibilityRequired()
            }

            normalized.contains("уведомления") ||
                normalized.contains("открой шторку") -> {
                if (MyAiAccessibilityService.notifications()) "Готово. Открыты уведомления." else accessibilityRequired()
            }

            normalized == "открой настройки" ||
                normalized == "открой настройки телефона" -> {
                start(Intent(Settings.ACTION_SETTINGS))
                "Готово. Открыты настройки Android."
            }

            normalized.contains("открой калькулятор") -> {
                if (openFirstMatching(
                        "com.google.android.calculator",
                        "com.android.calculator2",
                        "com.coloros.calculator"
                    )
                ) "Готово. Открыт калькулятор."
                else "Не нашёл калькулятор на телефоне."
            }

            normalized.contains("открой браузер") -> {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")))
                "Готово. Открыт браузер. Сам MyAI при этом не выполнял сетевой запрос."
            }

            normalized.contains("диагностика производительности") ||
                normalized.contains("профиль производительности") ||
                normalized.contains("диагностика телефона") -> {
                val p = RealmePerformanceProfile(context).snapshot()
                """Диагностика устройства:
CPU-ядер: ${p.cpuCores}
ОЗУ: ${p.availableRamMb} MB свободно из ${p.totalRamMb} MB
Температурный статус: ${p.thermalStatus}
Стартовая рекомендация: ${p.recommendedThreads} потока(ов)
Профиль: ${p.profile}

Важно: это стартовая настройка. Для Второй ветки финальный выбор потоков будет делаться реальным LLM-бенчмарком."""
            }

            normalized.startsWith("прочитай экран") ||
                normalized.startsWith("что сейчас на экране") ||
                normalized == "прочитай что на экране" -> {
                val result = MyAiAccessibilityService.readScreen()
                if (result.isBlank()) accessibilityRequired()
                else "Текст текущего экрана:\n$result"
            }

            normalized.startsWith("найди на экране ") ||
                normalized.startsWith("найди ") -> {
                val target = extractFindAndClickTarget(command)
                if (target.isBlank()) {
                    "Укажи, что найти и нажать."
                } else if (MyAiAccessibilityService.clickText(target)) {
                    "Готово. Нашёл и нажал «$target»."
                } else {
                    "Не смог найти «$target». Проверь, что элемент есть на экране и служба управления телефоном включена."
                }
            }

            normalized.startsWith("нажми ") -> {
                val target = cleanTarget(command.substringAfter("нажми ").trim())
                if (target.isBlank()) "Укажи, что нажать."
                else if (MyAiAccessibilityService.clickText(target)) "Готово. Нажал «$target»."
                else "Не смог найти «$target». Проверь, что служба управления телефоном включена."
            }

            else -> null
        }
    }

    private fun accessibilityRequired() =
        "Для управления телефоном включи службу «MyAI — управление телефоном» в настройках специальных возможностей."

    /**
     * Extracts targets from commands such as:
     *   найди на экране "Система" и нажми
     *   найди "Система" и нажми
     *   найди на экране Система и нажми
     */
    private fun extractFindAndClickTarget(command: String): String {
        val raw = command.trim()
        val withoutPrefix = raw.replaceFirst(
            Regex("^найди(?:\\s+на\\s+экране)?\\s*", RegexOption.IGNORE_CASE),
            ""
        ).trim()

        val beforeClick = withoutPrefix.replaceFirst(
            Regex("\\s+и\\s+нажми(?:\\s*)$", RegexOption.IGNORE_CASE),
            ""
        ).trim()

        return cleanTarget(beforeClick)
    }

    private fun cleanTarget(value: String): String {
        var target = value.trim()
        if (target.length >= 2) {
            val first = target.first()
            val last = target.last()
            if ((first == '"' && last == '"') ||
                (first == '«' && last == '»') ||
                (first == '\'' && last == '\'')) {
                target = target.substring(1, target.length - 1).trim()
            }
        }
        return target
    }

    private fun start(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    private fun openFirstMatching(vararg packages: String): Boolean {
        for (pkg in packages) {
            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching {
                    context.startActivity(intent)
                    return true
                }
            }
        }
        return false
    }
}
