package com.dmitry.myai

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.roundToInt
import kotlin.system.measureTimeMillis

/**
 * Safe hardware benchmark for the experimental Second Branch.
 *
 * This is a CPU scheduling benchmark, NOT an LLM benchmark. It is used to
 * choose a sensible starting thread count before a real llama.cpp/Qwen
 * benchmark is available.
 */
data class CpuBenchmarkRow(
    val threads: Int,
    val opsPerSecond: Long,
    val elapsedMs: Long
)

data class CpuBenchmarkReport(
    val rows: List<CpuBenchmarkRow>,
    val bestThreads: Int,
    val batteryTempC: Float?,
    val thermalStatus: String,
    val freeRamMb: Long,
    val totalRamMb: Long
)

class DeviceBenchmark(private val context: Context) {
    suspend fun run(): CpuBenchmarkReport = withContext(Dispatchers.Default) {
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        // Do not hammer the device with every possible count on a huge CPU.
        val candidates = listOf(1, 2, 4, 6, 8).filter { it <= maxOf(8, cores) }.distinct()
        val rows = candidates.map { runCpuTest(it, 1400L) }
        val best = rows.maxByOrNull { it.opsPerSecond }?.threads ?: 1
        val am = context.getSystemService(ActivityManager::class.java)
        val mem = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(mem)
        CpuBenchmarkReport(
            rows = rows,
            bestThreads = best,
            batteryTempC = batteryTemperatureC(),
            thermalStatus = thermalLabel(),
            freeRamMb = mem.availMem / (1024L * 1024L),
            totalRamMb = mem.totalMem / (1024L * 1024L)
        )
    }

    private fun runCpuTest(threads: Int, durationMs: Long): CpuBenchmarkRow {
        val pool = Executors.newFixedThreadPool(threads)
        val latch = CountDownLatch(threads)
        val operations = AtomicLong(0L)
        val elapsed = measureTimeMillis {
            repeat(threads) {
                pool.execute {
                    var x = (it + 1).toLong()
                    val end = System.nanoTime() + durationMs * 1_000_000L
                    var local = 0L
                    while (System.nanoTime() < end) {
                        x = x xor (x shl 13)
                        x = x xor (x ushr 7)
                        x = x xor (x shl 17)
                        x += -7046029254386353131L
                        local++
                    }
                    // Prevent the optimizer from making the loop irrelevant.
                    operations.addAndGet(local + (x and 0xFF))
                    latch.countDown()
                }
            }
            latch.await(durationMs + 2000L, TimeUnit.MILLISECONDS)
        }
        pool.shutdownNow()
        val seconds = elapsed.coerceAtLeast(1L) / 1000.0
        val opsPerSecond = (operations.get().toDouble() / seconds).roundToInt().toLong()
        return CpuBenchmarkRow(threads, opsPerSecond, elapsed)
    }

    private fun batteryTemperatureC(): Float? {
        val bm = context.getSystemService(BatteryManager::class.java) ?: return null
        val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
            ?: return null
        val raw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        return if (raw == Int.MIN_VALUE) null else raw / 10f
    }

    private fun thermalLabel(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "не поддерживается"
        val pm = context.getSystemService(PowerManager::class.java) ?: return "неизвестно"
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "норма"
            PowerManager.THERMAL_STATUS_LIGHT -> "слегка повышена"
            PowerManager.THERMAL_STATUS_MODERATE -> "умеренная"
            PowerManager.THERMAL_STATUS_SEVERE -> "высокая"
            PowerManager.THERMAL_STATUS_CRITICAL -> "критическая"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "аварийная"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "аварийное отключение"
            else -> "неизвестно"
        }
    }
}
