#!/usr/bin/env bash
set -euo pipefail

test -x ./gradlew
python3 -c 'import xml.etree.ElementTree as ET; ET.parse("app/src/main/AndroidManifest.xml")'
grep -q 'id("com.android.application") version "8.6.1"' build.gradle.kts
grep -q 'id("org.jetbrains.kotlin.android") version "2.4.10"' build.gradle.kts
grep -q 'litertlm-android:0.17.1' app/build.gradle.kts
grep -q 'sherpa-onnx:sherpa-onnx:v1.13.8' app/build.gradle.kts
grep -q 'https://jitpack.io' settings.gradle.kts
grep -q 'versionCode = 800' app/build.gradle.kts
grep -q 'versionName = "0.8.0-neural-voice-realme8"' app/build.gradle.kts
grep -q 'NeuralVoiceManager.kt' README.md
test -f app/src/main/java/com/dmitry/myai/NeuralVoiceManager.kt
test -f app/src/main/java/com/dmitry/myai/NeuralTtsController.kt
! grep -Rqs 'kotlinOptions' app build.gradle.kts
! grep -qs 'versionCode = 700' app/build.gradle.kts
! grep -qs 'FIXED' README.md app/build.gradle.kts settings.gradle.kts
! grep -qs '\.text' app/src/main/java/com/dmitry/myai/LocalAiEngine.kt

echo "MyAI v0.8 sanity check: OK"

# Second Branch LLM benchmark files
test -f app/src/main/java/com/dmitry/myai/LlamaEngine.kt
test -f app/src/main/java/com/dmitry/myai/GgufModelManager.kt
grep -q 'dev.ffmpegkit-maintained:llama-android:0.1.1' app/build.gradle.kts
grep -q 'tokensPerSecond' app/src/main/java/com/dmitry/myai/LlamaEngine.kt
